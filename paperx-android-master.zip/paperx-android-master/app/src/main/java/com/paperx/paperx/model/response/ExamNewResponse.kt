package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

class ExamNewResponse {
    @SerializedName("code")
    var code: Int? = null
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null
    @SerializedName("message")
    var message: String? = null
    @SerializedName("result")
    var result: Result? = null

    data class Result(
        @SerializedName("data")
        var data: ArrayList<Data>? = null
    ) {
        data class Data(
            @SerializedName("allowLateSubmissions")
            var allowLateSubmissions: List<String?>? = null,
            @SerializedName("applyAll")
            var applyAll: Boolean? = null,
            @SerializedName("course")
            var course: Course? = null,
            @SerializedName("defaultRubricType")
            var defaultRubricType: String? = null,
            @SerializedName("defaultScoreBonds")
            var defaultScoreBonds: List<String?>? = null,
            @SerializedName("endDate")
            var endDate: String? = null,
            @SerializedName("endTime")
            var endTime: String? = null,
            @SerializedName("fileVisibility")
            var fileVisibility: Boolean? = null,
            @SerializedName("files")
            var files: List<File?>? = null,
            @SerializedName("graded")
            var graded: Double? = null,
            @SerializedName("groupSubmissionLimit")
            var groupSubmissionLimit: Int? = null,
            @SerializedName("_id")
            var id: String? = null,
            @SerializedName("isEnabledGroupSubmission")
            var isEnabledGroupSubmission: Boolean? = null,
            @SerializedName("isPublished")
            var isPublished: Boolean? = null,
            @SerializedName("isRegrades")
            var isRegrades: Boolean? = null,
            @SerializedName("lateDate")
            var lateDate: String? = null,
            @SerializedName("lateTime")
            var lateTime: String? = null,
            @SerializedName("name")
            var name: String? = null,
            @SerializedName("outlines")
            var outlines: ArrayList<Outline>? = null,
            @SerializedName("passive")
            var passive: Boolean? = null,
            @SerializedName("selectionStyle")
            var selectionStyle: String? = null,
            @SerializedName("shareInstructors")
            var shareInstructors: Boolean? = null,
            @SerializedName("shareStudents")
            var shareStudents: Boolean? = null,
            @SerializedName("shareTAs")
            var shareTAs: Boolean? = null,
            @SerializedName("stamp")
            var stamp: Stamp? = null,
            @SerializedName("startDate")
            var startDate: String? = null,
            @SerializedName("startTime")
            var startTime: String? = null,
            @SerializedName("status")
            var status: String? = null,
            @SerializedName("studentVisibility")
            var studentVisibility: String? = null,
            @SerializedName("submissionType")
            var submissionType: String? = null,
            @SerializedName("type")
            var type: String? = null,
            @SerializedName("uploadSubmissions")
            var uploadSubmissions: String? = null
        ) {
            data class Course(
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("name")
                var name: String? = null
            )

            data class File(
                @SerializedName("duration")
                var duration: Int? = null,
                @SerializedName("durationType")
                var durationType: String? = null,
                @SerializedName("encoding")
                var encoding: String? = null,
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("mimeType")
                var mimeType: String? = null,
                @SerializedName("name")
                var name: String? = null,
                @SerializedName("originalName")
                var originalName: String? = null,
                @SerializedName("path")
                var path: String? = null,
                @SerializedName("size")
                var size: Int? = null,
                @SerializedName("sizeType")
                var sizeType: String? = null
            )

            data class Outline(
                @SerializedName("childs")
                var childs: ArrayList<Child>? = null,
                @SerializedName("point")
                var point: Int? = null,
                @SerializedName("title")
                var title: String? = null
            ) {
                data class Child(
                    @SerializedName("point")
                    var point: Int? = null,
                    @SerializedName("title")
                    var title: String? = null
                )
            }

            data class Stamp(
                @SerializedName("createAt")
                var createAt: String? = null,
                @SerializedName("displayName")
                var displayName: String? = null,
                @SerializedName("email")
                var email: String? = null,
                @SerializedName("ip")
                var ip: String? = null,
                @SerializedName("username")
                var username: String? = null
            )
        }
    }
}