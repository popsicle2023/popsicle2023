package com.paperx.paperx.usecase

import com.paperx.paperx.model.response.CourseListResponse
import com.paperx.paperx.model.response.UserLoginResponseModel
import com.paperx.paperx.model.response.WhoamiResponse
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.repository.PaperXRepository
import com.paperx.paperx.util.Resource
import javax.inject.Inject

class CoursesDataUseCase @Inject constructor(private val paperRepository: PaperXRepository) {
    suspend fun coursesData() : Resource<CourseListResponse> = paperRepository.courses()
    suspend fun whoami() : Resource<WhoamiResponse> = paperRepository.whoami()
}