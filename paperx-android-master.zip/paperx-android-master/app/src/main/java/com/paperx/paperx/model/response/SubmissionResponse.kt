package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

data class SubmissionResponse(
    @SerializedName("code")
    var code: Int? = null,
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null,
    @SerializedName("message")
    var message: String? = null,
    @SerializedName("result")
    var result: Result? = null
) {
    class Result
}