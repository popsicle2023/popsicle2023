package com.paperx.paperx.model.response

import android.net.Uri
import java.net.URI

data class ImageAndOutlinesModel(
    var uri: Uri? = null,
    var outlineList: ArrayList<String> = arrayListOf(),
    var imagePath: String? = null
)
