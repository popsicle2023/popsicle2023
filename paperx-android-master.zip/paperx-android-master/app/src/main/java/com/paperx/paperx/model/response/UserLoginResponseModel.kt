package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

data class UserLoginResponseModel(
    @SerializedName("code")
    var code: Int? = null,
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null,
    @SerializedName("message")
    var message: String? = null,
    @SerializedName("result")
    var result: Result? = null
) {
    data class Result(
        @SerializedName("token")
        var token: String? = null
    )
}