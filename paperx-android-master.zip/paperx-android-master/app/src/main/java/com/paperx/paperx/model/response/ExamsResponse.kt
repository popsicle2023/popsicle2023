package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

class ExamsResponse{
    @SerializedName("code")
    var code: Int? = null
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null
    @SerializedName("message")
    var message: String? = null
    @SerializedName("result")
    var result: Result? = null

    data class Result(
        @SerializedName("data")
        var data: ArrayList<Data>? = null
    ) {
        data class Data(
            @SerializedName("endDate")
            var endDate: String? = null,
            @SerializedName("_id")
            var id: String? = null,
            @SerializedName("name")
            var name: String? = null,
            @SerializedName("startDate")
            var startDate: String? = null,
            @SerializedName("submissions")
            var submissions: ArrayList<Submission>? = null
        ) {
            data class Submission(
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("user")
                var user: String? = null
            )
        }
    }
}