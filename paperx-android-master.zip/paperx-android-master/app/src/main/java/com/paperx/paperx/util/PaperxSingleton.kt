package com.paperx.paperx.util

import com.paperx.paperx.model.response.ImageAndOutlinesModel

object PaperxSingleton {
    var token = ""
    var outlinesList: ArrayList<ImageAndOutlinesModel> = arrayListOf()
}