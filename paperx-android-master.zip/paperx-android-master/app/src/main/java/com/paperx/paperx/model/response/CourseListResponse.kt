package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

class CourseListResponse{
    @SerializedName("code")
    var code: Int? = null
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null
    @SerializedName("message")
    var message: String? = null
    @SerializedName("result")
    var result: Result? = null

    data class Result(
        @SerializedName("data")
        var data: ArrayList<Data>? = null
    ) {
        data class Data(
            @SerializedName("assignedTAs")
            var assignedTAs: List<AssignedTA?>? = null,
            @SerializedName("departmentName")
            var departmentName: String? = null,
            @SerializedName("endDate")
            var endDate: String? = null,
            @SerializedName("endTime")
            var endTime: String? = null,
            @SerializedName("exams")
            var exams: List<Exam?>? = null,
            @SerializedName("grades")
            var grades: List<Grade?>? = null,
            @SerializedName("_id")
            var id: String? = null,
            @SerializedName("name")
            var name: String? = null,
            @SerializedName("passive")
            var passive: Boolean? = null,
            @SerializedName("printeds")
            var printeds: List<Printed?>? = null,
            @SerializedName("schoolName")
            var schoolName: String? = null,
            @SerializedName("stamp")
            var stamp: Stamp? = null,
            @SerializedName("startDate")
            var startDate: String? = null,
            @SerializedName("startTime")
            var startTime: String? = null,
            @SerializedName("videos")
            var videos: List<Any?>? = null
        ) {
            data class AssignedTA(
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("username")
                var username: String? = null
            )

            data class Exam(
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("name")
                var name: String? = null
            )

            data class Grade(
                @SerializedName("distribution")
                var distribution: Int? = null,
                @SerializedName("type")
                var type: String? = null
            )

            data class Printed(
                @SerializedName("duration")
                var duration: Int? = null,
                @SerializedName("durationType")
                var durationType: String? = null,
                @SerializedName("encoding")
                var encoding: String? = null,
                @SerializedName("id")
                var id: String? = null,
                @SerializedName("mimeType")
                var mimeType: String? = null,
                @SerializedName("name")
                var name: String? = null,
                @SerializedName("originalName")
                var originalName: String? = null,
                @SerializedName("path")
                var path: String? = null,
                @SerializedName("size")
                var size: Int? = null,
                @SerializedName("sizeType")
                var sizeType: String? = null
            )

            data class Stamp(
                @SerializedName("createAt")
                var createAt: String? = null,
                @SerializedName("displayName")
                var displayName: String? = null,
                @SerializedName("email")
                var email: String? = null,
                @SerializedName("ip")
                var ip: String? = null,
                @SerializedName("username")
                var username: String? = null
            )
        }
    }
}