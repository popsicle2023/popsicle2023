package com.paperx.paperx.view

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mobven.kocailem.helpers.OnFileChooseListener
import com.paperx.paperx.adapter.ImageAndOutlinesSelectedListAdapter
import com.paperx.paperx.adapter.OutlineParentSelectorAdapter
import com.paperx.paperx.databinding.FragmentTakeImageExamBinding
import com.paperx.paperx.databinding.OutlinesSelectorBottomSheetBinding
import com.paperx.paperx.helper.CameraHelper
import com.paperx.paperx.model.response.ExamNewResponse
import com.paperx.paperx.model.response.ImageAndOutlinesModel
import com.paperx.paperx.model.response.OutlinesListModel
import com.paperx.paperx.util.Constant
import com.paperx.paperx.util.PermissionUtils
import com.paperx.paperx.viewmodel.ExamsViewModel
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import java.io.File
import java.util.*
import kotlin.collections.ArrayList


@AndroidEntryPoint
class TakeImageExamFragment : Fragment(), OnFileChooseListener {

    private lateinit var binding: FragmentTakeImageExamBinding
    private val examsViewModel: ExamsViewModel by viewModels()
    private val cameraHelper by lazy { CameraHelper(requireActivity()) }
    var imagePathList: ArrayList<String> = ArrayList()

    val imageAndOutlinesSelectedListAdapter = ImageAndOutlinesSelectedListAdapter()

    val outlineParentSelectorAdapter = OutlineParentSelectorAdapter()

    private var examId: String? = null
    private var outlinePosition: Int? = null


    private var sendOutlineListArrayList: ArrayList<ImageAndOutlinesModel> = arrayListOf()

    var outlinesParent: ArrayList<ExamNewResponse.Result.Data.Outline>? = arrayListOf()

    var outlinesTitleList: ArrayList<OutlinesListModel>? = arrayListOf()

    var tempOutlineList: ArrayList<OutlinesListModel> = arrayListOf()

    var imageAndOutlinesModel = ImageAndOutlinesModel()

    var mStringArray: Array<String?> = arrayOf()

    var jsonArray = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraHelper.init(this, this)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTakeImageExamBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            (arguments)?.let {
                examId = it.get(Constant.EXAM_ID) as String?
                outlinePosition = it.get(Constant.OUTLINES_POSITION) as Int?
            }
            //Toast.makeText(requireContext(), examId.toString(), Toast.LENGTH_LONG).show()

            ivSelectOutline.setOnClickListener {
                if (imagePreview.drawable != null){
                    showBottomSheet {
                        binding.tvExamTitle.visibility = View.VISIBLE
                        imagePreview.setImageResource(0)
                        ivTakeImage.visibility = View.VISIBLE
                        ivClear.visibility = View.GONE
                    }
                }else{
                    Snackbar.make(view, "First you have to draw the exam paper.", Snackbar.LENGTH_LONG).show()
                }
            }

            examsViewModel.exams()

            ivTakeImage.setOnClickListener {
                askPermissionAndGetImage()
            }

            rvExamPreviewList.adapter = imageAndOutlinesSelectedListAdapter

            imageAndOutlinesSelectedListAdapter.removeItemClickListener = {
                sendOutlineListArrayList.remove(it)
                imageAndOutlinesSelectedListAdapter.setSelectedOutlines(sendOutlineListArrayList)
            }

            ivClear.setOnClickListener {
                imagePreview.setImageResource(0)
                ivTakeImage.visibility = View.VISIBLE
                ivClear.visibility = View.GONE
            }

            sendExamImage.setOnClickListener {
                if (sendOutlineListArrayList.isNotEmpty()){
                    val fileList: MutableList<MultipartBody.Part> = mutableListOf()
                    sendOutlineListArrayList.forEachIndexed { index, s ->
                        fileList.clear()
                        val file = File(s.imagePath ?: "")
                        val requestFile = file.asRequestBody("image/png".toMediaTypeOrNull())
                        val partImage = MultipartBody.Part.createFormData("submissions", file.name, requestFile)
                        val partExam = MultipartBody.Part.createFormData("exam", examId ?: "")
                        fileList.add(partImage)
                        fileList.add(partExam)
                        mStringArray = arrayOfNulls(s.outlineList.size)
                        mStringArray = s.outlineList.toArray(mStringArray)
                        jsonArray = JSONArray(s.outlineList)
                        val partOutlines = MultipartBody.Part.createFormData("outlineTitles", jsonArray.toString())
                        fileList.add(partOutlines)

                        examsViewModel.submissions(fileList)
                        pbLoading.visibility = View.VISIBLE
                    }
                }else{
                    Snackbar.make(view, "You cannot send blank.", Snackbar.LENGTH_LONG).show()
                }
            }



            examsViewModel.submissionLiveData.observe(viewLifecycleOwner){
                it?.let {
                    Snackbar.make(view, it.message.toString(), Snackbar.LENGTH_LONG).show()
                    pbLoading.visibility = View.GONE
                }
            }
            examsViewModel.errorMessage.observe(viewLifecycleOwner){
                it?.let {
                    Toast.makeText(requireContext(), it, Toast.LENGTH_LONG).show()
                }
            }

            examsViewModel.examLiveData.observe(viewLifecycleOwner){
                it?.let {
                   outlinesParent = it.result?.data?.filter { it.id == examId }?.getOrNull(0)?.outlines
                    it.result?.data?.filter { it.id == examId }?.getOrNull(0)?.outlines?.forEach { parent->
                        if (parent.childs?.isNotEmpty() == true){
                            parent.childs?.forEach { child->
                                outlinesTitleList?.add(OutlinesListModel(parent.title + "/" + child.title, false))
                            }
                        }else{
                            outlinesTitleList?.add(OutlinesListModel(parent.title ?: "", false))
                        }
                    }
                }
            }

        }
    }

    override fun onFilesSelected(pathList: List<File>, isVideo: Boolean) {
        pathList.forEach {
            binding.apply {
                imagePathList.add(it.path)
                imageAndOutlinesModel.uri = it.toUri()
                imageAndOutlinesModel.imagePath = it.path
                imagePreview.setImageURI(it.toUri())
                ivTakeImage.visibility = View.GONE
                ivClear.visibility = View.VISIBLE
            }
        }
    }

    private fun askPermissionAndGetImage() {
        if (PermissionUtils.checkCameraPermission(requireActivity())) {
            cameraHelper.takePhotoResultLauncher.launch(cameraHelper.takenImageUri)
        } else {
            PermissionUtils.askCameraPermission(this)
        }
    }

    private fun showBottomSheet(selectClickListener: () -> Unit = {->}) {
        tempOutlineList.clear()
        val binding = OutlinesSelectorBottomSheetBinding.inflate(layoutInflater)
        val bottomSheetDialog = BottomSheetDialog(requireContext())

        binding.apply {
            rvOutlinesList.adapter = outlineParentSelectorAdapter
            outlineParentSelectorAdapter.submitList(outlinesTitleList)

            outlineParentSelectorAdapter.outlineParentClickListener = { outline, status, position ->
                if (status){
                    tempOutlineList.add(OutlinesListModel(outline.outlineTitle, status, position))
                }else run {
                    tempOutlineList.remove(OutlinesListModel(outline.outlineTitle, status, position))
                }
            }

            btnSave.setOnClickListener {
                val imageAndOutlinesModel = ImageAndOutlinesModel().apply {
                    uri = imageAndOutlinesModel.uri
                    imagePath = imageAndOutlinesModel.imagePath
                    tempOutlineList.forEach {
                        it.outlineTitle?.let { it1 -> outlineList.add(it1) }
                        outlinesTitleList?.get(it.itemPosition ?: 0)?.isSelect = it.isSelect
                    }
                }
                sendOutlineListArrayList.add(imageAndOutlinesModel)

                imageAndOutlinesSelectedListAdapter.setSelectedOutlines(sendOutlineListArrayList)
                selectClickListener()
                bottomSheetDialog.dismiss()
            }
        }

        bottomSheetDialog.setContentView(binding.root)
        bottomSheetDialog.show()
    }




}