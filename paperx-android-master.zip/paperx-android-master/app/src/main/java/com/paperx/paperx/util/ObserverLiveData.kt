package com.paperx.paperx.util

import android.app.AlertDialog
import android.content.Context
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData


fun LiveData<String?>.observerLiveData(viewLifecycleOwner: LifecycleOwner, context: Context){
   this.observe(viewLifecycleOwner){
       it?.let {
           val builder: AlertDialog.Builder = AlertDialog.Builder(context)
           builder.setTitle("Info")
           builder.setMessage(it)
           builder.show()
       }
   }
}