package com.paperx.paperx.helper

import android.content.Context
import com.paperx.paperx.util.Constant
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object FileUtils {
    fun createImageFile(context: Context): File {
        val timeStamp = SimpleDateFormat.getDateTimeInstance().format(Date())
        val storageDir = context.cacheDir

        return File.createTempFile(
            "${Constant.JPG}_${timeStamp}_",
            Constant.EXT_JPG,
            storageDir
        )
    }
}