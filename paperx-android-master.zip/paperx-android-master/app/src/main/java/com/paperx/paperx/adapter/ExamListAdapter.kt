package com.paperx.paperx.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.paperx.paperx.databinding.ExamListItemLayoutBinding
import com.paperx.paperx.databinding.ExamsListItemLayoutBinding
import com.paperx.paperx.model.response.ExamNewResponse
import com.paperx.paperx.model.response.ExamsResponse

class ExamListAdapter : ListAdapter<ExamNewResponse.Result.Data, ExamListAdapter.ViewHolder>(
    ExamDiffCallback()
    ) {

    var examClickListener: ExamClickListener? = null

    interface ExamClickListener {
        fun examItem(item: ExamNewResponse.Result.Data, position: Int)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, examClickListener)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder.from(parent)
    }

    class ViewHolder private constructor(val binding: ExamsListItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ExamNewResponse.Result.Data, examClickListener: ExamClickListener?) {
            with(binding) {
                tvCourseName.text = item.name
                //tvStartDate.text = item.startDate
                binding.root.setOnClickListener {
                    examClickListener?.examItem(item, adapterPosition)
                }
            }
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = ExamsListItemLayoutBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }
}


class ExamDiffCallback :
    DiffUtil.ItemCallback<ExamNewResponse.Result.Data>() {

    override fun areItemsTheSame(
        oldItem: ExamNewResponse.Result.Data,
        newItem: ExamNewResponse.Result.Data
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: ExamNewResponse.Result.Data,
        newItem: ExamNewResponse.Result.Data
    ): Boolean {
        return oldItem == newItem
    }
}