package com.paperx.paperx.di

import com.diyabet.diyabetgunlugum.Interceptor.ServiceInterceptor
import com.localebro.okhttpprofiler.OkHttpProfilerInterceptor
import com.paperx.paperx.BuildConfig
import com.paperx.paperx.repository.PaperXRepository
import com.paperx.paperx.service.PaperXAPI
import com.paperx.paperx.util.Constant
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun paperXRepository(api: PaperXAPI) = PaperXRepository(api)

    @Singleton
    @Provides
    fun providePaperApi() : PaperXAPI {
        val builder = OkHttpClient.Builder()
        val client = OkHttpClient.Builder()
            .addInterceptor(ServiceInterceptor())
            .build()
        if (BuildConfig.DEBUG){
            builder.addInterceptor(OkHttpProfilerInterceptor())
            builder.addInterceptor(ServiceInterceptor())
        }
        val clientProfiller = builder.build()
        return Retrofit.Builder()
            .client(clientProfiller)
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(Constant.BASE_URL)
            .build()
            .create(PaperXAPI::class.java)
    }

}