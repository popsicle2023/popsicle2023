package com.paperx.paperx.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.paperx.paperx.R
import com.paperx.paperx.adapter.ExamListAdapter
import com.paperx.paperx.databinding.FragmentExamBinding
import com.paperx.paperx.model.response.ExamNewResponse
import com.paperx.paperx.util.Constant
import com.paperx.paperx.util.observerLiveData
import com.paperx.paperx.viewmodel.ExamsViewModel
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class ExamFragment : Fragment() {

    private lateinit var binding: FragmentExamBinding
    private val examsViewModel: ExamsViewModel by viewModels()
    private val examListAdapter = ExamListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentExamBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            val rvExams = object : ExamListAdapter.ExamClickListener{
                override fun examItem(item: ExamNewResponse.Result.Data, position: Int) {
                    Navigation.findNavController(view).navigate(R.id.action_examFragment_to_takeImageExamFragment, bundleOf(
                        Constant.EXAM_ID to item.id, Constant.OUTLINES_POSITION to position))
                }
            }

            rvExamList.adapter = examListAdapter
            examListAdapter.examClickListener = rvExams
            examsViewModel.exams()

            examsViewModel.examLiveData.observe(viewLifecycleOwner){
                it?.let {
                    examListAdapter.submitList(it.result?.data)
                }
            }
            examsViewModel.errorMessage.observerLiveData(viewLifecycleOwner, requireContext())
        }
    }
}