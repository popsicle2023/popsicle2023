package com.paperx.paperx.helper

import androidx.core.content.FileProvider

class GenericFileProvider: FileProvider() {

}