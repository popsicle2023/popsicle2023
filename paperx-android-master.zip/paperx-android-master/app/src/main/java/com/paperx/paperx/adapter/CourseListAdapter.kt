package com.paperx.paperx.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.paperx.paperx.databinding.CoursesListItemLayoutBinding
import com.paperx.paperx.databinding.ExamListItemLayoutBinding
import com.paperx.paperx.model.response.CourseListResponse
import com.paperx.paperx.model.response.ExamsResponse

class CourseListAdapter : ListAdapter<CourseListResponse.Result.Data, CourseListAdapter.ViewHolder>(
    CourseDiffCallback()
    ) {

    var courseClickListener: CourseClickListener? = null

    interface CourseClickListener {
        fun examItem(item: CourseListResponse.Result.Data)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, courseClickListener)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder.from(parent)
    }

    class ViewHolder private constructor(val binding: CoursesListItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: CourseListResponse.Result.Data, courseClickListener: CourseClickListener?) {
            with(binding) {
                tvCourseName.text = item.name
                tvSubCourseName.text = item.departmentName

                binding.root.setOnClickListener {
                    courseClickListener?.examItem(item)
                }
            }
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = CoursesListItemLayoutBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }
}


class CourseDiffCallback :
    DiffUtil.ItemCallback<CourseListResponse.Result.Data>() {

    override fun areItemsTheSame(
        oldItem: CourseListResponse.Result.Data,
        newItem: CourseListResponse.Result.Data
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: CourseListResponse.Result.Data,
        newItem: CourseListResponse.Result.Data
    ): Boolean {
        return oldItem == newItem
    }
}