package com.paperx.paperx.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.orhanobut.hawk.Hawk
import com.paperx.paperx.R
import com.paperx.paperx.adapter.CourseListAdapter
import com.paperx.paperx.databinding.FragmentMainBinding
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.util.Constant
import com.paperx.paperx.util.observerLiveData
import com.paperx.paperx.viewmodel.LoginViewModel
import com.paperx.paperx.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainFragment : Fragment() {
    private lateinit var binding: FragmentMainBinding
    private val mainViewModel: MainViewModel by viewModels()
    private val courseListAdapter = CourseListAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMainBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            mainViewModel.whoami()

            mainViewModel.courses()

            rvCourseList.adapter = courseListAdapter
            rvCourseList.layoutManager = GridLayoutManager(this@MainFragment.requireContext(), 2)

            mainViewModel.courseLiveData.observe(viewLifecycleOwner){
                it?.result?.data.let { courseList->
                    courseListAdapter.submitList(courseList)
                }
            }
            mainViewModel.whoamiLiveData.observe(viewLifecycleOwner){
                it?.let {
                    tvWhoamiPersonName.text = getString(R.string.welcome_person, it.result?.username)
                }
            }
        }
    }
}