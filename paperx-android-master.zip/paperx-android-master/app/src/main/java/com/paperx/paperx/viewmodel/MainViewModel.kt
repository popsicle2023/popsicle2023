package com.paperx.paperx.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.paperx.paperx.model.response.*
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.usecase.CoursesDataUseCase
import com.paperx.paperx.usecase.ExamDataUseCase
import com.paperx.paperx.usecase.LoginDataUseCase
import com.paperx.paperx.util.Resource

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val coursesDataUseCase: CoursesDataUseCase
)  : ViewModel() {

    private val _courseLiveData: MutableLiveData<CourseListResponse?> = MutableLiveData()
    val courseLiveData: LiveData<CourseListResponse?> get() = _courseLiveData

    private val _whoamiLiveData: MutableLiveData<WhoamiResponse?> = MutableLiveData()
    val whoamiLiveData: LiveData<WhoamiResponse?> get() = _whoamiLiveData

    private val _errorMessage: MutableLiveData<String?> = MutableLiveData()
    val errorMessage: LiveData<String?> get() = _errorMessage
    var isLoading = mutableStateOf(false)

    fun courses(){
        viewModelScope.launch {
            isLoading.value = true
            val result = coursesDataUseCase.coursesData()
            when(result){
                is Resource.Success -> {
                    _courseLiveData.value = result.data
                    isLoading.value = false
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message.toString()
                    isLoading.value = false
                }
                else -> {}
            }
        }
    }

    fun whoami(){
        viewModelScope.launch {
            isLoading.value = true
            val result = coursesDataUseCase.whoami()
            when(result){
                is Resource.Success -> {
                    _whoamiLiveData.value = result.data
                    isLoading.value = false
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message.toString()
                    isLoading.value = false
                }
                else -> {}
            }
        }
    }

}