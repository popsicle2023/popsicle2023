package com.mobven.kocailem.helpers

import java.io.File

interface OnFileChooseListener {
    fun onFilesSelected(pathList: List<File>, isVideo: Boolean)
}