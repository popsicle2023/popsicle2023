package com.paperx.paperx.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.paperx.paperx.databinding.OutlinesItemLayoutBinding
import com.paperx.paperx.model.response.OutlinesListModel

class OutlineParentSelectorAdapter : ListAdapter<OutlinesListModel, OutlineParentSelectorAdapter.ViewHolder>(
    OutlineParentDiffCallback()
) {

    var outlineParentClickListener: (OutlinesListModel, Boolean, Int) -> Unit = { _,_,_->}
    var hashMapSelector = HashMap<String, Boolean>()


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, outlineParentClickListener, hashMapSelector)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder.from(parent)
    }

    class ViewHolder private constructor(val binding: OutlinesItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(
            item: OutlinesListModel,
            outlineParentClickListener: (OutlinesListModel, Boolean, Int) -> Unit,
            hashMapSelector: HashMap<String, Boolean>
        ) {
            with(binding) {
                item.let {
                    cbQuestionName.text = item.outlineTitle
                    cbQuestionName.isChecked = item.isSelect == true

                    cbQuestionName.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener{
                        override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
                            hashMapSelector.put(p0?.text.toString(), p1)
                            outlineParentClickListener(item, p1, adapterPosition)
                        }
                    })
                }
            }
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = OutlinesItemLayoutBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }
}


class OutlineParentDiffCallback :
    DiffUtil.ItemCallback<OutlinesListModel>() {

    override fun areItemsTheSame(
        oldItem: OutlinesListModel,
        newItem: OutlinesListModel
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: OutlinesListModel,
        newItem: OutlinesListModel
    ): Boolean {
        return oldItem == newItem
    }
}