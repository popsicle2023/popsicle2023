package com.paperx.paperx.util

object Constant {
    const val BASE_URL = "http://api.paper-x.com/"

    const val TOKEN = "token"

    const val EXT_JPG = ".jpg"
    const val JPG = "jpg"

    const val EXAM_ID = "examId"

    const val OUTLINES_POSITION = "outlinesPosition"
}