package com.paperx.paperx.util


fun ArrayList<String>.isHaveArrayListItem(item: String) : Boolean{
   if (this.filter { it == item }.isNotEmpty()){
       return false
   }
    return true
}