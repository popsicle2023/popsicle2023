package com.paperx.paperx

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PaperxApplication : Application() {
}