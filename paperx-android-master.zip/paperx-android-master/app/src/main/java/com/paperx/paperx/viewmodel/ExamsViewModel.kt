package com.paperx.paperx.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.paperx.paperx.model.response.ExamNewResponse
import com.paperx.paperx.model.response.SubmissionResponse
import com.paperx.paperx.usecase.ExamDataUseCase
import com.paperx.paperx.util.Resource

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import javax.inject.Inject

@HiltViewModel
class ExamsViewModel @Inject constructor(
    private val examDataUseCase: ExamDataUseCase
)  : ViewModel() {

    private val _examLiveData: MutableLiveData<ExamNewResponse?> = MutableLiveData()
    val examLiveData: LiveData<ExamNewResponse?> get() = _examLiveData

    private val _submissionLiveData: MutableLiveData<SubmissionResponse?> = MutableLiveData()
    val submissionLiveData: LiveData<SubmissionResponse?> get() = _submissionLiveData

    private val _errorMessage: MutableLiveData<String?> = MutableLiveData()
    val errorMessage: LiveData<String?> get() = _errorMessage

    var isLoading = mutableStateOf(false)

    fun exams(){
        viewModelScope.launch {
            isLoading.value = true
            val result = examDataUseCase.examData()
            when(result){
                is Resource.Success -> {
                    _examLiveData.value = result.data
                    isLoading.value = false
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message.toString()
                    isLoading.value = false
                }
                else -> {}
            }
        }
    }

    fun submissions(formData: List<MultipartBody.Part>){
        viewModelScope.launch {
            isLoading.value = true
            val result = examDataUseCase.submission(formData)
            when(result){
                is Resource.Success -> {
                    _submissionLiveData.value = result.data
                    isLoading.value = false
                }
                is Resource.Error -> {
                    _errorMessage.value = result.data?.message.toString()
                    isLoading.value = false
                }
                else -> {}
            }
        }
    }
}