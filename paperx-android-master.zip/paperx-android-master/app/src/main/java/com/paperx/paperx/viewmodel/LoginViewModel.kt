package com.paperx.paperx.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.paperx.paperx.model.response.UserLoginResponseModel
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.usecase.LoginDataUseCase
import com.paperx.paperx.util.Resource

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val loginDataUseCase: LoginDataUseCase
)  : ViewModel() {

    private val _loginLiveData: MutableLiveData<UserLoginResponseModel?> = MutableLiveData()
    val loginLiveData: LiveData<UserLoginResponseModel?> get() = _loginLiveData

    private val _errorMessage: MutableLiveData<String?> = MutableLiveData()
    val errorMessage: LiveData<String?> get() = _errorMessage
    var isLoading = mutableStateOf(false)

    fun login(loginRequestModel: LoginRequestModel){
        viewModelScope.launch {
            isLoading.value = true
            val result = loginDataUseCase.loginData(loginRequestModel)
            when(result){
                is Resource.Success -> {
                    _loginLiveData.value = result.data
                    isLoading.value = false
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message.toString()
                    isLoading.value = false
                }
                else -> {}
            }
        }
    }
}