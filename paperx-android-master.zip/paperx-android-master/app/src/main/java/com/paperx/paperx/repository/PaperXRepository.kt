package com.paperx.paperx.repository


import com.paperx.paperx.model.response.*
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.service.PaperXAPI
import com.paperx.paperx.util.Resource
import dagger.hilt.android.scopes.ActivityScoped
import okhttp3.MultipartBody
import javax.inject.Inject

@ActivityScoped
class PaperXRepository @Inject constructor(private val api: PaperXAPI){

    suspend fun login(loginRequestModel: LoginRequestModel) : Resource<UserLoginResponseModel> {
        val response = try {
            api.userLogin(loginRequestModel)
        }catch (e: Exception){
            return Resource.Error(e.message.toString())
        }
        return Resource.Success(response)
    }

    suspend fun exams() : Resource<ExamNewResponse> {
        val response = try {
            api.exams()
        }catch (e: Exception){
            return Resource.Error(e.message.toString())
        }
        return Resource.Success(response)
    }
    suspend fun submission(formData: List<MultipartBody.Part>) : Resource<SubmissionResponse> {
        val response = try {
            api.submission(formData)
        }catch (e: Exception){
            return Resource.Error(e.message.toString())
        }
        return Resource.Success(response)
    }

    suspend fun courses() : Resource<CourseListResponse> {
        val response = try {
            api.courses()
        }catch (e: Exception){
            return Resource.Error(e.message.toString())
        }
        return Resource.Success(response)
    }

    suspend fun whoami() : Resource<WhoamiResponse> {
        val response = try {
            api.whoami()
        }catch (e: Exception){
            return Resource.Error(e.message.toString())
        }
        return Resource.Success(response)
    }


}