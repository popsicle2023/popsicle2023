package com.paperx.paperx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.recyclerview.widget.RecyclerView
import com.paperx.paperx.R
import com.paperx.paperx.model.response.ExamNewResponse
import kotlinx.android.synthetic.main.outlines_item_layout.view.*

class OutlineChildListAdapter : RecyclerView.Adapter<OutlineChildListAdapter.ChilOutlinesViewHolder>() {

    var childClickListener: (HashMap<String, Boolean>) -> Unit = { _->}
    var parentClick = false
    var hashMapSelector = HashMap<String, Boolean>()

    var childParentTitle: String = ""

    var outlinesChildList: ArrayList<ExamNewResponse.Result.Data.Outline.Child> = arrayListOf()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ChilOutlinesViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.outlines_item_layout, parent, false)
    )

    override fun onBindViewHolder(holder: OutlineChildListAdapter.ChilOutlinesViewHolder, position: Int) {
        holder.bind(outlinesChildList[position])
    }

    override fun getItemCount() = outlinesChildList.size

    inner class ChilOutlinesViewHolder(view: View) :  RecyclerView.ViewHolder(view){
        fun bind(item: ExamNewResponse.Result.Data.Outline.Child) {
            itemView.cb_question_name.text = item.title
            itemView.cb_question_name.isChecked = parentClick

            itemView.cb_question_name.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener{
                override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
                    hashMapSelector.put(childParentTitle + "/" + p0?.text.toString(), p1)
                    childClickListener(hashMapSelector)
                }
            })
        }
    }

    fun parentCheckControl(isClick: Boolean, parentTitle: String){
        parentClick = isClick
        childParentTitle = parentTitle
        notifyDataSetChanged()
    }

    fun setChildOutlines(childOutlineList: ArrayList<ExamNewResponse.Result.Data.Outline.Child>){
        outlinesChildList.clear()
        outlinesChildList.addAll(childOutlineList)
        notifyDataSetChanged()
    }
}
