package com.paperx.paperx.model.response

data class OutlinesListModel(
    var outlineTitle: String? = null,
    var isSelect: Boolean? = null,
    var itemPosition: Int? = null
)
