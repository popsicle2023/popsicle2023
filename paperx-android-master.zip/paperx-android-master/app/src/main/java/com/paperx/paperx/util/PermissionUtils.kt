package com.paperx.paperx.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity


object PermissionUtils {

    const val REQUEST_EXTERNAL_STORAGE = 1003
    private val PERMISSIONS_STORAGE = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)

    fun askStoragePermissions(fragment: Fragment) {
        // Check if we have write permission
        fragment.requestPermissions(
                PERMISSIONS_STORAGE,
                REQUEST_EXTERNAL_STORAGE
        )
    }

    fun checkStoragePermissions(activity: Activity): Boolean {
        val writePermission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val readPermission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE)

        return writePermission == PackageManager.PERMISSION_GRANTED && readPermission == PackageManager.PERMISSION_GRANTED
    }

    const val REQUEST_CAMERA_STORAGE = 1002
    private val PERMISSION_CAMERA = arrayOf(Manifest.permission.CAMERA)



    fun askCameraPermission(fragment: Fragment) {
        // Check if we have camera permission
        if (fragment.isAdded) {
            fragment.requestPermissions(
                    PERMISSION_CAMERA,
                    REQUEST_CAMERA_STORAGE
            )
        }
    }

    fun checkCameraPermission(activity: Activity): Boolean {
        return ActivityCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    const val REQUEST_LOCATION = 1001
    private val PERMISSION_LOCATION = arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)

    fun askLocationPermission(fragment: Fragment) {
        // Check if we have camera permission
        if (fragment.isAdded) {
            fragment.requestPermissions(
                    PERMISSION_LOCATION,
                    REQUEST_LOCATION
            )
        }
    }

    fun checkLocationPermission(context: Context): Boolean {
        return ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    fun isGpsEnabled(activity: Activity): Boolean {
        val lm = activity.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var isProviderEnabled = false
        try {
            isProviderEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (ex: Exception) {
            println(ex.message)
        }

        return isProviderEnabled
    }

    fun Fragment.takePhoto(callback: ActivityResultCallback<Boolean>): ActivityResultLauncher<Uri> {
        return this.registerForActivityResult(ActivityResultContracts.TakePicture(), callback)
    }

}