package com.paperx.paperx.usecase

import com.paperx.paperx.model.response.ExamNewResponse
import com.paperx.paperx.model.response.SubmissionResponse
import com.paperx.paperx.repository.PaperXRepository
import com.paperx.paperx.util.Resource
import okhttp3.MultipartBody
import javax.inject.Inject

class ExamDataUseCase @Inject constructor(private val paperRepository: PaperXRepository) {
    suspend fun examData() : Resource<ExamNewResponse> = paperRepository.exams()
    suspend fun submission(formData: List<MultipartBody.Part>) : Resource<SubmissionResponse>
    = paperRepository.submission(formData)
}