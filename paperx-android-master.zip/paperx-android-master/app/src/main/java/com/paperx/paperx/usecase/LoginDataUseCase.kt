package com.paperx.paperx.usecase

import com.paperx.paperx.model.response.UserLoginResponseModel
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.repository.PaperXRepository
import com.paperx.paperx.util.Resource
import javax.inject.Inject

class LoginDataUseCase @Inject constructor(private val paperRepository: PaperXRepository) {
    suspend fun loginData(loginRequestModel: LoginRequestModel) : Resource<UserLoginResponseModel> = paperRepository.login(loginRequestModel)
}