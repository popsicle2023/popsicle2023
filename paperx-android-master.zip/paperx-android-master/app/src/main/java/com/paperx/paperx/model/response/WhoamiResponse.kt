package com.paperx.paperx.model.response


import com.google.gson.annotations.SerializedName

data class WhoamiResponse(
    @SerializedName("code")
    var code: Int? = null,
    @SerializedName("isShowMessage")
    var isShowMessage: Boolean? = null,
    @SerializedName("message")
    var message: String? = null,
    @SerializedName("result")
    var result: Result? = null
) {
    data class Result(
        @SerializedName("displayName")
        var displayName: String? = null,
        @SerializedName("email")
        var email: String? = null,
        @SerializedName("ip")
        var ip: String? = null,
        @SerializedName("roles")
        var roles: List<String?>? = null,
        @SerializedName("username")
        var username: String? = null
    )
}