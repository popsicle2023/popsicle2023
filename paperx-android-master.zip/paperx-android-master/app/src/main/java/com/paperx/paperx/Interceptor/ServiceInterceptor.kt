package com.diyabet.diyabetgunlugum.Interceptor

import android.content.Context
import com.orhanobut.hawk.Hawk
import com.paperx.paperx.util.Constant
import com.paperx.paperx.util.LocalDataManager
import com.paperx.paperx.util.PaperxSingleton
import okhttp3.Interceptor
import okhttp3.Response

class ServiceInterceptor : Interceptor {


    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()

        if(request.header("No-Authentication") == null){
            if(PaperxSingleton.token.isNotEmpty())
            {
                val finalToken = "Bearer ${PaperxSingleton.token}"
                request = request.newBuilder()
                    .addHeader("Authorization", finalToken)
                    .build()
            }
        }

        return chain.proceed(request)
    }
}