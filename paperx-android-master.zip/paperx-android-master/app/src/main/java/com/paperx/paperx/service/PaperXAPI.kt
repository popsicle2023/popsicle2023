package com.paperx.paperx.service


import com.paperx.paperx.model.response.*
import com.paperx.paperx.model.response.request.LoginRequestModel
import okhttp3.MultipartBody
import retrofit2.http.*

interface PaperXAPI {

    companion object{
        const val LOGIN = "login"
        const val EXAMS = "exams"
        const val SUBMISSION = "submission"
        const val COURSES = "courses"
        const val WHOAMI = "whoami"
    }

    @POST(LOGIN)
    suspend fun userLogin(@Body loginRequestModel: LoginRequestModel) : UserLoginResponseModel

    @Headers("Content-Type: application/json")
    @GET(EXAMS) //@Query("_project") project: String
    suspend fun exams() : ExamNewResponse

    @Multipart
    @POST(SUBMISSION)
    suspend fun submission(@Part submissions: List<MultipartBody.Part>) : SubmissionResponse

    @GET(COURSES)
    suspend fun courses() : CourseListResponse

    @POST(WHOAMI)
    suspend fun whoami() : WhoamiResponse
}