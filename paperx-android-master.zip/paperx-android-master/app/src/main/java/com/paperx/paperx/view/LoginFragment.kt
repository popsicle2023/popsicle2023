package com.paperx.paperx.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.google.android.material.snackbar.Snackbar
import com.orhanobut.hawk.Hawk
import com.paperx.paperx.R
import com.paperx.paperx.databinding.FragmentLoginBinding
import com.paperx.paperx.model.response.request.LoginRequestModel
import com.paperx.paperx.util.Constant
import com.paperx.paperx.util.LocalDataManager
import com.paperx.paperx.util.PaperxSingleton
import com.paperx.paperx.util.observerLiveData
import com.paperx.paperx.viewmodel.LoginViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginFragment : Fragment() {

    private lateinit var binding: FragmentLoginBinding
    private val loginViewModel: LoginViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLoginBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            edtEmail.setText("testOgrenci")
            edtPassword.setText("12345")
            btnLogin.setOnClickListener {
                if (formValidation()){
                    val loginRequestModel = LoginRequestModel().apply {
                        unameOrEmail = edtEmail.text.toString()
                        password = edtPassword.text.toString()
                    }
                    loginViewModel.login(loginRequestModel = loginRequestModel)
                }
            }
            loginViewModel.loginLiveData.observe(viewLifecycleOwner){
                it?.let {
                    if (it.code == 0){
                        PaperxSingleton.token = it.result?.token.toString()
                        //localDataManager.setSharedPreference(requireContext(), Constant.TOKEN, it.result?.token.toString())
                        Navigation.findNavController(view).navigate(R.id.action_loginFragment_to_mainFragment)
                    }else{
                        Snackbar.make(view, it.message.toString(), Snackbar.LENGTH_LONG).show()
                    }
                }
            }
            loginViewModel.errorMessage.observerLiveData(viewLifecycleOwner, requireContext())

        }
    }

    fun formValidation() : Boolean{
        var isValid = true
        binding.apply {
            if (edtEmail.text?.isEmpty() == true){
                isValid = false
                edtEmail.setError("Please do not leave blank")
            }
            if (edtPassword.text?.isEmpty() == true){
                isValid = false
                edtPassword.setError("Please do not leave blank")
            }
        }
        return isValid
    }
}