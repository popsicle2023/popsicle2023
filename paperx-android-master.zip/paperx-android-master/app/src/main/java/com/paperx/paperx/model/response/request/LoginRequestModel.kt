package com.paperx.paperx.model.response.request

data class LoginRequestModel(
    var unameOrEmail: String? = null,
    var password: String? = null,
)
