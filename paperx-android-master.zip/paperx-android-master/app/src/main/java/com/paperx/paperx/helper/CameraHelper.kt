package com.paperx.paperx.helper

import android.content.Context
import android.net.Uri
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.github.dhaval2404.imagepicker.util.FileUriUtils
import com.mobven.kocailem.helpers.OnFileChooseListener
import com.paperx.paperx.R
import com.paperx.paperx.util.PermissionUtils.takePhoto
import id.zelory.compressor.Compressor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File


class CameraHelper(context: Context) {

    lateinit var takePhotoResultLauncher: ActivityResultLauncher<Uri>
    val takenImageUri by lazy {
        FileProvider.getUriForFile(
            context,
            context.getString(R.string.file_provider),
            FileUtils.createImageFile(context)
        )
    }

    fun init(activity: Fragment, onFileChooseListener: OnFileChooseListener) {
        initTakePhotoResultLauncher(activity, onFileChooseListener)
    }

    private fun initTakePhotoResultLauncher(activity: Fragment, onFileChooseListener: OnFileChooseListener) {
        takePhotoResultLauncher = activity.takePhoto { isSuccess ->
            if (isSuccess) {
                val fileList = arrayListOf<File>()
                CoroutineScope(Dispatchers.Main).launch {
                    val compressedImageFile = Compressor.compress(activity.requireContext(), File(FileUriUtils.getRealPath(activity.requireContext(), takenImageUri)))
                    fileList.add(compressedImageFile)
                    onFileChooseListener.onFilesSelected(fileList, false)
                }

            }
        }
    }


}