package com.paperx.paperx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.paperx.paperx.R
import com.paperx.paperx.model.response.ImageAndOutlinesModel
import kotlinx.android.synthetic.main.selected_image_and_outlines_list_layout.view.*

class ImageAndOutlinesSelectedListAdapter : RecyclerView.Adapter<ImageAndOutlinesSelectedListAdapter.MessageVieHolder>() {

    private var imageAndOutlineList: ArrayList<ImageAndOutlinesModel> = arrayListOf()
    var removeItemClickListener: (ImageAndOutlinesModel) -> Unit = { _->}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MessageVieHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.selected_image_and_outlines_list_layout, parent, false)
    )

    override fun onBindViewHolder(holder: ImageAndOutlinesSelectedListAdapter.MessageVieHolder, position: Int) {
        holder.bind(imageAndOutlineList[position])
    }

    override fun getItemCount() = imageAndOutlineList.size

    inner class MessageVieHolder(view: View) :  RecyclerView.ViewHolder(view){
        fun bind(item: ImageAndOutlinesModel) {
            itemView.image_preview.setImageURI(item.uri)
            itemView.tv_select_outlines.text = item.outlineList.toString()
            itemView.pay.setOnClickListener {
                removeItemClickListener(item)
            }
        }
    }

    fun setSelectedOutlines(outlineAndImageList: ArrayList<ImageAndOutlinesModel>){
        imageAndOutlineList.clear()
        imageAndOutlineList.addAll(outlineAndImageList)
        notifyDataSetChanged()
    }
}
