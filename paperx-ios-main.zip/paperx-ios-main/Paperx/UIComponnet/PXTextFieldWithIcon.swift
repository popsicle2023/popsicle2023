//
//  PXTextFieldWithIcon.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import SkyFloatingLabelTextField
import UIKit

@IBDesignable public class PXTextFieldWithIcon: SkyFloatingLabelTextFieldWithIcon {
    public init() {
        super.init(frame: .zero)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    @IBInspectable public var image: String?

    func setup() {
        font = UIFont.getFont(family: PaperxFontsFamily.medium, size: 16.0)
        lineHeight = 2.0
        selectedLineHeight = 2.0
        selectedLineColor = .blue
        lineColor = .gray
        textColor = .blue
        selectedTitleColor = .blue
        titleColor = .gray
        placeholderColor = .gray
        iconImage = UIImage(named: image.stringValue)
        titleFormatter = { (text: String) -> String in
            text
        }
        errorLabel = UILabel(frame: CGRect(
            x: lineView.frame.origin.x,
            y: lineView.frame.origin.y + 5,
            width: lineView.frame.width,
            height: 13 * AppConstant.heightRate
        ))
        errorLabel.font = UIFont.getFont(family: .regular, size: 13)
        errorLabel.textColor = .red
        errorLabel.text = ""
        addSubview(errorLabel)
    }

    var selectedTextColor: UIColor {
        .blue
    }

    override public func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }

    override open func becomeFirstResponder() -> Bool {
        let result = super.becomeFirstResponder()
        changeErrorUI()
        return result
    }

    override public func resignFirstResponder() -> Bool {
        let result = super.resignFirstResponder()
        changeErrorUI()
        return result
    }

    public func changeErrorUI() {
        errorLabel?.text = ""
        placeholderColor = selectedTitleColor
        lineColor = selectedLineColor
        textColor = selectedTextColor
        errorMessage = ""
    }

    override public func layoutSubviews() {
        super.layoutSubviews()
        errorLabel?.frame = CGRect(
            x: lineView.frame.origin.x,
            y: lineView.frame.origin.y + 5,
            width: lineView.frame.width,
            height: 13 * AppConstant.heightRate
        )
    }
}
