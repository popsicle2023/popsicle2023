//
//  UIViewControllerExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 7.02.2023.
//

import UIKit

public extension UIViewController {
    func showErrorMessage(_ error: Error) {
        showMessage(title: "Warning", message: error.localizedDescription, actionTitle: "Ok")
    }

    func showErrorMessage(_ message: String) {
        showMessage(title: "Warning", message: message, actionTitle: "Ok")
    }
    
    func showSuccesMessage(_ message: String) {
        showMessage(title: "", message: message, actionTitle: "Ok")
    }

    func showMessage(
        title: String,
        message: String,
        actionTitle: String,
        action: Alert.Button.AlertAction? = nil
    ) {
        let alert = Alert(title: title, message: message)
        alert.addAction(.init(title: actionTitle, type: .destructive, action: action))
        alert.present(over: self)
    }
}
