//
//  AlertViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 7.02.2023.
//

import SnapKit
import UIKit

public final class Alert {
    // swiftlint:disable nesting
    public struct Button {
        var title: String
        var type: Button.ActionType
        var defaultTitleColor: UIColor?
        var action: AlertAction?
        var borderColor: UIColor?
        var backgroundColor: UIColor?

        public init(
            title: String,
            type: Button.ActionType,
            titleColor: UIColor? = .solidSecondaryS70,
            borderColor: UIColor? = .clear,
            backgroundColor: UIColor? = .clear,
            action: AlertAction? = nil
        ) {
            self.title = title
            self.type = type
            defaultTitleColor = titleColor
            self.borderColor = borderColor
            self.backgroundColor = backgroundColor
            self.action = action
        }

        public enum ActionType {
            case `default`, destructive, custom
        }

        public typealias AlertAction = (Button) -> Void
    }

    // swiftlint:enable nesting

    var icon: UIImage?
    var title: String
    var message: String
    var titleFont: UIFont?
    var buttons: [Button] = []
    var attributedMessage: NSAttributedString?
    var messageTapHandler: (() -> Void)?

    public init(
        icon: UIImage? = nil,
        title: String,
        message: String,
        titleFont: UIFont? = nil,
        attributedMessage: NSAttributedString? = nil,
        messageTapHandler: (() -> Void)? = nil
    ) {
        self.icon = icon
        self.title = title
        self.message = message
        self.titleFont = titleFont
        self.attributedMessage = attributedMessage
        self.messageTapHandler = messageTapHandler
    }

    public func addAction(_ button: Button) {
        buttons.append(button)
    }

    public func present(over viewController: UIViewController, animated: Bool = true, completion: (() -> Void)? = nil) {
        guard let controller = UIStoryboard(name: "Alert", bundle: Bundle.main)
            .instantiateViewController(withIdentifier: "AlertViewController") as? AlertViewController else {return}
        controller.alertIcon = icon
        controller.alertTitle = title
        controller.alertMessage = message
        controller.titleFont = titleFont
        controller.alertButtons = buttons
        controller.attributedMessage = attributedMessage
        controller.messageTapHandler = messageTapHandler
        controller.modalPresentationStyle = .overFullScreen
        controller.modalTransitionStyle = .crossDissolve
        viewController.present(controller, animated: animated, completion: completion)
    }
}

final class AlertViewController: UIViewController {
    @IBOutlet private var contentHeightConstraint: NSLayoutConstraint!
    @IBOutlet private var contentView: UIView!
    @IBOutlet private var scrollView: UIScrollView!
    @IBOutlet private var alertIconHeightConstraint: NSLayoutConstraint!
    @IBOutlet private var alertIconImage: UIImageView!
    @IBOutlet private var alertTitleLabel: UILabel!
    @IBOutlet private var alertMessageLabel: UILabel!
    @IBOutlet private var buttonsStackView: UIStackView!

    fileprivate var alertIcon: UIImage?
    fileprivate var alertTitle: String!
    fileprivate var titleFont: UIFont?
    fileprivate var alertMessage: String!
    fileprivate var alertButtons: [Alert.Button]!
    fileprivate var messageTapHandler: (() -> Void)?
    fileprivate var attributedMessage: NSAttributedString?

    @IBInspectable private var imageContainerHeight: CGFloat = 120
    @IBInspectable private var buttonHeight: CGFloat = 40
    @IBInspectable private var buttonCornerRadius: CGFloat = 20

    override func viewDidLoad() {
        super.viewDidLoad()
        alertIconHeightConstraint.constant = alertIcon == nil ? 0 : imageContainerHeight
        alertIconImage.image = alertIcon
        alertTitleLabel.text = alertTitle
        if let font = titleFont {
            alertTitleLabel.font = font
        }
        alertMessageLabel.text = alertMessage
        if let attributedMessage {
            alertMessageLabel.attributedText = attributedMessage
        }
        setButtons()
        contentView.alpha = 0
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak self] in
            self?.setContentHeight()
        }
        if messageTapHandler != nil {
            alertMessageLabel.isUserInteractionEnabled = true
            alertMessageLabel.addGestureRecognizer(
                UITapGestureRecognizer(target: self, action: #selector(didTapMessage(_:)))
            )
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }

    func setContentHeight() {
        UIView.animate(withDuration: 0.25) { [weak self] in
            guard let self else { return }
            self.contentView.alpha = 1.0
            let maxContentHeight = UIScreen.main.bounds.height - 50
            if self.scrollView.contentSize.height > maxContentHeight {
                self.contentHeightConstraint.constant = maxContentHeight
            } else {
                self.contentHeightConstraint.constant = self.scrollView.contentSize.height
            }
            if self.contentHeightConstraint.constant == 0 {
                print("contentHeightConstraint value found zero. Dismissing AlertViewController")
                self.dismiss(animated: false, completion: nil)
            }
        }
    }

    private func setButtons() {
        for (index, alertButton) in alertButtons.enumerated() {
            let button = UIButton(frame: .init(origin: .zero, size: .init(
                width: buttonsStackView.frame.width,
                height: buttonHeight
            )))
            button.layer.cornerRadius = buttonCornerRadius
            button.setTitle(alertButton.title, for: .normal)
            button.titleLabel?.font = UIFont.getFont(family: .bold, size: 15)
            button.tag = index
            button.addTarget(self, action: #selector(selectButton(_:)), for: .touchUpInside)
            button.snp.makeConstraints { $0.height.equalTo(buttonHeight) }
            if alertButton.type == .default {
                button.backgroundColor = .clear
                button.setTitleColor(alertButton.defaultTitleColor, for: .normal)
            } else if alertButton.type == .custom {
                button.backgroundColor = alertButton.backgroundColor
                button.setBorder(width: 1, color: alertButton.borderColor ?? .clear)
                button.setTitleColor(alertButton.defaultTitleColor, for: .normal)
            } else {
                button.backgroundColor = .buttonPrimaryNormal
                button.setTitleColor(.buttonPrimaryNormalText, for: .normal)
            }
            buttonsStackView.addArrangedSubview(button)
        }
    }

    @objc private func selectButton(_ button: UIButton) {
        dismiss(animated: true) { [weak self] in
            guard let self else { return }
            self.alertButtons[button.tag].action?(self.alertButtons[button.tag])
        }
    }

    @objc func didTapMessage(_ recognizer: UITapGestureRecognizer) {
        messageTapHandler?()
    }
}

