//
//  Colors.swift
//  Paperx
//
//  Created by Eser Kucuker on 7.02.2023.
//

import UIKit

public extension UIColor {
    static var baseBackgroundDefault: UIColor { UIColor(colorName: "baseBackgroundDefault") }
    static var baseBackgroundDefaultSecondary: UIColor { UIColor(colorName: "baseBackgroundDefaultSecondary") }
    static var baseBackgroundDefaultTertiary: UIColor { UIColor(colorName: "baseBackgroundDefaultTertiary") }
    static var baseBackgroundInverse: UIColor { UIColor(colorName: "baseBackgroundInverse") }
    static var baseBackgroundInverseSecondary: UIColor { UIColor(colorName: "baseBackgroundInverseSecondary") }
    static var baseBackgroundInverseTertiary: UIColor { UIColor(colorName: "baseBackgroundInverseTertiary") }
    static var baseColorAffirmative: UIColor { UIColor(colorName: "baseColorAffirmative") }
    static var baseColorBlack: UIColor { UIColor(colorName: "baseColorBlack") }
    static var baseColorBlood: UIColor { UIColor(colorName: "baseColorBlood") }
    static var baseColorDeclarative: UIColor { UIColor(colorName: "baseColorDeclarative") }
    static var baseColorDestructive: UIColor { UIColor(colorName: "baseColorDestructive") }
    static var baseColorEverDark: UIColor { UIColor(colorName: "baseColorEverDark") }
    static var baseColorInformative: UIColor { UIColor(colorName: "baseColorInformative") }
    static var baseColorPrimary: UIColor { UIColor(colorName: "baseColorPrimary") }
    static var baseColorSecondary: UIColor { UIColor(colorName: "baseColorSecondary") }
    static var baseColorTheme: UIColor { UIColor(colorName: "baseColorTheme") }
    static var baseColorWhite: UIColor { UIColor(colorName: "baseColorWhite") }
    static var baseForegroundDefault: UIColor { UIColor(colorName: "baseForegroundDefault") }
    static var baseForegroundDefaultSecondary: UIColor { UIColor(colorName: "baseForegroundDefaultSecondary") }
    static var baseForegroundDefaultTertiary: UIColor { UIColor(colorName: "baseForegroundDefaultTertiary") }
    static var baseForegroundInverse: UIColor { UIColor(colorName: "baseForegroundInverse") }
    static var baseForegroundInverseSecondary: UIColor { UIColor(colorName: "baseForegroundInverseSecondary") }
    static var baseForegroundInverseTertiary: UIColor { UIColor(colorName: "baseForegroundInverseTertiary") }
    static var baseObjectChevronDefault: UIColor { UIColor(colorName: "baseObjectChevronDefault") }
    static var baseObjectChevronInverse: UIColor { UIColor(colorName: "baseObjectChevronInverse") }
    static var baseObjectSeperatorDefault: UIColor { UIColor(colorName: "baseObjectSeperatorDefault") }
    static var baseObjectSeperatorInverse: UIColor { UIColor(colorName: "baseObjectSeperatorInverse") }
    static var baseOverlayBlurDefault: UIColor { UIColor(colorName: "baseOverlayBlurDefault") }
    static var baseOverlayBlurInverse: UIColor { UIColor(colorName: "baseOverlayBlurInverse") }
    static var baseOverlayDimDefault: UIColor { UIColor(colorName: "baseOverlayDimDefault") }
    static var baseOverlayDimInverse: UIColor { UIColor(colorName: "baseOverlayDimInverse") }
    static var buttonDefaultNormal: UIColor { UIColor(colorName: "buttonDefaultNormal") }
    static var solidSecondaryS70: UIColor { UIColor(colorName: "solidSecondaryS70") }
    static var baseForegroundDefaultText: UIColor { UIColor(colorName: "baseForegroundDefaultText") }
    static var buttonPrimaryNormal: UIColor { UIColor(colorName: "buttonPrimaryNormal") }
    static var buttonPrimaryNormalText: UIColor { UIColor(colorName: "buttonPrimaryNormalText") }
    static var buttonPrimaryDisable: UIColor { UIColor(colorName: "buttonPrimaryDisable") }
    static var solidDeclarativeS20: UIColor { UIColor(colorName: "solidDeclarativeS20") }
    static var solidDeclarativeS60: UIColor { UIColor(colorName: "solidDeclarativeS60") }
    static var solidPrimaryS20: UIColor { UIColor(colorName: "solidPrimaryS20") }
    static var buttonDefaultNormalstroke: UIColor { UIColor(colorName: "buttonDefaultNormalstroke") }
    static var inputRegularNormal: UIColor { UIColor(colorName: "inputRegularNormal") }
    static var buttonDestructiveNormal: UIColor { UIColor(colorName: "buttonDestructiveNormal") }
    static var buttonDestructiveNormalStroke: UIColor { UIColor(colorName: "buttonDestructiveNormalStroke") }
    static var baseForegroundInverseText: UIColor { UIColor(colorName: "baseForegroundInverseText") }
    static var solidPrimaryS60: UIColor { UIColor(colorName: "solidPrimaryS60") }
    static var inputRegularAlternate: UIColor { UIColor(colorName: "inputRegularAlternate") }
    static var solidSecondaryS30: UIColor { UIColor(colorName: "solidSecondaryS30") }
    static var baseForegroundDefaultSecondaryText: UIColor { UIColor(colorName: "baseForegroundDefaultSecondaryText") }
    static var baseElevationDExclusive: UIColor { UIColor(colorName: "baseElevationDExclusive") }
    static var buttonDeclarativeNormaltext: UIColor { UIColor(colorName: "buttonDeclarativeNormaltext") }
    static var inputRegularNormalStroke: UIColor { UIColor(colorName: "inputRegularNormalStroke") }
    static var solidPrimaryS70: UIColor { UIColor(colorName: "solidPrimaryS70") }
    static var dropShadow: UIColor { UIColor(colorName: "dropShadow") }
    static var solidSecondaryS40: UIColor { UIColor(colorName: "solidSecondaryS40") }
    static var buttonDefaultNormalText: UIColor { UIColor(colorName: "buttonDefaultNormalText") }
    static var baseElevationDButton: UIColor { UIColor(colorName: "baseElevationD-Button") }
    static var inputFloatingNormalStroke: UIColor { UIColor(colorName: "inputFloatingNormalStroke") }
    static var solidAffirmativeS10: UIColor { UIColor(colorName: "solidAffirmativeS10") }
    static var solidAffirmativeS60: UIColor { UIColor(colorName: "solidAffirmativeS60") }
    static var inputRegularFocusStroke: UIColor { UIColor(colorName: "inputRegularFocusStroke") }
    static var buttonPrimaryDisableText: UIColor { UIColor(colorName: "buttonPrimaryDisableText") }
    static var buttonDestructiveNormalText: UIColor { UIColor(colorName: "buttonDestructiveNormalText") }
    static var buttonDestructiveDisable: UIColor { UIColor(colorName: "buttonDestructiveDisable") }
    static var buttonDestructiveDisableStroke: UIColor { UIColor(colorName: "buttonDestructiveDisableStroke") }
    static var solidSecondaryS60: UIColor { UIColor(colorName: "solidSecondaryS60") }
    static var baseElevationE5030: UIColor { UIColor(colorName: "baseElevationE5030") }
    static var buttonInformativeNormalText: UIColor { UIColor(colorName: "buttonInformativeNormalText") }
    static var baseColorKanBankasiBottom: UIColor { UIColor(colorName: "baseColorKanBankasiBottom") }
    static var baseColorKanBankasiTop: UIColor { UIColor(colorName: "baseColorKanBankasiTop") }
}
public extension UIColor {
    convenience init(colorName: String) {
        if #available(iOS 13.0, *) {
            self.init(named: colorName, in: Bundle.main, compatibleWith: .current)!
        } else {
            self.init(named: colorName, in: Bundle.main, compatibleWith: nil)!
        }
    }
}
