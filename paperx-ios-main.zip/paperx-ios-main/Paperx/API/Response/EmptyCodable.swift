//
//  EmptyCodable.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct EmptyCodable: Codable {
    public let code: Int
    public let message: String
    public let isShowMessage: Bool
    public let result: Result?
    
    public struct Result: Codable {}
}
