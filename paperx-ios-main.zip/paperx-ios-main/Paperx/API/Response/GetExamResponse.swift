//
//  GetExamResponse.swift
//  Paperx
//
//  Created by Eser Kucuker on 16.03.2023.
//

import Foundation

struct GetExamResponse: Codable {
    let code: Int?
    let message: String?
    let isShowMessage: Bool?
    let result: Response?
}

// MARK: - Result
struct Response: Codable {
    let id: String?
    let allowLateSubmissions: [String]?
    let name: String?
    let isPublished, isRegrades, fileVisibility, isEnabledGroupSubmission: Bool?
    let groupSubmissionLimit: Int?
    let uploadSubmissions, startTime, endTime, submissionType: String?
    let lateTime: String?
    let shareInstructors, shareStudents, shareTAs: Bool?
    let type: String?
    let files: [File]?
    let status, defaultRubricType: String?
    let defaultScoreBonds: [String]?
    let applyAll: Bool?
    let selectionStyle, studentVisibility: String?
    let outlines: [Outline]?
    let passive: Bool?
    let submissions: [Submission]?
    let startDate, endDate, lateDate: String?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case allowLateSubmissions, name, isPublished, isRegrades, fileVisibility, isEnabledGroupSubmission, groupSubmissionLimit, uploadSubmissions, startTime, endTime, submissionType, lateTime, shareInstructors, shareStudents, shareTAs, type, files, status, defaultRubricType, defaultScoreBonds, applyAll, selectionStyle, studentVisibility, outlines, passive, submissions, startDate, endDate, lateDate
    }
}

// MARK: - File
struct File: Codable {
    let id, name, originalName, path: String?
    let encoding, mimeType: String?
    let size: Int?
    let sizeType: String?
    let duration: Int?
    let durationType: String?
}

// MARK: - Outline
struct Outline: Codable {
    let title: String?
    let point: Int?
    let childs: [Child]?
}

// MARK: - Child
struct Child: Codable {
    let title: String?
    let point: Int?
}


// MARK: - Submission
struct Submission: Codable {
    let id, user: String?
}
