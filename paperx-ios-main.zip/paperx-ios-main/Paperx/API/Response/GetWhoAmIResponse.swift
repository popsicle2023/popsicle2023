//
//  GetWhoAmIResponse.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct GetWhoAmIResponse: Codable {
    public let code: Int
    public let message: String
    public let isShowMessage: Bool
    public let result: Result?
    
    
    // MARK: - Result
    public struct Result: Codable {
        public let id, username, displayName, email: String?
        public let roles: [String]?
        public let requirePasswordChange: Bool?
        public let ip: String?
    }
}
