//
//  GetCourseResponse.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct GetCourseResponse: Codable {
    public var data: [Datum]?
}

// MARK: - Datum

public struct Datum: Codable {
    public var id, schoolName, departmentName, name: String?
    public var startTime, endTime: String?
    public var grades: [Grade]?
    public var assignedTAs: [AssignedTA]?
    public var stamp: Stamp?
    public var passive: Bool?
    public var exams: [Exam]?
    public var printeds: [Printed]?
    public var startDate, endDate: String?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case schoolName, departmentName, name, startTime, endTime, grades, assignedTAs, stamp, passive, exams, printeds, startDate, endDate
    }
}

// MARK: - AssignedTA

public struct AssignedTA: Codable {
    public var id, username: String?
}

// MARK: - Exam

public struct Exam: Codable {
    public var id, name: String?
}

// MARK: - Grade

public struct Grade: Codable {
    public var type: TypeEnum?
    public var distribution: Int?
}

public enum TypeEnum: String, Codable {
    case finalExam = "Final Exam"
    case homework = "Homework"
    case midtermExam = "Midterm Exam"
    case quizzes = "Quizzes"
}

// MARK: - Printed

public struct Printed: Codable {
    public var id, name, originalName, path: String?
    public var encoding, mimeType: String?
    public var size: Int?
    public var sizeType: String?
    public var duration: Int?
    public var durationType: String?
}

// MARK: - Stamp

public struct Stamp: Codable {
    public var createAt, username, email, displayName: String?
    public var ip: String?
}
