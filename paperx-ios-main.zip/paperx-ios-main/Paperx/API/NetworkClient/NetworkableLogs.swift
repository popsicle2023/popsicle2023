//
//  NetworkableLogs.swift
//  Paperx
//
//  Created by Eser Kucuker on 12.01.2023.
//

import Foundation

extension Networkable {
    func printResponse(_ data: Data?, _ request: PaperxRequest) {
        
            print("\n")
            print("<-------- MarketNetworking -------->")
            print("Action: \(request.action)")
            print("Headers: \(request.header)")
            print("Request Body:")
            printData(request.body)
            print("\n")
            print("Response Body:")
            printData(data)
            print("<-------- MarketNetworking -------->")
            print("\n")
        }
    
    private func printData(_ data: Data?) {
        if let data = data {
            if let jsonObject = try? JSONSerialization.jsonObject(with: data, options: .allowFragments),
               let json = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted),
               let string = String(data: json, encoding: .utf8) {
                print(string)
            } else if let string = String(data: data, encoding: .utf8) {
                print(string)
            }
        }
    }

    private func printData(_ body: [String: Any]?) {
        if let body = body {
            if let json = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted),
               let string = String(data: json, encoding: .utf8) {
                print(string)
            }
        }
    }
}
