//
//  Authentication.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public final class Authentication {
    public static let shared = Authentication()
    public let token = UserDefaults(suiteName: "token")

    public func getTokenValue() -> String? {
        guard let value = token?.string(forKey: "token") else { return "" }
        return value
    }
}
