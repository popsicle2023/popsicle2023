//
//  Networkable.swift
//  Paperx
//
//  Created by Eser Kucuker on 12.01.2023.
//

import Alamofire
import Foundation

public protocol Networkable {
    var request: PaperxRequest { get }
    func fetchResponse<V: Decodable>(_ vtype: V.Type, completion: @escaping (Result<V, Error>) -> Void)
}

public extension Networkable {
    func getResult(
        onSuccess: @escaping (_ result: Data) -> Void,
        onError: @escaping (_ error: Error) -> Void
    ) {
        AF.request(request.action, method: request.httpMethod.method, parameters: request.body).responseData { response in
            switch response.result {
            case let .success(responseData):
                onSuccess(responseData)
            case let .failure(error):
                onError(error)
            }
        }
    }

    func fetchResponse<V: Decodable>(_ vtype: V.Type, completion: @escaping (Result<V, Error>) -> Void) {
        getResult { result in
            do {
                printResponse(result, request)
                let response = try JSONDecoder().decode(V.self, from: result)
                completion(.success(response))
            } catch {
                completion(.failure(error))
            }
        } onError: { error in
            completion(.failure(error))
        }
    }

    func upluadImage(
        onSuccess: @escaping (_ result: Data) -> Void,
        onError: @escaping (_ error: Error) -> Void
    ) {
        let headers: HTTPHeaders = [
            "Content-type": "multipart/form-data",
        ]
        AF.upload(
            multipartFormData: { multipartFormData in

                // multipartFormData.append(request.file, withName: "submissions")

                multipartFormData.append(request.file.first?.data ?? Data(), withName: "submissions", fileName: request.file.first?.fileName, mimeType: request.file.first?.mimeType)
                for (key, value) in request.body {
                    if value as! String ==  "exam"{
                        multipartFormData.append(Data(key.utf8), withName: "exam")
                    } else {
                        multipartFormData.append(Data(key.utf8), withName: "outlineTitles")
                    }
                }
            },
            to: request.action, method: request.httpMethod.method, headers: headers
        )
        .response { response in
            switch response.result {
            case let .success(responseData):
                onSuccess(responseData!)
            case let .failure(error):
                onError(error)
            }
        }
    }

    func fetchUpdateImagee<V: Decodable>(_ vtype: V.Type, completion: @escaping (Result<V, Error>) -> Void) {
        upluadImage { result in
            do {
                printResponse(result, request)
                let response = try JSONDecoder().decode(V.self, from: result)
                completion(.success(response))
            } catch {
                completion(.failure(error))
            }
        } onError: { error in
            completion(.failure(error))
        }
    }

    internal func getRequest(
        action: String,
        requestBody: [String: Any] = [:],
        requestHeader: [String: String] = [:],
        httpMethod: APIHttpMethod = .post,
        file: [Files] = []
    ) -> PaperxRequest {
        PaperxRequest(
            action: action,
            body: requestBody,
            header: requestHeader,
            httpMethod: httpMethod,
            file: file
        )
    }
}
