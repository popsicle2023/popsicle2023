//
//  PaperxResponse.swift
//  Paperx
//
//  Created by Eser Kucuker on 12.01.2023.
//

import Foundation

public struct PaperxResponse<T: Decodable>: Decodable {
    
    public var result: T?
    public var message: String?
    public var code: Int?
    public var isShowMessage: Bool?

    var error: Error {
        let errorMessage = message ?? "Something went worng"
        return NSError.error(with: errorMessage)
    }

    public init(result: T) {
        self.result = result
    }

    public init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        result = (try? container?.decodeIfPresent(T.self, forKey: .result))
        message = (try? container?.decodeIfPresent(String.self, forKey: .message))
        code = (try? container?.decodeIfPresent(Int.self, forKey: .code))
        isShowMessage = (try? container?.decodeIfPresent(Bool.self, forKey: .isShowMessage))
    }

    enum CodingKeys: String, CodingKey {
        case result
        case message
        case code
        case isShowMessage
    }
}

extension NSError {
    static func error(with localizedDescription: String) -> NSError {
        NSError(domain: "", code: genericErrorCode, userInfo: [NSLocalizedDescriptionKey: localizedDescription])
    }
}

public extension Error {
    static var genericErrorCode: Int {
        -2
    }
}
