//
//  PaperxRequest.swift
//  Paperx
//
//  Created by Eser Kucuker on 12.01.2023.
//

import Alamofire
import Foundation

enum APIHttpMethod {
    case get, post, put, delete
    var method: HTTPMethod {
        switch self {
        case .get: return .get
        case .post: return .post
        case .put: return .put
        case .delete: return .delete
        }
    }
}

public struct PaperxRequest {
    let action: String
    let body: [String: Any]
    let header: [String: String]
    let httpMethod: APIHttpMethod
    let file: [Files]

    init(
        action: String,
        body: [String: Any],
        header: [String: String],
        httpMethod: APIHttpMethod,
        file: [Files]
    ) {
        self.action = action
        self.body = body
        self.header = header
        self.httpMethod = httpMethod
        self.file = file
    }
}
