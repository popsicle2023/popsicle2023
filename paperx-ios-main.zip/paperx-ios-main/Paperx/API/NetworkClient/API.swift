//
//  API.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public enum PaperxAPI {
    static func getURL(with trail: String = "") -> String {
        "\(Bundle.main.infoForKey("BASE_URL") ?? "")\(trail)"
    }

    static func getHeaders() -> [String: String] {
        var headers: [String: String] = [:]
        if let token = Authentication.shared.getTokenValue() {
            headers["Authorization"] = "Bearer \(token)"
        }
        return headers
    }
}
