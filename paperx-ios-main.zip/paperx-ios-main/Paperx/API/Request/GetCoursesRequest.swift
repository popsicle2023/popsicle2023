//
//  GetCoursesRequest.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct GetCoursesRequest {
    func body() -> [String: Any] {
        [
            "_project": "assignedTAs,videos,printeds",
        ]
    }
}
