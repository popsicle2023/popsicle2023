//
//  GetExamsRequest.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct GetExamsRequest {
    func body() -> [String: Any] {
        [
            "_project": "submissions,name,startDate,endDate",
        ]
    }
}
