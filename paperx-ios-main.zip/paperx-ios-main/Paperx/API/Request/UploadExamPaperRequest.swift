//
//  UploadExamPaperRequest.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation

public struct UploadExamPaperRequest {
    public struct UploadFile {
        public var name: String
        public var fileExtension: String
        public var mimeType: String
        public var data: Data

        public init(name: String, fileExtension: String, mimeType: String, data: Data) {
            self.name = name
            self.fileExtension = fileExtension
            self.mimeType = mimeType
            self.data = data
        }
    }

    public var parameters: [String: String]
    internal var files: [Files]

    public init(parameters: [String: String], files: [UploadFile]) {
        self.parameters = parameters
        self.files = files.compactMap {
            Files(name: "\($0.name).\($0.fileExtension)", fileName: "\($0.name).\($0.fileExtension)", fileExtension: $0.fileExtension, mimeType: $0.mimeType, data: $0.data)
        }
    }
}
