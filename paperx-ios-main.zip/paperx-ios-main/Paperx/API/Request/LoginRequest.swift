//
//  LoginRequest.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public struct LoginRequest {
    public var unameOrEmail: String?
    public var password: String?

    public init(unameOrEmail: String? = "superUser",
                password: String? = "1q2w3e4r5t6y7u")
    {
        self.unameOrEmail = unameOrEmail
        self.password = password
    }

    func body() -> [String: Any] {
        [
            "password": password ?? "",
            "unameOrEmail": unameOrEmail ?? "",
        ]
    }
}
