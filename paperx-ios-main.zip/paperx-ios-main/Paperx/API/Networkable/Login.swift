//
//  Login.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public extension PaperxAPI {
    enum Login: Networkable {
        case startAuth(request: LoginRequest)

        public var request: PaperxRequest {
            switch self {
            case let .startAuth(request):
                return getRequest(
                    action: PaperxAPI.getURL(with: "login"),
                    requestBody: request.body(),
                    httpMethod: .post
                )
            }
        }
    }
}
