//
//  UploadExamPage.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation

public extension PaperxAPI {
    enum UploadExamPge: Networkable {
        case uploadExamPage(request: UploadExamPaperRequest)

        public var request: PaperxRequest {
            switch self {
            case let .uploadExamPage(request):
                return getRequest(
                    action: PaperxAPI.getURL(with: "submission"),
                    requestBody: request.parameters,
                    httpMethod: .post,
                    file: request.files
                )
            }
        }
    }
}
