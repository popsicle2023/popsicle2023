//
//  GetCourses.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public extension PaperxAPI {
    enum GetCourses: Networkable {
        case getCourses

        public var request: PaperxRequest {
            switch self {
            case .getCourses:
                return getRequest(
                    action: PaperxAPI.getURL(with: "courses"),
                    requestBody: [:],
                    httpMethod: .get
                )
            }
        }
    }
}
