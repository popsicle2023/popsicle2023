//
//  GetExems.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public extension PaperxAPI {
    enum GetExems: Networkable {
        case GetExems(request: GetExamsRequest)
        case getExemByID(request: String)

        public var request: PaperxRequest {
            switch self {
            case let .GetExems(request):
                return getRequest(
                    action: PaperxAPI.getURL(with: "exams"),
                    requestBody: request.body(),
                    httpMethod: .get
                )
            case let .getExemByID(request):
                return getRequest(
                    action: PaperxAPI.getURL(with: "exam/\(request)"),
                    requestHeader: PaperxAPI.getHeaders(),
                    httpMethod: .get
                )
            }
        }
    }
}
