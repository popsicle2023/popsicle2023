//
//  UIImageExtension.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import UIKit

public extension UIImage {
    convenience init?(named: String, in bundle: Bundle) {
        if #available(iOS 13.0, *) {
            self.init(named: named, in: bundle, compatibleWith: .current)
        } else {
            self.init(named: named, in: bundle, compatibleWith: nil)
        }
    }

    // swiftlint:disable function_body_length cyclomatic_complexity
    func rotateCameraImageToProperOrientation(maxResolution: CGFloat = 1024) -> UIImage? {
        guard let imgRef = cgImage else {
            return nil
        }

        let width = CGFloat(imgRef.width)
        let height = CGFloat(imgRef.height)

        var bounds = CGRect(x: 0, y: 0, width: width, height: height)

        var scaleRatio: CGFloat = 1
        if width > maxResolution || height > maxResolution {
            scaleRatio = min(maxResolution / bounds.size.width, maxResolution / bounds.size.height)
            bounds.size.height *= scaleRatio
            bounds.size.width *= scaleRatio
        }

        var transform = CGAffineTransform.identity
        let orient = imageOrientation
        let imageSize = CGSize(width: CGFloat(imgRef.width), height: CGFloat(imgRef.height))

        switch imageOrientation {
        case .up:
            transform = .identity
        case .upMirrored:
            transform = CGAffineTransform(translationX: imageSize.width, y: 0)
                .scaledBy(x: -1.0, y: 1.0)
        case .down:
            transform = CGAffineTransform(translationX: imageSize.width, y: imageSize.height)
                .rotated(by: CGFloat.pi)
        case .downMirrored:
            transform = CGAffineTransform(translationX: 0, y: imageSize.height)
                .scaledBy(x: 1.0, y: -1.0)
        case .left:
            let storedHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = storedHeight
            transform = CGAffineTransform(translationX: 0, y: imageSize.width)
                .rotated(by: 3.0 * CGFloat.pi / 2.0)
        case .leftMirrored:
            let storedHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = storedHeight
            transform = CGAffineTransform(translationX: imageSize.height, y: imageSize.width)
                .scaledBy(x: -1.0, y: 1.0)
                .rotated(by: 3.0 * CGFloat.pi / 2.0)
        case .right:
            let storedHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = storedHeight
            transform = CGAffineTransform(translationX: imageSize.height, y: 0)
                .rotated(by: CGFloat.pi / 2.0)
        case .rightMirrored:
            let storedHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = storedHeight
            transform = CGAffineTransform(scaleX: -1.0, y: 1.0)
                .rotated(by: CGFloat.pi / 2.0)
        @unknown default:
            break
        }

        UIGraphicsBeginImageContext(bounds.size)
        if let context = UIGraphicsGetCurrentContext() {
            if orient == .right || orient == .left {
                context.scaleBy(x: -scaleRatio, y: scaleRatio)
                context.translateBy(x: -height, y: 0)
            } else {
                context.scaleBy(x: scaleRatio, y: -scaleRatio)
                context.translateBy(x: 0, y: -height)
            }

            context.concatenate(transform)
            context.draw(imgRef, in: CGRect(x: 0, y: 0, width: width, height: height))
        }

        let imageCopy = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return imageCopy
    }

    enum JPEGQuality: CGFloat {
        case lowest = 0.000001 // 0 does not change the value of the image, it should be given a value slightly above 0
        case low = 0.25
        case medium = 0.5
        case high = 0.75
        case highest = 1
    }

    func jpeg(_ jpegQuality: JPEGQuality) -> Data? {
        jpegData(compressionQuality: jpegQuality.rawValue)
    }

    // swiftlint:enable function_body_length cyclomatic_complexity
}

public class ImageWithoutRender: UIImage {
    override public func withRenderingMode(_: UIImage.RenderingMode) -> UIImage {
        self
    }
}
