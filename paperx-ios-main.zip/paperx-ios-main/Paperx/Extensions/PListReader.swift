//
//  PListReader.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public enum PListReader {
    public static func infoForKey(_ key: String) -> String? {
        Bundle.main.infoForKey(key)
    }

    public static func intForKey(_ key: String) -> Int? {
        guard let value = infoForKey(key) else {
            return nil
        }
        return Int(value)
    }

    public static func infoForCheck(_ key: String) -> Bool {
        Bundle.main.boolForKey(key)
    }
}

/// Bundle extension
public extension Bundle {
    /// Returns String value for the specified key from bundle dictionary.
    /// - Parameter key: String representing item key.
    /// - Returns: String value if exists.
    func infoForKey(_ key: String) -> String? {
        (infoDictionary?[key] as? String)?.replacingOccurrences(of: "\\", with: "")
    }

    /// Returns boolean value with specified key from bundle dictionary.
    /// - Parameter key: String representing item key.
    /// - Returns: Boolean value. If key does not exist, `false` will be returned.
    func boolForKey(_ key: String) -> Bool {
        infoForKey(key) == "YES"
    }
}
