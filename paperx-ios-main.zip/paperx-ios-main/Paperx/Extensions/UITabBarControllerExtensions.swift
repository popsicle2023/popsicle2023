//
//  UITabBarControllerExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 15.01.2023.
//

import Foundation
import UIKit

public extension UITabBarController {
    @available(iOS 13.0, *) func createAppearance() -> UITabBarAppearance {
        createAppearance(
            backgroundColor: UIColor.lightGray,
            badgeBackgroundColor: UIColor.red
        )
    }

    @available(iOS 13.0, *) func createMarketTabBarAppearance() -> UITabBarAppearance {
        createAppearance(backgroundColor: UIColor.lightGray, badgeBackgroundColor: UIColor.blue)
    }

    @available(iOS 13.0, *) func createAppearance(
        backgroundColor: UIColor,
        badgeBackgroundColor: UIColor
    ) -> UITabBarAppearance {
        let normalTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.getFont(family: .regular, size: 12),
            .foregroundColor: backgroundColor,
        ]
        let selectedTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.getFont(family: .semibold, size: 12),
            .foregroundColor: backgroundColor,
        ]

        let appearance = tabBar.standardAppearance

        let itemAppearance = appearance.inlineLayoutAppearance
        itemAppearance.normal.titleTextAttributes = normalTextAttributes
        itemAppearance.normal.badgeBackgroundColor = badgeBackgroundColor
        itemAppearance.selected.titleTextAttributes = selectedTextAttributes
        itemAppearance.selected.badgeBackgroundColor = badgeBackgroundColor

        appearance.inlineLayoutAppearance = itemAppearance
        appearance.compactInlineLayoutAppearance = itemAppearance
        appearance.stackedLayoutAppearance = itemAppearance
        appearance.backgroundColor = UIColor.clear

        return appearance
    }
}
