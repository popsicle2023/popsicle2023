//
//  CaseCountableExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 15.01.2023.
//

import Foundation

public protocol CaseCountable {
    static var caseCount: Int { get }
}

public extension CaseCountable where Self: RawRepresentable, Self.RawValue == Int {
    static var caseCount: Int {
        var count = 0
        while let _ = Self(rawValue: count) {
            count += 1
        }
        return count
    }
}
