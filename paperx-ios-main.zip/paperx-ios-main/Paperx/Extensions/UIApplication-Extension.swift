//
//  UIApplication-Extension.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation
import UIKit

public extension UIApplication {
    var rootViewController: UIViewController? {
        keyWindow?.rootViewController
    }

    func changeRootViewController(for viewController: UIViewController) {
        if let window = delegate?.window {
            window?.rootViewController = viewController
            window?.makeKeyAndVisible()
        }
    }

    @discardableResult func openURLIfAvailable(url: String) -> Bool {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
            return true
        }
        return false
    }

    /// Returns top view controller in the window.
    func topViewController(
        controller: UIViewController? = UIApplication.shared.keyWindow?.rootViewController
    ) -> UIViewController? {
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController as? UINavigationController {
                return topViewController(controller: selected.visibleViewController)
            }

            return topViewController(controller: tabController.selectedViewController)
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller
    }

    class func rootViewController() -> UIViewController? {
        UIApplication.shared.keyWindow?.rootViewController
    }

    func routeToSettings(completionHandler: ((Bool) -> Void)? = nil) {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        if canOpenURL(settingsUrl) {
            open(settingsUrl, options: [:], completionHandler: completionHandler)
        }
    }

    class func getViewController<T: UIViewController>(
        inScene named: String? = nil,
        rootViewController: Bool = true,
        in bundle: Bundle? = nil
    ) -> T {
        let controllerName = String(describing: T.self)
        let storyboardName = named ?? substringStoryboardName(withViewControllerName: controllerName)
        if rootViewController,
           let viewController = UIStoryboard(
               name: String(storyboardName), bundle: bundle
           ).instantiateInitialViewController() as? T
        {
            return viewController
        } else if let viewController = UIStoryboard(
            name: String(storyboardName), bundle: bundle
        ).instantiateViewController(withIdentifier: controllerName) as? T {
            return viewController
        } else {
            fatalError("InstantiateInitialViewController not found")
        }
    }

    private class func substringStoryboardName(withViewControllerName controllerName: String) -> String {
        let viewControllerName = controllerName
        if let range = viewControllerName.range(of: "ViewController") {
            return String(viewControllerName[..<range.lowerBound])
        } else {
            return controllerName
        }
    }
}
