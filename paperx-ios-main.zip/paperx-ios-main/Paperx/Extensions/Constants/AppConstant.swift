//
//  AppConstant.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

public enum AppConstant {
    public static let iPhone6Height: CGFloat = 667.0
    public static let iPhone6Width: CGFloat = 375.0

    public static var heightRate: CGFloat {
        let height = UIScreen.main.bounds.height / iPhone6Height
        if height > 1.0 {
            return 1.0
        }
        return height
    }

    public static var widthRate: CGFloat {
        let width = UIScreen.main.bounds.width / iPhone6Width
        if width > 1.0 {
            return 1.0
        }
        return width
    }
}
