//
//  StringExtension.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

public extension String? {
    func sendNullIfNil() -> Any {
        if let value = self, value.isEmpty {
            return NSNull()
        }
        return self == nil ? NSNull() : self!
    }

    func isNilOrEmpty() -> Bool {
        self == nil ? true : self!.isEmpty
    }

    var stringValue: String {
        self ?? ""
    }
}
