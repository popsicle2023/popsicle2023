//
//  UICollectionViewExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

public extension UICollectionView {
    func setup(cellsId: [String], bundle: Bundle) {
        cellsId.forEach { item in
            let uinib = UINib(nibName: item, bundle: bundle)
            self.register(uinib, forCellWithReuseIdentifier: item)
        }
    }

    func layoutSetup(cellsId: [String], bundle: Bundle, direction: ScrollDirection = .horizontal) {
        setup(cellsId: cellsId, bundle: bundle)
        let layout = collectionViewLayout as? UICollectionViewFlowLayout
        layout?.scrollDirection = direction
        layout?.minimumLineSpacing = 0
        decelerationRate = .fast
    }

    /// Registers a nib file for use in creating new collection view cells.
    /// Cell nib file name and identifier name should as same as the cell.
    /// - Parameters:
    ///   - type: Type of the cell.
    ///   - bundle: Bundle to be looked for the cell.
    func register(_ type: UICollectionViewCell.Type, in bundle: Bundle) {
        register(UINib(nibName: type.identifier, bundle: bundle), forCellWithReuseIdentifier: type.identifier)
    }

    /// Dequeues a reusable cell object located by its type.
    /// - Parameters:
    ///   - type: Type of the cell.
    ///   - indexPath: The index path specifying the location of the cell.
    /// - Returns: A valid UICollectionReusableView object with type specified type.
    func dequeueCell<CellType: UICollectionViewCell>(type: CellType.Type, indexPath: IndexPath) -> CellType {
        guard let cell = dequeueReusableCell(
            withReuseIdentifier: CellType.identifier, for: indexPath
        ) as? CellType else {
            fatalError("Wrong type of cell \(type)")
        }
        return cell
    }

    /**
     Clears loading in backgroundView of the UITableView.
     */
    func hideLoading() {
        if let activityIndicator = backgroundView?.subviews.first as? UIActivityIndicatorView {
            activityIndicator.stopAnimating()
        }
        backgroundView = nil
    }
}

public class SnappingCollectionViewLayout: UICollectionViewFlowLayout {
    override public func targetContentOffset(
        forProposedContentOffset proposedContentOffset: CGPoint,
        withScrollingVelocity velocity: CGPoint
    ) -> CGPoint {
        guard let collectionView else {
            return super.targetContentOffset(
                forProposedContentOffset: proposedContentOffset,
                withScrollingVelocity: velocity
            )
        }

        var offsetAdjustment = CGFloat.greatestFiniteMagnitude
        let horizontalOffset = proposedContentOffset.x + collectionView.contentInset.left

        let targetRect = CGRect(
            x: proposedContentOffset.x,
            y: 0,
            width: collectionView.bounds.size.width,
            height: collectionView.bounds.size.height
        )

        let layoutAttributesArray = super.layoutAttributesForElements(in: targetRect)

        layoutAttributesArray?.forEach { layoutAttributes in
            let itemOffset = layoutAttributes.frame.origin.x
            if fabsf(Float(itemOffset - horizontalOffset)) < fabsf(Float(offsetAdjustment)) {
                offsetAdjustment = itemOffset - horizontalOffset
            }
        }

        return CGPoint(
            x: proposedContentOffset.x + offsetAdjustment,
            y: proposedContentOffset.y
        )
    }
}
