//
//  UIButtonExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 7.02.2023.
//

import UIKit

public extension UIButton {
    @IBInspectable var adjustsFontSizeToFitWidth: Bool {
        get { titleLabel?.adjustsFontSizeToFitWidth ?? true }
        set {
            titleLabel?.adjustsFontSizeToFitWidth = newValue
            if newValue {
                titleLabel?.lineBreakMode = .byClipping
                titleLabel?.baselineAdjustment = .alignCenters
            }
        }
    }

    func setBorder(width: CGFloat, color: UIColor) {
        layer.borderWidth = width
        layer.borderColor = color.cgColor
    }
}

