//
//  UIFontExtension.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

public enum PaperxFontsFamily: String {
    case bold = "Bold", medium = "Medium", small = "Small", regular = "Regular", semibold = "Semibold"
}

public extension UIFont {
    static func getFont(family: PaperxFontsFamily, size: CGFloat = 17) -> UIFont {
        UIFont(name: "Cabin-\(family.rawValue)", size: size) ?? UIFont.systemFont(ofSize: size)
    }
}
