//
//  UIViewExtension.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

public extension UIView {
    class var identifier: String {
        String(describing: self)
    }

    func loadNib(in bundle: Bundle, nibName: String) {
        let nib = UINib(nibName: nibName, bundle: bundle)
        guard let view = (nib.instantiate(withOwner: self, options: nil).first as? UIView)
        else { return }
        view.frame = bounds
        view.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        addSubview(view)
    }

    func loadViewFromNib(_ nibName: String, bundle: Bundle) -> UIView {
        let nib = UINib(nibName: nibName, bundle: bundle)
        guard let view = (nib.instantiate(withOwner: self, options: nil)[0] as? UIView)
        else { return UIView() }
        view.frame = bounds
        view.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        return view
    }

    static func loadViewFromNib(in bundle: Bundle = Bundle.main) -> UIView? {
        let nib = UINib(nibName: String(describing: self), bundle: bundle)
        let nibObjects = nib.instantiate(withOwner: nil, options: nil)
        guard let view = nibObjects.first as? UIView else { return nil }
        return view
    }

    func setAlphaWithAnimate(_ alpha: CGFloat) {
        UIView.animate(withDuration: 0.12) {
            self.alpha = alpha
        }
    }

    func bottomCorner(width: CGFloat, height: CGFloat) {
        let path = UIBezierPath(
            roundedRect: bounds,
            byRoundingCorners: [.topRight, .bottomLeft],
            cornerRadii: CGSize(width: width, height: height)
        )

        let maskLayer = CAShapeLayer()

        maskLayer.path = path.cgPath
        layer.mask = maskLayer
    }

    func animateDamping() {
        UIView.animate(
            withDuration: 0.12,
            delay: 0.01,
            usingSpringWithDamping: 0.75,
            initialSpringVelocity: 0.5,
            options: [.curveEaseInOut],
            animations: {
                self.layoutIfNeeded()
            }
        )
    }

    func animateLayout() {
        UIView.animate(withDuration: 0.12) {
            self.layoutIfNeeded()
        }
    }

    @IBInspectable var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }

    // Note: Parameter names is equal to Zeplin.io
    func addShadowToView(
        shadowLayer: CAShapeLayer,
        x: CGFloat = 0,
        y: CGFloat = 0,
        blur: CGFloat = 0,
        spread: CGFloat = 0,
        fillColor: UIColor = UIColor.white,
        color: UIColor,
        opacity: Float,
        radius: CGFloat = 20
    ) {
        shadowLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: radius).cgPath
        shadowLayer.fillColor = fillColor.cgColor
        shadowLayer.shadowColor = color.cgColor
        shadowLayer.shadowPath = shadowLayer.path
        shadowLayer.shadowOffset = CGSize(width: x, height: y)
        shadowLayer.shadowOpacity = opacity
        shadowLayer.shadowRadius = blur
        if spread == 0 {
            layer.shadowPath = nil
        } else {
            let dx = -spread
            let rect = bounds.insetBy(dx: dx, dy: dx)
            layer.shadowPath = UIBezierPath(rect: rect).cgPath
        }
        if layer.sublayers == nil || !layer.sublayers!.contains(shadowLayer) {
            layer.insertSublayer(shadowLayer, at: 0)
        }
    }

    func setShadow() {
        layer.shadowColor = UIColor(red: 71 / 255, green: 100 / 255, blue: 104 / 255, alpha: 1.0).cgColor
        layer.shadowRadius = 13
        layer.shadowOffset = CGSize(width: 0, height: -2)
        layer.shadowOpacity = 0.18
    }

    func shake() {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 3
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: center.x - 10, y: center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: center.x + 10, y: center.y))
        layer.add(animation, forKey: "position")
    }

    func rotate(value: CGFloat, animate: Bool, delegate: CAAnimationDelegate) {
        let animation = CABasicAnimation(keyPath: "transform.rotation")

        animation.toValue = value
        animation.duration = 0.2
        if !animate {
            animation.speed = 200
        }
        animation.isRemovedOnCompletion = false
        animation.fillMode = CAMediaTimingFillMode.forwards

        animation.delegate = delegate

        layer.add(animation, forKey: nil)
    }

    func removeAllAnimations() {
        layer.removeAllAnimations()
    }

    @discardableResult func addGradient(color: UIColor, from top: CGFloat, to bottom: CGFloat) -> CAGradientLayer {
        let gradientLayer = CAGradientLayer()
        let topColor = color.withAlphaComponent(top).cgColor
        let bottomColor = color.withAlphaComponent(bottom).cgColor
        gradientLayer.colors = [topColor, bottomColor]
        gradientLayer.frame = frame
        gradientLayer.startPoint = CGPoint(x: 1, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        layer.insertSublayer(gradientLayer, at: 0)
        return gradientLayer
    }

    func setGradient(gradientLayer: CAGradientLayer, topColor: UIColor, bottomColor: UIColor) {
        let topColor = topColor.withAlphaComponent(0).cgColor
        let bottomColor = bottomColor.withAlphaComponent(1).cgColor
        gradientLayer.colors = [topColor, bottomColor]
        gradientLayer.frame = frame
        gradientLayer.startPoint = CGPoint(x: 1, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        layer.insertSublayer(gradientLayer, at: 0)
    }
}

public extension UIView {
    @IBInspectable var cornerRadiusForView: CGFloat {
        get {
            layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }

    func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(
            roundedRect: bounds,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
