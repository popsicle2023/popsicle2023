//
//  DataExtensions.swift
//  Paperx
//
//  Created by Eser Kucuker on 18.01.2023.
//

import Foundation
import UIKit

public extension Data {
    var format: MimeType {
        let array = [UInt8](self)
        if array.count <= 0 {
            return .unknown
        }
        let ext: MimeType
        switch array[0] {
        case 0xFF:
            ext = .jpeg
        case 0x89:
            ext = .png
        case 0x47:
            ext = .gif
        case 0x49, 0x4D:
            ext = .tiff
        default:
            ext = .unknown
        }
        return ext
    }

    var byteCount: String {
        let bcf = ByteCountFormatter()
        bcf.allowedUnits = [.useKB]
        bcf.countStyle = .file
        let string = bcf.string(fromByteCount: Int64(count))
        return string.replacingOccurrences(of: " KB", with: "")
    }

    func image() -> UIImage? {
        UIImage(data: self)
    }
}

public enum MimeType: String, Decodable {
    case jpeg = "image/jpeg", png = "image/png", gif = "image/gif", tiff = "image/tiff", unknown = ""
    public var fileExtension: String {
        switch self {
        case .jpeg: return "jpeg"
        case .png: return "png"
        case .gif: return "gif"
        case .tiff: return "tiff"
        case .unknown: return ""
        }
    }
}
