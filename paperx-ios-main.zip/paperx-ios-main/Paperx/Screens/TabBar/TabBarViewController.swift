//
//  HomeViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

/// An Empty View Controller to show as last empty tab which allows application to switch to previous screen.
private class EmptyTabController: UIViewController {
    // nothing to handle
}

final class TabBarViewController: UITabBarController {
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
        updateUI()
        displayMarket()
    }

    // MARK: Setup

    private func setup() {}

    func updateUI() {
        if #available(iOS 15.0, *) {
            let appearance = createMarketTabBarAppearance()
            self.tabBar.standardAppearance = appearance
            self.tabBar.scrollEdgeAppearance = appearance
        } else {
            UITabBarItem.appearance().setTitleTextAttributes(getAttributedString(selected: true), for: .selected)
            UITabBarItem.appearance().setTitleTextAttributes(getAttributedString(selected: false), for: .normal)
        }
    }

    func getAttributedString(selected: Bool) -> [NSAttributedString.Key: Any] {
        [
            .font: UIFont.getFont(family: selected ? .semibold : .regular, size: 12),
            .foregroundColor: UIColor.gray,
        ]
    }

    func routeTo(_ paperXTab: PaperXTabs) {
        selectedIndex = paperXTab.rawValue
    }

    func displayMarket() {
        tabBar.isHidden = false
        viewControllers = [
            "HomePage", "Exams",
        ].compactMap { createTabViewController(in: $0) }
        setKocMarketTabButton()
    }

    private func setKocMarketTabButton() {
        guard let items = tabBar.items else { return }
        for index in 0 ..< items.count {
            items[index].title = PaperXTabs(rawValue: index)?.title
            if index == PaperXTabs.home.rawValue {
                items[index].selectedImage = UIImage(named: "tab_home")
                items[index].image = UIImage(named: "tab_homeDisable")
            }
            if index == PaperXTabs.exam.rawValue {
                items[index].selectedImage = UIImage(named: "tab_profile")
                items[index].image = UIImage(named: "tab_profileDisable")
            }
        }
    }

    private func createTabViewController(in storyboardName: String) -> UINavigationController {
        let controller: UINavigationController = UIApplication.getViewController(
            inScene: storyboardName, rootViewController: true
        )
        return controller
    }
}

extension TabBarViewController: UITabBarControllerDelegate {
    override public func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let position = tabBar.items?.firstIndex(of: item) else { return }
    }
}

enum PaperXTabs: Int, CaseCountable {
    case home = 0
    case exam

    var title: String {
        switch self {
        case .home: return "Home Page"
        case .exam: return "Exams"
        }
    }
}
