//
//  ExamPaperRouter.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation
import UIKit
import HandyViewController

protocol ExamPaperRoutingLogic: AnyObject {
    func routeToExams(data: ExamPaper.FetchExamsPaper.ViewModel)
}

protocol ExamPaperDataPassing: AnyObject {
    var dataStore: ExamPaperDataStore? { get }
}

final class ExamPaperRouter: ExamPaperRoutingLogic, ExamPaperDataPassing {
    weak var viewController: ExamPaperViewController?
    var dataStore: ExamPaperDataStore?

    func routeToExams(data: ExamPaper.FetchExamsPaper.ViewModel) {
        let controller: QuestionsNameViewController = UIApplication.getViewController()
        let transitioningDelegate = HandyTransitioningDelegate(from: viewController!, to: controller)
        controller.data = data.questionName
        controller.modalPresentationStyle = .custom
        controller.transitioningDelegate = transitioningDelegate
        controller.delegate = viewController
        viewController?.present(controller, animated: true)
    }
}
