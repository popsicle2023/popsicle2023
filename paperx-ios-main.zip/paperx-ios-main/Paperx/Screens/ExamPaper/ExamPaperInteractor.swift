//
//  ExamPaperInteractor.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation
import Reachability

protocol ExamPaperBusinessLogic: AnyObject {
    func fetchAddExamPaper(request: ExamPaper.FetchExamsPaper.Request)
    func fetchExamById()
}

protocol ExamPaperDataStore: AnyObject {
    var exam: ExamList? { get set }
}

final class ExamPaperInteractor: ExamPaperBusinessLogic, ExamPaperDataStore {
    var presenter: ExamPaperPresentationLogic?
    var worker: ExamPaperWorkingLogic = ExamPaperWorker()

    var exam: ExamList?
    
    func fetchExamById() {
        guard let id = exam?.id else {return}
        worker.getExamById(request: id) { [weak self] result in
            guard let self else {return}
            switch result {
            case let .success(response):
                self.presenter?.presentExams(response: ExamPaper.FetchExamsPaper.Response(exam: response))
            case let .failure(error):
                print(error)
            }
        }
    }

    func fetchAddExamPaper(request: ExamPaper.FetchExamsPaper.Request) {
        
        request.answers.answerList.forEach({ answer in
           let cleanAnswer = answer.selectedAnsers.replacingOccurrences(of: "\\\\", with: "", options: .literal, range: nil)
            
            guard let imageData: Data = answer.image.jpeg(.medium) else { return }
            let mimeType = imageData.format
            let request = UploadExamPaperRequest(
                parameters: [
                    (exam?.id).stringValue: "exam",
                    cleanAnswer : "outlineTitles"
                ],
                files: [UploadExamPaperRequest.UploadFile(
                    name: UUID().uuidString,
                    fileExtension: mimeType.fileExtension,
                    mimeType: mimeType.rawValue,
                    data: imageData
                )]
            )
            if Reachability.shared.currentPath.isReachable {
            worker.uploadExamPage(request: request) { result in
                switch result {
                case let .success(success):
                    self.presenter?.presentError(error: success.message)
                case let .failure(failure):
                    self.presenter?.presentError(error: failure.localizedDescription)
                }
            }
             } else {
                 self.presenter?.presentError(error: "network_error".localized)
             }
        })
       // guard let imageData: Data = request.image.jpeg(.medium) else { return }

    }
}
