//
//  ExamPaperModels.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation
import UIKit

// swiftlint:disable nesting
enum ExamPaper {
    enum FetchExamsPaper {
        struct Request {
            let answers: Answers.Answers
        }

        struct Response {
            let exam: GetExamResponse
        }

        struct ViewModel {
            let questionName: [String]
        }
    }
    
    enum Answers {
        struct Answers {
            var answerList:[Answer]
        }
       
        struct Answer {
            var image: UIImage
            var selectedAnsers: String
        }
    
    }
}

enum ImageSource {
    case photoLibrary
    case camera
}

// swiftlint:enable nesting
