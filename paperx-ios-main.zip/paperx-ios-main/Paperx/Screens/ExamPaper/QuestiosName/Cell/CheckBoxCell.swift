//
//  CheckBoxCell.swift
//  Paperx
//
//  Created by Eser Kucuker on 18.03.2023.
//

import UIKit

class CheckBoxCell: UITableViewCell {

    @IBOutlet var chekBoxImageView: UIImageView!
    
    enum Radio {
        static var selected = UIImage(named: "checkIcon")
        static var unselected = UIImage(named: "unCheckIcon")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        super.setSelected(selected, animated: animated)
        if selected {
            chekBoxImageView.image = Radio.selected
        } else {
            chekBoxImageView.image = Radio.unselected
        }
    }

}
