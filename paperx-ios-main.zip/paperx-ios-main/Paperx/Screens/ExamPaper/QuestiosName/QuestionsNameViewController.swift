//
//  QuestionsNameViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 17.03.2023.
//

import UIKit
import HandyViewController

protocol QuestionNameDelegate: AnyObject {
    func sendQuestionName(questions: [String])
}

class QuestionsNameViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var doneButton: UIButton!
    weak var delegate: QuestionNameDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerHandyScrollView(tableView)
        
    }
    
    var data: [String] = []
    var selectedQuesiton: [String] = []
    
    @IBAction func submitDoneButton(_ sender: Any) {
        delegate?.sendQuestionName(questions: selectedQuesiton)
        self.dismiss(animated: true)
    }
    
}
extension QuestionsNameViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CheckBoxCell")
        cell?.textLabel?.text = data[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedQuesiton.append(data[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let questionsName = data[indexPath.row]
        selectedQuesiton.removeAll { value in
            value == questionsName
        }
    }
}

extension QuestionsNameViewController {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        handyScrollViewDidScroll(scrollView)
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint,
                                   targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        handyScrollViewWillEndDragging(scrollView, withVelocity: velocity)
    }
}
