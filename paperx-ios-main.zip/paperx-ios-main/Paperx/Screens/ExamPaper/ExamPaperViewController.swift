//
//  ExamPaperViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import AVFoundation
import UIKit
import Reachability
import HandyViewController

protocol ExamPaperDisplayLogic: AnyObject {
    func displayExams(viewModel: ExamPaper.FetchExamsPaper.ViewModel)
    func displayError(error: String)
}

final class ExamPaperViewController: UIViewController {
    
    @IBOutlet weak var seperatorView: UIView!
    @IBOutlet weak var sendQuestion: UIButton!
    @IBOutlet var examPaperImageView: UIImageView!
    @IBOutlet var sendButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var interactor: ExamPaperBusinessLogic?
    var router: (ExamPaperRoutingLogic & ExamPaperDataPassing)?

    var isImageSetted: Bool = false
    var questionsNameList: [String] = []
    var answerList: [ExamPaper.Answers.Answer] = []

    // MARK: Object lifecycle

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    // MARK: Setup

    private func setup() {
        let viewController = self
        let interactor = ExamPaperInteractor()
        let presenter = ExamPaperPresenter()
        let router = ExamPaperRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        addShadow()
        interactor?.fetchExamById()
        makeClickable()
        Reachability.shared.currentPath.isReachable
        tableView.register(.init(nibName: "QuestionImageAndNameCell", bundle: .main), forCellReuseIdentifier: "QuestionImageAndNameCell")
    }
    
    fileprivate func addShadow() {
        seperatorView.layer.shadowColor = UIColor.black.cgColor
        seperatorView.layer.shadowOffset = CGSize(width: 0, height: 0)
        seperatorView.layer.shadowRadius = 5.0
        seperatorView.layer.shadowOpacity = 0.5
        seperatorView.layer.masksToBounds = false
    }

    func makeClickable() {
        let imageTapGesture = UITapGestureRecognizer(target: self, action: #selector(tapUserPhoto(_:)))
        imageTapGesture.delegate = self
        examPaperImageView.addGestureRecognizer(imageTapGesture)
        imageTapGesture.numberOfTapsRequired = 1
        examPaperImageView.isUserInteractionEnabled = true
    }

    @objc func tapUserPhoto(_: UITapGestureRecognizer) {
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)

        switch cameraAuthorizationStatus {
        case .notDetermined:
            requestCameraPermission()
        case .authorized:
            presentCamera()
        case .restricted, .denied:
            alertCameraAccessNeeded()
        }
    }

    func presentCamera() {
        DispatchQueue.main.async { [weak self] in
            let pickerController = UIImagePickerController()
            pickerController.sourceType = .camera
            pickerController.delegate = self
            self?.present(pickerController, animated: true)
        }
    }

    func requestCameraPermission() {
        AVCaptureDevice.requestAccess(for: .video, completionHandler: { accessGranted in
            guard accessGranted == true else { return }
            self.presentCamera()
        })
    }
    
    @IBAction func showQuestionName(_ sender: Any) {
        guard isImageSetted else {
            showSuccesMessage("picture_error".localized)
            return
        }
        router?.routeToExams(data: ExamPaper.FetchExamsPaper.ViewModel(questionName: questionsNameList))
    }
    

    @IBAction func subbitSendButton(_: Any) {
        guard !answerList.isEmpty else {
            showSuccesMessage("picture_error".localized)
            return
        }
        guard let image = examPaperImageView.image else {return}
        if Reachability.shared.currentPath.isReachable {
            interactor?.fetchAddExamPaper(
                request: ExamPaper.FetchExamsPaper.Request(
                    answers: ExamPaper.Answers.Answers(answerList: answerList)
                ))
        } else {
            showSuccesMessage("network_error".localized)
        }
        
    }

    func alertCameraAccessNeeded() {
        let settingsAppURL = URL(string: UIApplication.openSettingsURLString)!

        let alert = UIAlertController(
            title: "permissions".localized,
            message: "camere_permissions".localized,
            preferredStyle: UIAlertController.Style.alert
        )

        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "allow_camera".localized, style: .cancel, handler: { _ in
            UIApplication.shared.open(settingsAppURL, options: [:], completionHandler: nil)
        }))

        present(alert, animated: true, completion: nil)
    }
}

// MARK: TableView DataSource
extension ExamPaperViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        answerList.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueCell(type: QuestionImageAndNameCell.self, indexPath: indexPath)
        cell.questionLabel.text = answerList[indexPath.row].selectedAnsers
        cell.paperImageView.image = answerList[indexPath.row].image
        return cell
    }
    
    
}

// MARK: TableView DataSource
extension ExamPaperViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] (action, view, completionHandler) in
            self?.deleteRow(at: indexPath)
            completionHandler(true)
        }
        deleteAction.image = UIImage(systemName: "trash")
        deleteAction.backgroundColor = .red
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        return configuration
    }
    
    func deleteRow(at indexPath: IndexPath) {
        answerList.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
}

// MARK: DisplayLogic
extension ExamPaperViewController: ExamPaperDisplayLogic {
    func displayExams(viewModel: ExamPaper.FetchExamsPaper.ViewModel) {
        questionsNameList = viewModel.questionName
    }
    
    func displayError(error: String) {
        showSuccesMessage(error)
    }
}

// MARK: GestureRecognizerDelegate
extension ExamPaperViewController: UIGestureRecognizerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        guard let image = (info[.originalImage] as? UIImage)?.rotateCameraImageToProperOrientation() else {return}
        isImageSetted = true
        examPaperImageView.image = image
        dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}

// MARK: QuestionNameDelegate
extension ExamPaperViewController: QuestionNameDelegate {
    func sendQuestionName(questions: [String]) {
        let image = examPaperImageView.image!
        answerList.append(ExamPaper.Answers.Answer(image: image, selectedAnsers: "\(questions)"))
        tableView.reloadData()
        isImageSetted = false
        examPaperImageView.image = UIImage(systemName: "camera.shutter.button.fill")
    }
}
