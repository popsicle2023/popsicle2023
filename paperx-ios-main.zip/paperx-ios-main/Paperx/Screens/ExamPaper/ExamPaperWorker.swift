//
//  ExamPaperWorker.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation

protocol ExamPaperWorkingLogic: AnyObject {
    func uploadExamPage(request: UploadExamPaperRequest, completion: @escaping ((Result<EmptyCodable, Error>) -> Void))
    func getExamById(request: String, completion: @escaping (Result<GetExamResponse, Error>) -> Void)
}

final class ExamPaperWorker: ExamPaperWorkingLogic {
    func uploadExamPage(request: UploadExamPaperRequest, completion: @escaping ((Result<EmptyCodable, Error>) -> Void)) {
        PaperxAPI.UploadExamPge.uploadExamPage(request: request).fetchUpdateImagee(EmptyCodable.self, completion: completion)
    }
    
    func getExamById(request: String, completion: @escaping (Result<GetExamResponse, Error>) -> Void) {
        PaperxAPI.GetExems.getExemByID(request: request).fetchResponse(GetExamResponse.self, completion: completion)
    }
}
