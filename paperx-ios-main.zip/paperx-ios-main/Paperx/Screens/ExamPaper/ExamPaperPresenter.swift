//
//  ExamPaperPresenter.swift
//  Paperx
//
//  Created by Eser Kucuker on 14.01.2023.
//

import Foundation

protocol ExamPaperPresentationLogic: AnyObject {
    func presentExams(response: ExamPaper.FetchExamsPaper.Response)
    func presentError(error: String)
}

final class ExamPaperPresenter: ExamPaperPresentationLogic {
    weak var viewController: ExamPaperDisplayLogic?

    func presentExams(response: ExamPaper.FetchExamsPaper.Response) {
        var questionName: [String] = []
        let questions = response.exam.result?.outlines
        questions?.forEach({ outline in
            var name: [String] = []
            var quname = outline.title?.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil)
            if (outline.childs?.count == 0) {
                questionName.append(quname ?? "")
            }
            outline.childs?.forEach({ child in
                let qname = (quname ?? "") + "/" + (child.title?.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil) ?? "")
                name.append(qname)
                quname = outline.title?.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil)
            })
            questionName.append(contentsOf: name)
        })
        
        viewController?.displayExams(viewModel: ExamPaper.FetchExamsPaper.ViewModel(questionName: questionName))
    }
    
    func presentError(error: String) {
        viewController?.displayError(error: error)
    }
}
