//
//  HomePageViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

protocol HomePageDisplayLogic: AnyObject {
    func displayUserName(viewModel: HomePage.WhoAmI.ViewModel)
    func displayCourse(viewModel: HomePage.WhoAmI.ViewModel)
}

final class HomePageViewController: UIViewController {
    var interactor: HomePageBusinessLogic?
    var router: (HomePageRoutingLogic & HomePageDataPassing)?
    var course: [Datum] = []

    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var userNameLabel: UILabel!

    // MARK: Object lifecycle

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    // MARK: Setup

    private func setup() {
        let viewController = self
        let interactor = HomePageInteractor()
        let presenter = HomePagePresenter()
        let router = HomePageRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Main Courses"
        interactor?.fetcWhoAmI()
        interactor?.fetchCourse()
        registerCells()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        interactor?.fetchCourse()
    }

    func registerCells() {
        collectionView.register(CoureseCollectionViewCell.self, in: .main)
    }
}

extension HomePageViewController: HomePageDisplayLogic {
    func displayCourse(viewModel: HomePage.WhoAmI.ViewModel) {
        course = viewModel.course ?? []
        collectionView.reloadData()
    }

    func displayUserName(viewModel: HomePage.WhoAmI.ViewModel) {
        userNameLabel.text = """
            Hello,
            \(viewModel.userName.stringValue) !
        """
    }
}

extension HomePageViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_: UICollectionView, numberOfItemsInSection _: Int) -> Int {
        course.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueCell(type: CoureseCollectionViewCell.self, indexPath: indexPath)
        let model = course[indexPath.row]
        cell.model = model
        cell.setupUI()
        return cell
    }
}

extension HomePageViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(
        _ collectionView: UICollectionView,
        layout _: UICollectionViewLayout,
        sizeForItemAt _: IndexPath
    ) -> CGSize {
        let cellWidth = (collectionView.frame.size.width - 40) / 2
        return CGSize(width: cellWidth, height: 200)
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        minimumInteritemSpacingForSectionAt _: Int
    ) -> CGFloat {
        10
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        minimumLineSpacingForSectionAt _: Int
    ) -> CGFloat {
        15.0
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        insetForSectionAt _: Int
    ) -> UIEdgeInsets {
        UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
    }
}
