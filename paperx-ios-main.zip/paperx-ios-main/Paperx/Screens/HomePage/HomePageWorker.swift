//
//  HomePageWorker.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol HomePageWorkingLogic: AnyObject {
    func getLogin(completion: @escaping ((Result<GetWhoAmIResponse, Error>) -> Void))
    func getCourses(completion: @escaping ((Result<GetCourseResponse, Error>) -> Void))
}

final class HomePageWorker: HomePageWorkingLogic {
    func getLogin(completion: @escaping ((Result<GetWhoAmIResponse, Error>) -> Void)) {
        PaperxAPI.whoAmI.whoAmI.fetchResponse(GetWhoAmIResponse.self, completion: completion)
    }

    func getCourses(completion: @escaping ((Result<GetCourseResponse, Error>) -> Void)) {
        PaperxAPI.GetCourses.getCourses.fetchResponse(GetCourseResponse.self, completion: completion)
    }
}
