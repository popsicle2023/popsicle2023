//
//  HomePagePresenter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol HomePagePresentationLogic: AnyObject {
    func presentName(response: HomePage.WhoAmI.Response)

    func presentCourse(response: HomePage.WhoAmI.Response)
}

final class HomePagePresenter: HomePagePresentationLogic {
    weak var viewController: HomePageDisplayLogic?

    func presentName(response: HomePage.WhoAmI.Response) {
        viewController?.displayUserName(
            viewModel: HomePage.WhoAmI.ViewModel(
                userName: response.userName,
                course: response.course
            )
        )
    }

    func presentCourse(response: HomePage.WhoAmI.Response) {
        viewController?.displayCourse(
            viewModel: HomePage.WhoAmI.ViewModel(
                userName: response.userName,
                course: response.course
            ))
    }
}
