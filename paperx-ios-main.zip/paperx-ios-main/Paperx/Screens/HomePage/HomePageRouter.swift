//
//  HomePageRouter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol HomePageRoutingLogic: AnyObject {}

protocol HomePageDataPassing: AnyObject {
    var dataStore: HomePageDataStore? { get }
}

final class HomePageRouter: HomePageRoutingLogic, HomePageDataPassing {
    weak var viewController: HomePageViewController?
    var dataStore: HomePageDataStore?
}
