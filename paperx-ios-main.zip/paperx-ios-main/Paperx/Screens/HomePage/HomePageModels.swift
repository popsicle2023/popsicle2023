//
//  HomePageModels.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

// swiftlint:disable nesting
enum HomePage {
    enum WhoAmI {
        struct Request {}

        struct Response {
            let userName: String?
            let course: [Datum]?
        }

        struct ViewModel {
            let userName: String?
            let course: [Datum]?
        }
    }
}

// swiftlint:enable nesting
