//
//  HomePageInteractor.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol HomePageBusinessLogic: AnyObject {
    func fetcWhoAmI()
    func fetchCourse()
}

protocol HomePageDataStore: AnyObject {}

final class HomePageInteractor: HomePageBusinessLogic, HomePageDataStore {
    var presenter: HomePagePresentationLogic?
    var worker: HomePageWorkingLogic = HomePageWorker()

    func fetcWhoAmI() {
        worker.getLogin { result in
            switch result {
            case let .success(response):
                if response.result?.username != nil {
                    self.presenter?.presentName(
                        response: HomePage.WhoAmI.Response(
                            userName: response.result?.username, course: nil
                        )
                    )
                }
            case let .failure(error):
                print(error)
            }
        }
    }

    func fetchCourse() {
        worker.getCourses { result in
            switch result {
            case let .success(response):
                if response.result.data != nil {
                    self.presenter?.presentCourse(response: HomePage.WhoAmI.Response(userName: nil, course: response.result.data))
                }
            case let .failure(error):
                print(error)
            }
        }
    }
}
