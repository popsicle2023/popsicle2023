//
//  CoureseCollectionViewCell.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

class CoureseCollectionViewCell: UICollectionViewCell {
    @IBOutlet var cellView: UIView!
    @IBOutlet var courseLabel: UILabel!

    @IBOutlet var departmenLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    var model: Datum?

    fileprivate func extractedFunc() {
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowRadius = 5.0
        layer.shadowOpacity = 0.5
        layer.masksToBounds = false
    }

    func setupUI() {
        courseLabel.text = model?.name.stringValue
        departmenLabel.text = model?.departmentName.stringValue
        cellView.layer.borderColor = UIColor.gray.cgColor
        cellView.layer.borderWidth = 1
        extractedFunc()
    }
}
