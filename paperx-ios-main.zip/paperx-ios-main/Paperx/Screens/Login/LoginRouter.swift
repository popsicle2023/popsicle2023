//
//  LoginRouter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation
import UIKit

protocol LoginRoutingLogic: AnyObject {
    func routeToHomePage()
}

protocol LoginDataPassing: AnyObject {
    var dataStore: LoginDataStore? { get }
}

final class LoginRouter: LoginRoutingLogic, LoginDataPassing {
    weak var viewController: LoginViewController?
    var dataStore: LoginDataStore?

    func routeToHomePage() {
        let topViewController = UIApplication.shared.rootViewController
        let homeViewController: TabBarViewController = UIApplication.getViewController()
        homeViewController.modalPresentationStyle = .overFullScreen
        homeViewController.loadViewIfNeeded()
        topViewController?.present(homeViewController, animated: true, completion: nil)
//        viewController?.dismiss(animated: true,
//                                completion: {
//                                    let homeViewController: TabBarViewController = UIApplication.getViewController()
//                                    homeViewController.navigationController?.navigationBar.isHidden = true
//                                    self.viewController?.navigationController?.pushViewController(homeViewController, animated: true)
//                                })
    }
}
