//
//  LoginWorker.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol LoginWorkingLogic: AnyObject {
    func getLogin(request: LoginRequest, completion: @escaping ((Result<LoginResponse, Error>) -> Void))
}

final class LoginWorker: LoginWorkingLogic {
    func getLogin(request: LoginRequest, completion: @escaping ((Result<LoginResponse, Error>) -> Void)) {
        PaperxAPI.Login.startAuth(request: request).fetchResponse(LoginResponse.self, completion: completion)
    }
}
