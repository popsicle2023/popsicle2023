//
//  LoginInteractor.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol LoginBusinessLogic: AnyObject {
    func fetchLogin(request: Login.FetchLogin.Request)
}

protocol LoginDataStore: AnyObject {}

final class LoginInteractor: LoginBusinessLogic, LoginDataStore {
    var presenter: LoginPresentationLogic?
    var worker: LoginWorkingLogic = LoginWorker()

    func fetchLogin(request: Login.FetchLogin.Request) {
        guard let unameOrEmail = request.userNameOrMail,
              let password = request.password else { return }
        worker.getLogin(request: LoginRequest(unameOrEmail: unameOrEmail, password: password)) { result in
            switch result {
            case let .success(response):
                if response.result?.token != nil {
                    Authentication.shared.token?.set(response.result?.token, forKey: "token")
                    self.presenter?.presentLogin()
                } else {
                    self.presenter?.presentError(error: response.message)
                }
            case let .failure(failure):
                self.presenter?.presentError(error: failure.localizedDescription)
            }
        }
    }
}
