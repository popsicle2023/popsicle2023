//
//  LoginModels.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

// swiftlint:disable nesting
enum Login {
    enum FetchLogin {
        struct Request {
            let userNameOrMail: String?
            let password: String?
        }

        struct Response {}

        struct ViewModel {}
    }
}

// swiftlint:enable nesting
