//
//  LoginPresenter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol LoginPresentationLogic: AnyObject {
    func presentLogin()
    func presentError(error: String)
}

final class LoginPresenter: LoginPresentationLogic {
    weak var viewController: LoginDisplayLogic?

    func presentLogin() {
        viewController?.displayLogin()
    }
    
    func presentError(error: String) {
        viewController?.displayError(error: error)
    }
}
