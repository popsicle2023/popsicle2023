//
//  LoginViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import SkyFloatingLabelTextField
import UIKit

protocol LoginDisplayLogic: AnyObject {
    func displayLogin()
    func displayError(error: String)
}

final class LoginViewController: UIViewController {
    @IBOutlet var passwrodTextFeild: PXTextFieldWithIcon!
    @IBOutlet var emailTextFeild: PXTextFieldWithIcon!
    @IBOutlet var loginButton: UIButton!

    var interactor: LoginBusinessLogic?
    var router: (LoginRoutingLogic & LoginDataPassing)?

    // MARK: Object lifecycle

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    // MARK: Setup

    private func setup() {
        let viewController = self
        let interactor = LoginInteractor()
        let presenter = LoginPresenter()
        let router = LoginRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
        emailTextFeild.iconType = .image
        passwrodTextFeild.iconType = .image
        self.hideKeyboardWhenTappedAround()
    }

    @IBAction func SubmitLoginButton(_: Any) {
        let userNameOrMail =  emailTextFeild.text
        let password =  passwrodTextFeild.text
        interactor?.fetchLogin(
            request: Login.FetchLogin.Request(
                userNameOrMail: userNameOrMail,
                password: password
            )
        )
    }
}

extension LoginViewController: LoginDisplayLogic {
    func displayLogin() {
        router?.routeToHomePage()
    }
    
    func displayError(error: String) {
        showErrorMessage(error)
    }
}
