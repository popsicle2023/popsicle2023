//
//  ExamsInteractor.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol ExamsBusinessLogic: AnyObject {
    func fetchExems()
}

protocol ExamsDataStore: AnyObject {
    var exams: [ExamList]? { get set }
}

final class ExamsInteractor: ExamsBusinessLogic, ExamsDataStore {
    var presenter: ExamsPresentationLogic?
    var worker: ExamsWorkingLogic = ExamsWorker()

    var exams: [ExamList]?

    func fetchExems() {
        worker.getExems { [weak self] result in
            guard let self else { return }
            switch result {
            case let .success(response):
                if response.result?.data != nil {
                    self.exams = response.result?.data ?? []
                    self.presenter?.presentExmas(
                        response: Exams.FetchExams.Response(
                            exams: self.exams ?? []
                        )
                    )
                } else {
                    self.presenter?.presentError(error: response.message)
                }
            case let .failure(error):
                self.presenter?.presentError(error: error.localizedDescription)
            }
        }
    }
}
