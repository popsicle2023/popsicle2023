//
//  ExamsViewController.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

protocol ExamsDisplayLogic: AnyObject {
    func displayExams(viewModel: Exams.FetchExams.ViewModel)
    func displayError(error: String)
}

final class ExamsViewController: UIViewController {
    @IBOutlet var collectionView: UICollectionView!

    var interactor: ExamsBusinessLogic?
    var router: (ExamsRoutingLogic & ExamsDataPassing)?

    var exams: [ExamList]?

    // MARK: Object lifecycle

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    // MARK: Setup

    private func setup() {
        let viewController = self
        let interactor = ExamsInteractor()
        let presenter = ExamsPresenter()
        let router = ExamsRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Exam List"
        let textAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        registerCells()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        interactor?.fetchExems()
    }

    func registerCells() {
        collectionView.register(ExamsCollectionViewCell.self, in: .main)
    }
}

extension ExamsViewController: ExamsDisplayLogic {
    func displayExams(viewModel: Exams.FetchExams.ViewModel) {
        exams = viewModel.exams
        collectionView.reloadData()
    }
    
    func displayError(error: String) {
        showErrorMessage(error)
    }
}

extension ExamsViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_: UICollectionView, numberOfItemsInSection _: Int) -> Int {
        exams?.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueCell(type: ExamsCollectionViewCell.self, indexPath: indexPath)
        let model = exams?[indexPath.row]
        cell.model = model
        cell.setupUI()
        return cell
    }

    func collectionView(_: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        router?.routeToExamPaper(index: indexPath.row)
    }
}

extension ExamsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(
        _ collectionView: UICollectionView,
        layout _: UICollectionViewLayout,
        sizeForItemAt _: IndexPath
    ) -> CGSize {
        let cellWidth = (collectionView.frame.size.width - 40) / 2
        return CGSize(width: cellWidth, height: 200)
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        minimumInteritemSpacingForSectionAt _: Int
    ) -> CGFloat {
        10
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        minimumLineSpacingForSectionAt _: Int
    ) -> CGFloat {
        15.0
    }

    func collectionView(
        _: UICollectionView,
        layout _: UICollectionViewLayout,
        insetForSectionAt _: Int
    ) -> UIEdgeInsets {
        UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
    }
}
