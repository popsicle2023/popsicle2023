//
//  ExamsRouter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation
import UIKit

protocol ExamsRoutingLogic: AnyObject {
    func routeToExamPaper(index: Int)
}

protocol ExamsDataPassing: AnyObject {
    var dataStore: ExamsDataStore? { get }
}

final class ExamsRouter: ExamsRoutingLogic, ExamsDataPassing {
    weak var viewController: ExamsViewController?
    var dataStore: ExamsDataStore?

    func routeToExamPaper(index: Int) {
        let examViewController: ExamPaperViewController = UIApplication.getViewController()
        examViewController.router?.dataStore?.exam = dataStore?.exams?[index]
        viewController?.navigationController?.pushViewController(examViewController, animated: true)
    }
}
