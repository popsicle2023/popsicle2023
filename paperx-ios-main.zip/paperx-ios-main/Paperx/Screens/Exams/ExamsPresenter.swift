//
//  ExamsPresenter.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol ExamsPresentationLogic: AnyObject {
    func presentExmas(response: Exams.FetchExams.Response)
    func presentError(error: String)
}

final class ExamsPresenter: ExamsPresentationLogic {
    weak var viewController: ExamsDisplayLogic?

    func presentExmas(response: Exams.FetchExams.Response) {
        viewController?.displayExams(
            viewModel: Exams.FetchExams.ViewModel(
                exams: response.exams
            )
        )
    }
    
    func presentError(error: String) {
        viewController?.displayError(error: error)
    }
}
