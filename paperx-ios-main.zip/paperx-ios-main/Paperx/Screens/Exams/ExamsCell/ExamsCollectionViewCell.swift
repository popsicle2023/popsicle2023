//
//  ExamsCollectionViewCell.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import UIKit

class ExamsCollectionViewCell: UICollectionViewCell {
    @IBOutlet var cellView: UIView!
    @IBOutlet var ExamLabel: UILabel!
    var shadowLayer = CAShapeLayer()

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    var model: ExamList?

    fileprivate func extractedFunc() {
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowRadius = 5.0
        layer.shadowOpacity = 0.5
        layer.masksToBounds = false
    }

    func setupUI() {
        ExamLabel.text = model?.name.stringValue
        cellView.layer.borderColor = UIColor.gray.cgColor
        cellView.layer.borderWidth = 1
        extractedFunc()
    }
}
