//
//  ExamsModels.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

// swiftlint:disable nesting
enum Exams {
    enum FetchExams {
        struct Request {}

        struct Response {
            var exams: [ExamList]
        }

        struct ViewModel {
            var exams: [ExamList]
        }
    }
}

// swiftlint:enable nesting
