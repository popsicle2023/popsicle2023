//
//  ExamsWorker.swift
//  Paperx
//
//  Created by Eser Kucuker on 13.01.2023.
//

import Foundation

protocol ExamsWorkingLogic: AnyObject {
    func getExems(completion: @escaping ((Result<GetExamsResponse, Error>) -> Void))
}

final class ExamsWorker: ExamsWorkingLogic {
    func getExems(completion: @escaping ((Result<GetExamsResponse, Error>) -> Void)) {
        PaperxAPI.GetExems.GetExems(request: GetExamsRequest()).fetchResponse(GetExamsResponse.self, completion: completion)
    }
}
