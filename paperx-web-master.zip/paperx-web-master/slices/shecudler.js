import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    Schedules: []
};

const shecudlerSlice = createSlice({
    name: "Schedules",
    initialState,
    reducers: {
        setShecudler: (state, action) => {
            state.Schedules = action.payload.Schedules;
          },
    },
});
export const Schedules = (state) => state.Schedules.value;

export const { setShecudler } = shecudlerSlice.actions;
export default shecudlerSlice.reducer;
