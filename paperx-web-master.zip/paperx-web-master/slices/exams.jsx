import { createSlice } from "@reduxjs/toolkit";
import courses from "../utils/menuItems";

const initialState = {
  examList: [],
  selectedPage: "Exams",
  selectedCourse: {},
  pageContent: courses,
  selectedCourseId: "",
  loading: true,
};
const examsSlice = createSlice({
  name: "examSettings",
  initialState,
  reducers: {
    setExamList: (state, action) => {
      state.examList = action.payload.examList;
    },
    setSelectedCourse: (state, action) => {
      state.selectedCourse = action.payload.selectedCourse;
      state.selectedCourseId = action.payload.selectedCourse?._id;
    },
    setSelectedPage: (state, action) => {
      state.selectedPage = action.payload.selectedPage;
    },
  },
});

export const { setSelectedCourse, setSelectedPage, setExamList } =
  examsSlice.actions;

export default examsSlice.reducer;
