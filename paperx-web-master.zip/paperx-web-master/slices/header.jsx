import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    AmI: {
        name: ""
    }
};

const headerSlice = createSlice({
    name: "header",
    initialState,
    reducers: {
        setAmI: (state, action) => {
            state.AmI = action.payload.AmI;
        }
    },
});

export const selectHeader = (state) => state;
export const { setAmI } = headerSlice.actions;

export default headerSlice.reducer;