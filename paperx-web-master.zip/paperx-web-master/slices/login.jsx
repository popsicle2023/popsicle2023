import { createSlice } from "@reduxjs/toolkit";
import AuthService from "../services/AuthService";
const initialState = {
    auth: false
};

const loginSlice = createSlice({
    name: "login",
    initialState,
    reducers: {
        setLogin: async (state, action) => {
            var result = await AuthService.login(action.payload.email, action.payload.password, action.payload.rememberMe)
            if (result) {
                state.auth = true;
                window.location.href = "/dashboard"
            }
        },
        LogOut() {
            AuthService.logout();
            window.location.href = "/"
        },
    },
});
export const selectPageData = (state) => state.login.value;


export const { setLogin, LogOut, WhoAmI } = loginSlice.actions;
export default loginSlice.reducer;
