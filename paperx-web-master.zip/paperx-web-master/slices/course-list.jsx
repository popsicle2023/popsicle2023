import { createSlice } from "@reduxjs/toolkit";
import courses from "../utils/menuItems";

const initialState = {
  selectedPage: "Dashboard",
  selectedCourse: {},
  pageContent: courses,
  selectedCourseId: "",
  courseList: [],
  loading: true,
};
const pageSettingsSlice = createSlice({
  name: "pageSettings",
  initialState,
  reducers: {
    setCourseList: (state, action) => {
      state.courseList = action.payload.courseList;
    },
    setSelectedCourse: (state, action) => {
      state.selectedCourse = action.payload.selectedCourse;
      state.selectedCourseId = action.payload.selectedCourse?._id;
    },
    setSelectedPage: (state, action) => {
      state.selectedPage = action.payload.selectedPage;
    },
  },
});

export const { setSelectedCourse, setSelectedPage, setCourseList } =
  pageSettingsSlice.actions;

export const exams = (state) => state.pageSettings.value;

export default pageSettingsSlice.reducer;
