import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    selectedSubmission:0
};

const SelectedSubmissionSlice = createSlice({
    name: "SelectedSubmission",
    initialState,
    reducers: {
        setselectedSubmission: (state, action) => {
            state.selectedSubmission = action.payload.selectedSubmission;
        },
        selectedSubmissionUp: (state, action) => {
            state.selectedSubmission++;
        },
        selectedSubmissionDown: (state, action) => {
            state.selectedSubmission--;
        },
    },
});
export const selectedSubmission = (state) => state.selectedSubmission.value;

export const { setselectedSubmission,selectedSubmissionUp,selectedSubmissionDown } = SelectedSubmissionSlice.actions;
export default SelectedSubmissionSlice.reducer;
