import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    courses: [],
    departments: [],
    schools: [],
};

const helperSlice = createSlice({
    name: "helper",
    initialState,
    reducers: {
        setSchools: (state, action) => {
            state.schools = action.payload.schools;
        },
        setDepartments: (state, action) => {
            state.departments = action.payload.departments;
        },
        setCourses: (state, action) => {
            state.courses = action.payload.courses;
        }
    },
});

export const { setSchools, setDepartments, setCourses } = helperSlice.actions;
export default helperSlice.reducer;