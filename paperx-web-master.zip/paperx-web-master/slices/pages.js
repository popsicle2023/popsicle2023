import { createSlice } from "@reduxjs/toolkit";
const initialState = {
    assigment: {

    },
    course: {

    }
};

const pagesSlice = createSlice({
    name: "Pages",
    initialState,
    reducers: {
        setCourseData: (state, action) => {
            state.course = action.payload.course;
        },
    },
});
export const Pages = (state) => state.Pages.value;

export const { setCourseData } = pagesSlice.actions;
export default pagesSlice.reducer;
