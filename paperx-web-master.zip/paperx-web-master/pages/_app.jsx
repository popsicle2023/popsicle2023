import "../styles/style.scss";
import "../styles/globals.scss";
import "../styles/dropdown.scss";
import "react-datepicker/dist/react-datepicker.css";
import { store } from "../store";
import { Provider, useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import AuthService from "../services/AuthService";
import { useRouter } from "next/router";
import HomePage from "../components/widgets/home-page";
import Layout from "../components/Shared/Layout";
import "react-toastify/dist/ReactToastify.css";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-material.css';

export default function App({ Component, pageProps }) {
  useEffect(() => {
    authCheck(router.asPath);
    const hideContent = () => setAuthorized(false);
    router.events.on("routeChangeStart", hideContent);
    router.events.on("routeChangeComplete", authCheck);
    return () => {
      router.events.off("routeChangeStart", hideContent);
      router.events.off("routeChangeComplete", authCheck);
    };
  }, []);
  const router = useRouter();
  const [authorized, setAuthorized] = useState(false);
  const privatePaths = [
    "/assigment",
    "/dashboard",
    "/course-material",
    "/exams",
    "/grade-distribution",
    "/grading",
    "/homeworks",
    "/quizzes",
    "/roster",
  ];
  function authCheck(url) {
    var path = url.split("?")[0].split("/")[1];
    if (!AuthService.checkAuth() && privatePaths.includes(path)) {
      setAuthorized(false);
      router.push({
        pathname: "/",
        query: { returnUrl: router.asPath },
      });
    } else {
      setAuthorized(true);
    }
  }

  if (authorized) {
    const getContent = () => {
      if (!privatePaths.includes(router.pathname))
        return (
          <Provider store={store}>
            <HomePage id="section1" />
          </Provider>
        );
      return (
        <Provider store={store}>
          <Layout>
            <Component {...pageProps} />
          </Layout>
        </Provider>
      );
    };
    return <>{getContent()}</>;
  }
}
