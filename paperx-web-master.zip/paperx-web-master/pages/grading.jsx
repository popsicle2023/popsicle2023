import React from "react";
import StudentGrading from "../components/widgets/grading/students/StudentGrading";
import GradeReview from "../components/widgets/grading/GradeReview";

const grading = () => {
	return <GradeReview />;
};

export default grading;
