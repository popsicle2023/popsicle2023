import React from "react";

const createNewCours = () => {
  return <div>createNewCours</div>;
};

export default createNewCours;
