import Examine from "../components/widgets/Examine";

const Exams = () => {
  return (
    <>
      <Examine type={"exam"}></Examine>
    </>
  );
};
export default Exams;
