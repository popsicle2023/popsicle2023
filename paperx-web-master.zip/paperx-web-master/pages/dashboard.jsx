import React, { useState } from "react";
import RightSection from "../components/widgets/RightSection";
import PageCards from "../components/widgets/PageCards";
import CourseCards from "../components/widgets/CourseCards";
import WelcomeDashboardCard from "../components/widgets/WelcomeDashboardCard";

const Dashboard = () => {
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));

  return (
    <div className="flex">
      <div className="container bg-primary mt-6 ">
        <WelcomeDashboardCard AmI={AmI} />
        <CourseCards AmI={AmI} />
        <PageCards />
      </div>
      <RightSection />
    </div>
  );
};

export default Dashboard;
