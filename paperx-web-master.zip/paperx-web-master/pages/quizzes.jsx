import React from "react";
import Examine from "../components/widgets/Examine";

const Quizzes = () => {
  return (
    <Examine type={"quiz"}></Examine>
  );
};

export default Quizzes;
