import React from "react";
import Examine from "../components/widgets/Examine";

const Homeworks = () => {
  return (
    <Examine type={"homework"}></Examine>
  );
};

export default Homeworks;
