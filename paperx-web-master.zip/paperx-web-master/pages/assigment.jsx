import React, { useEffect, useState } from "react";
import { Modal } from "flowbite-react";
import Image from "next/image";
import question from "../public/assets/img/assignment/question.png";
import AssignedList from "../components/widgets/AssignedList";
import AssigmentList from "../components/widgets/AssignmentList";
import StudentService from '../services/StudentService'
import CourseService from "../services/CourseService";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import { setSelectedCourse } from '../slices/course-list'
function assigment() {

  const [students, setStudents] = useState([]);
  const [IsAssignModalActive, setIsAssignModalActive] = useState(false);
  const [IsDeleteModalActive, setIsDeleteModalActive] = useState(false);
  const [selectedStudent, SetSelectedStudent] = useState({});
  const selectedCourse = useSelector((store) => store.pageSettings.selectedCourse);

  useEffect(() => {
    getData(window.location.href.split("courseId=")[1]);

  }, [])

  async function getData(courseId) {
    setStudents((await StudentService.GetStudentsByCategoryId(courseId)).data.result.data)
  }
  const showAssignModal = (data) => {
    SetSelectedStudent(data);
    setIsAssignModalActive(true);
  };

  const showDeleteModal = (data) => {
    SetSelectedStudent(data);
    setIsDeleteModalActive(true);
  };

  const assignStudentTA = async () => {
    if ((await CourseService.UpdateCourse(window.location.href.split("courseId=")[1],
      {
        assignedTAs: [
          {
            id: selectedStudent._id,
            username: selectedStudent.username
          }
        ]
      }
    )).data.message == "İşlem başarılı.") {
      students.forEach((x) => {
        if (x._id == selectedStudent._id)
          x.assigned = true
      })
      setStudents(students)
      setIsAssignModalActive(false);
      toast.success("Assigned Success", "Success")
    }
  };

  const deAssignStudentTA = async () => {
    if ((await CourseService.SetCourse(window.location.href.split("courseId=")[1],
      {
        assignedTAs: selectedCourse.assignedTAs.filter(x => x.id == selectedStudent._id)
      }
    )).data.message == "İşlem başarılı.") {
      setSelectedCourse({ selectedCourse: (await CourseService.GetCourseById(selectedCourse._id)).data.result })
      students.forEach((x) => {
        if (x._id == selectedStudent._id)
          x.assigned = false
      })
      setStudents(students)
      setIsDeleteModalActive(false);
      toast.success("DeAssigned Success", "Success")
    }
  };

  return (
    <>
      <div className="flex m-8">
        <div className="w-8/12">
          <AssigmentList list={students.filter(x => x.assigned == false)} showAssignModal={showAssignModal} />
        </div>
        <div className="w-4/12 ml-6 ">
          <AssignedList list={students.filter(x => x.assigned == true)} showDeleteModal={showDeleteModal} />
        </div>
      </div>
      <Modal show={IsAssignModalActive} size="sm" popup={true} onClose={() => { setIsAssignModalActive(false); }}>
        <Modal.Header />
        <Modal.Body>
          <div className="container mb-8">
            <div className="flex justify-center items-center">
              <Image src={question} alt="Question Icon" />
            </div>
            <div className="text-base pt-8 mx-3">
              Are You Sure want to assign
              <span className="font-semibold mx-3 ">{selectedStudent.displayName + " " + selectedStudent.email}</span>
              as TA?
            </div>
            <div className="mt-12 flex justify-between">
              <button className="w-6/12 rounded-3xl border-2 border-createnewcoursebtn  pt-3 pb-3 bg-white  text-createnewcoursebtn mx-3" onClick={() => { setIsAssignModalActive(false); }}>
                Decline
              </button>
              <button className="w-6/12 rounded-3xl border-1 border-solid pt-3 pb-3 bg-createnewcoursebtn text-white mx-3 " onClick={assignStudentTA}>
                Assign TA
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
      <Modal show={IsDeleteModalActive} size="sm" popup={true} onClose={() => { setIsDeleteModalActive(false) }}>
        <Modal.Header />
        <Modal.Body>
          <div className="container mb-8">
            <div className="flex justify-center items-center">
              <Image src={question} alt="Question Icon" />
            </div>
            <div className="text-base pt-8 mx-3">
              Are You Sure want to Delete
              <span className="font-semibold mx-3 ">{selectedStudent.displayName + " " + selectedStudent.email}</span>
              From the assigned TAs List?
            </div>
            <div className="mt-12 flex justify-between">
              <button className="w-6/12 rounded-3xl border-2 border-createnewcoursebtn  pt-3 pb-3 bg-white  text-createnewcoursebtn mx-3" onClick={() => { setIsDeleteModalActive(false) }}>
                Decline
              </button>
              <button className="w-6/12 rounded-3xl border-1 border-solid pt-3 pb-3 bg-createnewcoursebtn text-white mx-3 " onClick={deAssignStudentTA}              >
                Delete
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default assigment;
