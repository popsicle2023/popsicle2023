import Link from "next/link";
import HomePage from "../components/widgets/home-page";

export default function Home() {
  return (
    <>
      <HomePage />
    </>
  )
}



