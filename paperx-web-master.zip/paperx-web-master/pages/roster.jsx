import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Examine from "../components/widgets/Examine";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-material.css";

const Roster = () => {
  const dispatch = useDispatch();
  const [rowData] = useState([
    { make: "Toyota", model: "Celica", price: 35000 },
    { make: "Ford", model: "Mondeo", price: 32000 },
    { make: "Porsche", model: "Boxster", price: 72000 },
  ]);

  const [columnDefs] = useState([
    { field: "make" },
    { field: "model" },
    { field: "price" },
  ]);
  useEffect(() => {
    // getData();
  }, []);
  return (
    <div className="ag-theme-material h-[60vh] px-8">
      <AgGridReact
        animateRows={true}
        rowData={rowData}
        columnDefs={columnDefs}
      ></AgGridReact>
    </div>
  );
};

export default Roster;
