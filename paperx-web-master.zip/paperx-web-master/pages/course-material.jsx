import React from "react";
import CourseMaterials from "../components/widgets/CourseMaterials";


const Dashboard = () => {
  return (
    <div className="flex">
        <CourseMaterials />
    </div>
  );
};

export default Dashboard;
