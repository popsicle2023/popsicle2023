/** @type {import('tailwindcss').Config} */
const defaultTheme = require("tailwindcss/defaultTheme");
const plugin = require("tailwindcss/plugin");

delete defaultTheme.screens["2xl"];
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./public/**/*.html",
    "./node_modules/flowbite-react/**/*.js",
  ],
  theme: {
    screens: {
      ...defaultTheme.screens,
      xsm: "375px",
      md: "768px",
      xl: "1200px",
    },
    extend: {
      container: {
        center: true,
        padding: {
          DEFAULT: "1rem",
        },
      },
      backgroundImage: {
        "home-page":
          "url('../public/assets/img/home-page/background-solo.png')",
        demo: "url('../public/assets/img/demo/background.png')",
        advantages: "url('../public/assets/img/demo/background.png')",
      },
      colors: {
        cardblue: "#3a5aff",
        createnewcoursebtn: "#DF6B2E",
        primary: {
          DEFAULT: "#FAFAFA",
          0: "rgba(186, 214, 255, 0.3)",
          10: "#BAD6FF",
          20: "#AAAAAA",
        },
        blue: {
          DEFAULT: "#263878",
          10: "#3A5AFF",
          20: "#E7EFFC",
        },
        orange: {
          DEFAULT: "#DF6B2E",
          10: "#FFBE9D",
        },
        gray: {
          DEFAULT: "#5C656A",
          100: "#263238",
        },
      },
      fontFamily: {
        sans: ["Poppins", ...defaultTheme.fontFamily.sans],
      },
      width: {
        sm: "19rem",
        md: "22rem",
        lg: "46rem",
      },
      height: {
        sm: "8rem",
        md: "11rem",
        lg: "10rem",
      },
      borderWidth: {
        top: "25px solid transparent;",
        right: "",
        bottom: "",
        left: "",
      },
      flexBasis: {
        "1/7": "14.2857143%",
        "2/7": "28.5714286%",
        "3/7": "42.8571429%",
        "4/7": "57.1428571%",
        "5/7": "71.4285714%",
        "6/7": "85.7142857%",
      },
      boxShadow: {
        l: "-4px 8px 24px rgba(137, 137, 137, 0.15)",
      },
    },
  },
  plugins: [
    require("flowbite/plugin"),
    plugin(function ({ addComponents }) {
      addComponents({
        ".border-top": {
          borderTop: "10px solid #555",
        },
        ".border-right": {
          borderRight: "10px solid transparent",
        },
        ".border-bottom": {
          borderBottom: "10px solid #555",
        },
        ".border-left": {
          borderLeft: "10px solid transparent",
        },
      });
    }),
  ],
};
