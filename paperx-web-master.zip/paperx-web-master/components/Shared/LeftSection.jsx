import React, { useEffect, useState } from "react";
import logo from "../../public/assets/img/logo.png";
import Image from "next/image";
import logout from "../../public/assets/img/dash-board/logout.svg";
import house from "../../public/assets/img/dash-board/house.svg";
import { useDispatch, useSelector } from "react-redux";
import { ArrowBack } from 'tabler-icons-react';
import { setSelectedCourse, setSelectedPage, setCourseList } from "../../slices/course-list";
import { LogOut } from '../../slices/login'
import CourseService from '../../services/CourseService'
import { useRouter } from "next/router";
const LeftSection = () => {
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
  const pages = useSelector((store) => store.pageSettings.pageContent[1].pages.page_details);
  const courseList = useSelector((store) => store.pageSettings.courseList);
  const selectedCourseId = useSelector((store) => store.pageSettings.selectedCourseId);
  const selectedPage = useSelector((store) => store.pageSettings.selectedPage);
  const [leftMenuIsOpen, setLeftMenuIsOpen] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();

  function handleClick(_, href) {
    _.preventDefault();
    router.push(href, undefined, { shallow: true });
  }

  const getPageData = async () => {
    var courseList = await CourseService.GetCourseList()
    dispatch(setCourseList({ courseList: courseList.data.result.data }))
  }

  useEffect(() => {
    getPageData()
  }, [])

  const BackToDashBoard = () => {
    if (selectedCourseId !== undefined && selectedCourseId != "") {
      return (
        <li className="cursor-pointer" onClick={(e) => { dispatch(setSelectedCourse({ selectedCourse: {} })), dispatch(setSelectedPage({ selectedPage: "dashboard" })); handleClick(e, "/dashboard") }}>
          <div className=" my-8  text-sm">
            <div className="ml-8 flex">
              <ArrowBack
                size={24}
                strokeWidth={2}
              />
              <span className={leftMenuIsOpen ? "" : "MobileItem"}>Back To Dashboard</span>
            </div>
          </div>
        </li>
      )
    }
  }

  return (
    <div className={leftMenuIsOpen ? "LeftMenu flex left-section" : "smallLeftMenu flex left-section"}>
      <div className="w-full h-full bg-blue relative rounded-tr-[4rem] text-primary-10 leftMenuContainer">
        <div className="mobileBrandAndLogo ">
          <Image
            src={logo}
            onClick={(e) => { dispatch(setSelectedCourse({ selectedCourse: {} })), dispatch(setSelectedPage({ selectedPage: "dashboard" })); handleClick(e, "/dashboard") }}
            alt="Paper-x logo"
            priority
            className={leftMenuIsOpen ? "" : "MobileItem"}
          />
          <div
            className="text-white mobileMenuButton"
            onClick={() =>
              setLeftMenuIsOpen(
                leftMenuIsOpen === true ? false : true
              )
            }
          >
            {leftMenuIsOpen === true ? (
              <svg
                width="30"
                height="30"
                viewBox="0 0 50 50"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M6.25 14.5833H43.75M6.25 25H43.75M6.25 35.4167H43.75"
                  stroke="white"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
              </svg>
            ) : (
              <svg
                width="30"
                height="30"
                viewBox="0 0 50 50"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M19.1042 30.8958L30.8959 19.1042M30.8959 30.8958L19.1042 19.1042M18.75 45.8333H31.25C41.6667 45.8333 45.8334 41.6667 45.8334 31.25V18.75C45.8334 8.33334 41.6667 4.16667 31.25 4.16667H18.75C8.33335 4.16667 4.16669 8.33334 4.16669 18.75V31.25C4.16669 41.6667 8.33335 45.8333 18.75 45.8333Z"
                  stroke="white"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}
          </div>
        </div>
        <div className="text-orange flex gap-x-2 py-4 pl-4  ml-4  items-center bg-primary right-0 rounded-l-full font-bold text-sm">
          <Image src={house} alt="House" width={25} height={25} />
          <div className={leftMenuIsOpen ? "" : "MobileItem"}>
            {selectedPage.charAt(0).toUpperCase() + selectedPage.slice(1)}
          </div>
        </div>
        <ul className="left-menu overflow-auto h-[70%] scrollbar">
          <BackToDashBoard />
          {((selectedCourseId === undefined || selectedCourseId === "") && courseList !== undefined) ? Object.entries(courseList).map((value, index) => {
            return (
              <li key={index} onClick={() => { dispatch(setSelectedCourse({ selectedCourse: value[1] })) }}>
                <div className="flex gap-x-2 my-8 font-normal">
                  <div className="ml-8">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M21.4899 10.1901L20.4899 9.64008L11.4899 4.64008H11.3799C11.3186 4.61416 11.255 4.59407 11.1899 4.58008H10.9999H10.8199C10.7516 4.59408 10.6846 4.61416 10.6199 4.64008H10.5099L1.50988 9.64008C1.35598 9.7273 1.22797 9.85378 1.13891 10.0066C1.04985 10.1595 1.00293 10.3332 1.00293 10.5101C1.00293 10.687 1.04985 10.8607 1.13891 11.0135C1.22797 11.1664 1.35598 11.2929 1.50988 11.3801L3.99988 12.7601V17.5001C3.99988 18.2957 4.31595 19.0588 4.87856 19.6214C5.44117 20.184 6.20423 20.5001 6.99988 20.5001H14.9999C15.7955 20.5001 16.5586 20.184 17.1212 19.6214C17.6838 19.0588 17.9999 18.2957 17.9999 17.5001V12.7601L19.9999 11.6401V14.5001C19.9999 14.7653 20.1052 15.0196 20.2928 15.2072C20.4803 15.3947 20.7347 15.5001 20.9999 15.5001C21.2651 15.5001 21.5194 15.3947 21.707 15.2072C21.8945 15.0196 21.9999 14.7653 21.9999 14.5001V11.0601C21.9996 10.8829 21.9522 10.7089 21.8626 10.5561C21.773 10.4032 21.6443 10.2769 21.4899 10.1901ZM15.9999 17.5001C15.9999 17.7653 15.8945 18.0196 15.707 18.2072C15.5194 18.3947 15.2651 18.5001 14.9999 18.5001H6.99988C6.73466 18.5001 6.48031 18.3947 6.29277 18.2072C6.10524 18.0196 5.99988 17.7653 5.99988 17.5001V13.8701L10.5099 16.3701L10.6599 16.4301H10.7499C10.8329 16.4405 10.9169 16.4405 10.9999 16.4301C11.0829 16.4405 11.1669 16.4405 11.2499 16.4301H11.3399C11.393 16.4189 11.4437 16.3986 11.4899 16.3701L15.9999 13.8701V17.5001ZM10.9999 14.3601L4.05988 10.5001L10.9999 6.64008L17.9399 10.5001L10.9999 14.3601Z" fill="#BAD6FF" />
                    </svg>
                  </div>
                  <span className={leftMenuIsOpen ? "" : "MobileItem"}>{value[1].name}</span>
                </div>
              </li>
            );
          }) : ""
          }
          {
            (selectedCourseId !== undefined && selectedCourseId !== "") ? Object.entries(pages).map((value, index) => {
              if (value[0] == "TA Assignment" && AmI.roles.includes("teacher")) {
                return (
                  <li key={index} onClick={(e) => { dispatch(setSelectedPage({ selectedPage: value[0] })); handleClick(e, "/" + value[1].url + "?courseId=" + selectedCourseId) }}>
                    <div className="flex gap-x-2 my-8 font-normal">
                      <div className="ml-8">
                        {value[1].left_svg}
                      </div>
                      <span className={leftMenuIsOpen ? "" : "MobileItem"}>{value[0]}</span>
                    </div>
                  </li>
                )
              }
              else if (value[0] != "TA Assignment") {
                return (
                  <li key={index} onClick={(e) => { dispatch(setSelectedPage({ selectedPage: value[0] })); handleClick(e, "/" + value[1].url + "?courseId=" + selectedCourseId) }}>
                    <div className="flex gap-x-2 my-8 font-normal">
                      <div className="ml-8">
                        {value[1].left_svg}
                      </div>
                      <span className={leftMenuIsOpen ? "" : "MobileItem"}>{value[0]}</span>
                    </div>
                  </li>
                )
              }

            }) : ""
          }
        </ul>
        <button onClick={() => { dispatch(LogOut()) }} >
          <div className="logout-button">
            <Image src={logout} alt="Logout" width={25} height={25} className="mr-2" />
            <span className={leftMenuIsOpen ? "" : "MobileItem"}>Logout</span>
          </div>
        </button>
      </div>
    </div >
  );
};

export default React.memo(LeftSection);
