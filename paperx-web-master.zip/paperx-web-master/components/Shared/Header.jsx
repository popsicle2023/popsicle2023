import Image from "next/image";
import React, { useEffect, useState } from "react";
import profile from "../../public/assets/img/dash-board/profile.png";
import { useSelector } from "react-redux";
import UserSevice from "../../services/UserSevice";
const Header = () => {
  const selectedPage = useSelector((store) => store.pageSettings.selectedPage);
  const selectedCourse = useSelector(
    (store) => store.pageSettings.selectedCourse
  );
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
  useEffect(() => {
    if (AmI == undefined) {
      async () => await SetAmI(UserSevice.WhoAmI());
    }
  });
  return (
    <div className="flex justify-between items-center relative  pr-4 pl-4">
      <div className="flex items-center">
        {selectedCourse != undefined ? (
          <div className="pageTitle">{selectedCourse.name}</div>
        ) : (
          <div></div>
        )}
        {selectedPage.charAt(0).toUpperCase() + selectedPage.slice(1)}
      </div>
      <div className=" ml-4 bg-white  flex justify-center items-center rounded-full shadow-lg mt-4  px-6 py-2 ">
        <Image src={profile} alt="Profile Photo" />
        <span className="font-medium text-sm mx-1">{AmI && AmI.displayName}</span> |
        <span className="text-gray text-xs mx-1">University of Rochester</span>
      </div>
    </div>
  );
};

export default React.memo(Header);
