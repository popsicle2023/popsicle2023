import Head from "next/head";
import LeftSection from "./LeftSection";
import Header from "./Header";
export const siteTitle = "PaperX";
import { ToastContainer } from 'react-toastify';
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setSelectedCourse, setSelectedPage } from "../../slices/course-list";
import { useRouter } from "next/router";
import api from '../../api'
export default function Layout({ children }) {
  const dispatch = useDispatch();
  const router = useRouter();
  useEffect(() => {
    if (window.location.href.split("courseId=")[1] !== undefined) {
      api.get('/api/course/' + window.location.href.split("courseId=")[1]).then((res) => {
        dispatch(setSelectedCourse({ selectedCourse: res.data.result }))
      })
    }
    dispatch(setSelectedPage({ selectedPage: router.pathname.slice(1) }))
  }, [])

  return (
    <>
      <Head>
        {/* Head ici komple gozden gecirilecek */}
        <meta
          name="description"
          content="Learn how to build a personal website using Next.js"
        />
        <meta
          property="og:image"
          content={`https://og-image.vercel.app/${encodeURI(
            siteTitle
          )}.png?theme=light&md=0&fontSize=75px&images=https%3A%2F%2Fassets.vercel.com%2Fimage%2Fupload%2Ffront%2Fassets%2Fdesign%2Fnextjs-black-logo.svg`}
        />
        <meta name="og:title" content={siteTitle} />
        <meta name="twitter:card" content="summary_large_image" />
      </Head>
      <ToastContainer />
      <div className="flex w-full h-full overflow-x-hidden" >
        <LeftSection />
        <div className="layoutContent relative">
          <div className="bg-none ">
            <Header></Header>
          </div>
          {children}
        </div>
      </div>
    </>
  );
}
