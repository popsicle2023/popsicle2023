import React, { useEffect, useState } from "react";

const Tabs = ({ children, setTabs }) => {
  const [activeTab, setActiveTab] = useState(0);
  const handleTabClick = (index) => {
    setActiveTab(index);
  };
  // useEffect(() => {
  //   activeTab === 0 ? setTabs("videos") : setTabs("printeds");
  // }, [activeTab]);

  return (
    <div>
      <div className="mb-[2.13rem] ml-8">
        {children.map(
          (child, index) =>
            child && (
              <span
                key={index}
                onClick={() => handleTabClick(index)}
                className={`tab-title p-2 mr-8  cursor-pointer ${
                  index === activeTab
                    ? " border-b-4 border-orange"
                    : "text-[#5C656A]"
                }`}
              >
                {child.props.label}
              </span>
            )
        )}
      </div>
      <div>{children[activeTab]}</div>
    </div>
  );
};

export default Tabs;
