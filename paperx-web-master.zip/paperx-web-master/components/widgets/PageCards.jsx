import { useRouter } from 'next/router';
import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedPage } from "../../slices/course-list";

const PageCards = () => {
    const pages = useSelector((store) => store.pageSettings.pageContent[1].pages.page_details);
    const selectedCourseId = useSelector((store) => store.pageSettings.selectedCourseId);
    const dispatch = useDispatch();
    const router = useRouter();
    function handleClick(_, href) {
        router.push(href)
    }
    if (selectedCourseId !== undefined && selectedCourseId !== "")
        return (
            <>
                <div className="flex w-full flex-wrap">
                    {
                        Object.entries(pages).map(function (value, index) {
                            return (
                                <div key={index} className="mt-4 w-1/2" onClick={(e) => { dispatch(setSelectedPage({ selectedPage: value[0] })); handleClick(e, "/" + value[1].url + "?courseId=" + selectedCourseId) }}>
                                    <div className='bg-white relative justify-center items-center flex flex-col basis-[100%] h-md rounded-3xl my-2 mx-4 p-4 cursor-pointer shadow-lg text-center'>
                                        {value[1].main_svg}
                                        <div className="mt-2 font-semibold">{value[0]}</div>
                                        <div className="font-light text-sm">
                                            {value[1].description}
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </>
        );
}

export default PageCards