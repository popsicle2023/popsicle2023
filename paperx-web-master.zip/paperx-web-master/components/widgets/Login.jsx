import { Button, Checkbox, Label, Modal, TextInput } from 'flowbite-react';
import React, { useState } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import AuthService from '../../services/AuthService';

function Login() {

    const [IsActive, SetIsActive] = useState(false);
    function onOpen() {
        SetIsActive(true);
    }
    function onClose() {
        SetIsActive(false);
    }
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [rememberMe, setRememberMe] = useState(false);
    const [newPassword, setNewPassword] = useState("");
    const [newPasswordAgain, setNewPasswordAgain] = useState("");

    var [requirePasswordChange, setrequirePasswordChange] = useState(false);
    const login = async () => {
        if (email != "" && password != "") {
            var response = await AuthService.login(email, password, rememberMe)
            if (response != null)
                if (response.data.result.requirePasswordChange) {
                    setrequirePasswordChange(response.data.result.requirePasswordChange)
                }
                else {
                    window.location.href = "/dashboard"
                }
        }
    }
    const reset = async () => {
        if (newPassword == newPasswordAgain) {
            if ((await AuthService.resetPassword(newPassword)).response != undefined) {
                var response = await AuthService.login(email, password, rememberMe)
                if (response != null)
                    window.location.href = "/dashboard"
            }
        }
        else
            toast.error("passwords do not match", "Error!")
    }
    return (
        <>
            <ToastContainer />
            <Button onClick={onOpen} className='button-orange'>
                Login
            </Button>
            <Modal show={IsActive} size="xl" popup={true} onClose={onClose}>
                <Modal.Header />
                <Modal.Body>
                    {
                        !requirePasswordChange &&
                        <div className="container">
                            <div className="flex justify-center">
                                <span className="modal-title">Log In to Your Account</span>
                            </div>
                            <div className="flex flex-col gap-4 mt-4">
                                <div>
                                    <div className="mb-2 block">
                                        <Label
                                            htmlFor="email"
                                            value="Email Address"
                                        />
                                    </div>
                                    <TextInput
                                        id="email"
                                        type="text"
                                        placeholder="Email Address"
                                        required={true}
                                        shadow={true}
                                        value={email}
                                        onChange={(e) => { setEmail(e.target.value); }}
                                    />
                                </div>
                                <div>
                                    <div className="mb-2 block">
                                        <Label
                                            htmlFor="password"
                                            value="Password"
                                        />
                                    </div>
                                    <TextInput
                                        id="password"
                                        type="password"
                                        placeholder="Password"
                                        required={true}
                                        shadow={true}
                                        value={password}
                                        onChange={(e) => { setPassword(e.target.value); }}
                                    />
                                </div>
                                <div className="flex justify-between gap-2">
                                    <div>
                                        <Checkbox id="agree" onChange={(e) => setRememberMe(e.target.checked)} />
                                        <Label htmlFor="agree" className='ml-2'>
                                            Remember Me
                                        </Label>
                                    </div>
                                    <a href="#" className="text-blue-600 hover:underline dark:text-blue-500">
                                        Forgot Password
                                    </a>
                                </div>
                                <Button className='button-orange' onClick={login}>
                                    Log In
                                </Button>
                            </div>
                        </div>
                    }
                    {
                        requirePasswordChange &&
                        <div className="container">
                            <div className="flex justify-center">
                                <span className="modal-title">You Have To Reset Password</span>
                            </div>
                            <div className="flex flex-col gap-4 mt-4">
                                <div>
                                    <div className="mb-2 block">
                                        <Label
                                            value="Password"
                                        />
                                    </div>
                                    <TextInput
                                        type="password"
                                        placeholder="Password"
                                        required={true}
                                        shadow={true}
                                        value={newPassword}
                                        onChange={(e) => { setNewPassword(e.target.value); }}
                                    />
                                </div>
                                <div>
                                    <div className="mb-2 block">
                                        <Label
                                            value="Password Again"
                                        />
                                    </div>
                                    <TextInput
                                        type="password"
                                        placeholder="Password again"
                                        required={true}
                                        shadow={true}
                                        value={newPasswordAgain}
                                        onChange={(e) => { setNewPasswordAgain(e.target.value); }}
                                    />
                                </div>
                                <Button type='button' className='button-orange' onClick={reset}>
                                    Reset Password
                                </Button>
                            </div>
                        </div>
                    }
                </Modal.Body>
            </Modal>
        </>
    );
}

export default Login