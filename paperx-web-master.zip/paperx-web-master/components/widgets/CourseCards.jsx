import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { setSelectedCourse } from "../../slices/course-list";
import cap from '../../public/assets/img/dash-board/poligon_grad_cap.png'
import Image from 'next/image';
import Dropdown from './dropdown/Dropdown';
import AddNewCourseModal from './AddNewCourseModal';
function CourseCards({ AmI }) {
    const dispatch = useDispatch();
    const selectedCourseId = useSelector((store) => store.pageSettings.selectedCourseId);
    const courseList = useSelector((store) => store.pageSettings.courseList);
    if ((selectedCourseId === undefined || selectedCourseId === "") && courseList !== undefined)
        return (
            <>
                <div className="flex justify-between mx-4 mt-10 flex-wrap">
                    <div className='subTitle'>Course List</div>
                    <Dropdown />
                </div>
                <div className="flex w-full flex-wrap scrollbar h-[40vh] md:h-[60vh] overflow-auto" >
                    {
                        courseList.map(function (value, index) {
                            return (
                                <div key={index} className="mt-4 w-1/2" onClick={() => { dispatch(setSelectedCourse({ selectedCourse: value })) }}>
                                    <div className='bg-white relative justify-center items-center flex flex-col basis-[100%] h-md rounded-3xl my-2 mx-4 p-4 cursor-pointer shadow-lg text-center'>
                                        <Image src={cap} alt="course element" />
                                        <div className="mt-2 font-semibold">{value.name}</div>
                                        <div className="font-light text-sm">
                                            {value.departmentName}
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <div className="flex justify-end align-end">
                    {!AmI.roles.includes("student") && <AddNewCourseModal />}
                </div>
            </>
        )
}

export default CourseCards