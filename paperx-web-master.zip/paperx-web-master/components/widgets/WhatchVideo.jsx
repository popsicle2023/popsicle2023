import ReactPDF from "@react-pdf/renderer";
import { Modal } from "flowbite-react";
import React from "react";
import { useState } from "react";

const WhatchVideo = ({ video, closePopup, printed, tab }) => {
  console.log(video, closePopup, tab, printed);
  const PDFViewer = () => {
    return (
      <ReactPDF.PDFViewer
        src={`/api/file/${printed.name}`}
        width="100%"
        height="800px"
      ></ReactPDF.PDFViewer>
    );
  };
  const ImageViewer = () => {
    return <img src={`/api/file/${printed.name}`}></img>;
  };
  return (
    <div className="font-sans mt-4 m">
      <Modal show={true} size="4xl" popup={true} onClose={closePopup}>
        <Modal.Header />
        <Modal.Body>
          <div className="container">
            {tab === "videos" ? (
              <video controls>
                <source src={`/api/file/${video}`} type="video/mp4" />
              </video>
            ) : printed.mimeType === "application/pdf" ? (
              <PDFViewer />
            ) : (
              <ImageViewer />
            )}
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default WhatchVideo;
