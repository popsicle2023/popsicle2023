import React, { useEffect, useState } from "react";
import { Button, Modal, TextInput } from "flowbite-react";
import Dropdown from "./selectbox/Dropdown";
import { useDispatch, useSelector } from "react-redux";
import HelperService from "../../services/HelperService";
import { setCourses, setDepartments, setSchools } from "../../slices/helper"
import { setCourseList } from "../../slices/course-list"
import CourseService from "../../services/CourseService";
import { toast } from 'react-toastify';

const AddNewCourseModal = () => {
  const [IsActive, SetIsActive] = useState(false);
  function onOpen() {
    SetIsActive(true);
  }
  function onClose() {
    SetIsActive(false);
  }
  const dispatch = useDispatch();
  // const courses = useSelector((store) => store.helperReducer.courses);
  const schools = useSelector((store) => store.helperReducer.schools);
  const departments = useSelector((store) => store.helperReducer.departments);
  const getPageData = async () => {
    dispatch(
      setCourses({ courses: (await HelperService.GetCourses()).data.result.data })
    )
    dispatch(
      setDepartments({ departments: (await HelperService.GetDepartments()).data.result.data })
    )
    dispatch(
      setSchools({ schools: (await HelperService.GetSchools()).data.result.data })
    )
  }
  useEffect(() => {
    getPageData()
  }, [])

  const addNewCourse = async () => {
    if (form.name != "" && form.departmentName != "" && form.schoolName != "") {
      toast.success(`New Course Added`, `Success`, {
        closeButton: true,
      })
      SetIsActive(false);
      await CourseService.AddCourse(form)
      dispatch(setCourseList({ courseList: (await CourseService.GetCourseList()).data.result.data }))
    }
  }

  const [form, setForm] = useState({
    schoolName: "",
    departmentName: "",
    name: "",
  });

  return (
    <div className="font-sans mt-4 m">
      <button className="text-cardblue border border-cardblue border-dashed w-md rounded-3xl my-2 mx-4 p-4" onClick={onOpen}>
        + Create New Course
      </button>
      <Modal show={IsActive} size="4xl" popup={true} onClose={onClose}>
        <Modal.Header />
        <Modal.Body>
          <div className="container">
            <div className="flex justify-center">
              <span className="modal-title">Create New Course</span>
            </div>
            <div className="mt-7">
              <span className="form-title">
                General Information{" "}
              </span>
            </div>
            <div className="flex justify-between">
              <div className="mt-5 mr-5 w-6/12">
                <label>School Name</label>
                <Dropdown
                  isSearchable
                  placeHolder="Select..."
                  name="schoolName"
                  options={schools}
                  onChange={(value) => setForm({ ...form, schoolName: value.name })}
                />
              </div>
              <div className="mt-5 w-6/12">
                <label>Department Name</label>
                <Dropdown
                  isSearchable
                  placeHolder="Select..."
                  name="departmentName"
                  options={departments}
                  onChange={(value) => setForm({ ...form, departmentName: value.name })}
                />
              </div>
            </div>
            <div className="flex justify-between">
              <div className="mt-5 mr-5 w-6/12">
                <label>Course Name</label>
                <TextInput type="text" name="name" sizing="sm" onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="mt-5 w-6/12"></div>
            </div>
            <div className="mt-12 flex justify-center">
              <Button id="savebutton" className="button-orange" disabled={form.departmentName == "" || form.name == "" || form.schoolName == "" ? true : false} onClick={() => { addNewCourse() }}>
                Create New Course
              </Button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div >
  );
};

export default AddNewCourseModal;
