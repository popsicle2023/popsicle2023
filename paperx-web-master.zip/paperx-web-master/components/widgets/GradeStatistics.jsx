import React from 'react'
import Image from 'next/image'
import Staticits from "../../public/assets/img/grading/staticits.png";
function GradeStatistics({ data }) {
    return (
        <>
            <div className='bg-primary-0 relative  rounded-3xl my-8 mx-4  p-4 py-10  px-8 shadow-lg'>
                <div className="flex flex-col lg:flex-row   w-11/12">
                    <div className='flex flex-row   lg:flex-col w-1/6'><span className='staticitsKey'>Minimum:</span><span className="staticitsValue lg:mt-3">{data.Minimum}</span></div>
                    <div className='flex flex-row pt-2 lg:pt-0   lg:flex-col w-1/6'><span className='staticitsKey'>Median:</span><span className="staticitsValue lg:mt-3">{data.Median}</span></div>
                    <div className='flex flex-row  pt-2 lg:pt-0  lg:flex-col w-1/6'><span className='staticitsKey'>Maximum:</span><span className="staticitsValue lg:mt-3">{data.Maximum}</span></div>
                    <div className='flex flex-row pt-2 lg:pt-0  lg:flex-col w-1/6'><span className='staticitsKey'>Mean:</span><span className="staticitsValue lg:mt-3">{data.Mean}</span></div>
                    <div className='flex flex-row pt-2 lg:pt-0  lg:flex-col w-1/6'><span className='staticitsKey'>Std Dev:</span><span className="staticitsValue lg:mt-3">{data.StdDev}</span></div>
                </div>
                <Image src={Staticits} alt="Grading Staticits" className='absolute right-0 bottom-0   staticitsImage ' />
            </div>
        </>
    )
}

export default GradeStatistics