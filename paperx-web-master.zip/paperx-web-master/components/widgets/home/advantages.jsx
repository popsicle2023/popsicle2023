import Image from "next/image";
import React, { useRef, useEffect, useState } from "react";
import divider from "../../../public/assets/img/advantages/divider.png";
import advantages from "../../../public/assets/img/advantages/advantages.png";
import background from "../../../public/assets/img/advantages/background.png";

const Advantages = (id) => {
  return (
    <div
      className="advantages h-[88.3vh] flex items-center relative px-16 pb-4 overflow-hidden"
      id={id.id}
    >
      <div>
        <div className="title mb-6">
          <h2>Advantages</h2>
          <Image src={divider} alt="divider" />
        </div>
        <Image src={advantages} alt="advantages" />
        <Image
          src={background}
          alt="background"
          className="absolute right-0 -z-10 xl:inset-y-96 top-[550px]"
        />
      </div>
    </div>
  );
};

export default Advantages;
