import React, { useState } from "react";
import navbarTitles from "../../../utils/menuItems";
import Image from "next/image";
import logo from "../../../public/assets/img/logo.svg";
import Login from "../Login";
import Link from "react-scroll/modules/components/Link";
import { Sidebar } from "flowbite-react";

const Header = () => {
  const [navbar, setNavbar] = useState(false);
  const changeBackground = () => {
    if (window.scrollY >= 1) setNavbar(true);
    else setNavbar(false);
  };
  if (typeof window !== "undefined") {
    window.addEventListener("scroll", changeBackground);
  }
  // const smallHeight = "14";
  // const headerHeight = {
  //   sm: `h-[${smallHeight / wr.sm}vh]`,
  //   md: `h-[${smallHeight}vh]`,
  //   lg: `h-[15vh]`,
  //   xl: `h-[15vh]`,
  //   "2xl": `h-[15vh]`,
  // };
  // console.log(wr.sm / 2);
  const [visibilityPopUp, setVisibilityPopUp] = useState("hidden");
  return (
    <header
      className={`${
        navbar
          ? `p-4 lg:py-0 xl:px-0 fixed top-0 xl:w-full bg-white h-[14vh] md:h-[11.7vh] z-50 shadow-lg ease-in duration-500 flex justify-center items-center w-[100vh] md:w-full`
          : `p-4 lg:py-0 xl:px-0 fixed top-0 xl:w-full bg-transparent h-[14vh] md:h-[11.7vh] z-50 transition-shadow ease-in duration-500 flex justify-center items-center w-[100vh] md:w-full`
      } `}
    >
      <div className="relative w-full">
        <div
          className="absolute md:static md:hidden -top-4 left-4"
          onClick={() =>
            setVisibilityPopUp(
              visibilityPopUp === "hidden" ? "block" : "hidden"
            )
          }
        >
          {visibilityPopUp === "hidden" ? (
            <svg
              width="50"
              height="50"
              viewBox="0 0 50 50"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M6.25 14.5833H43.75M6.25 25H43.75M6.25 35.4167H43.75"
                stroke="black"
                strokeWidth="4"
                strokeLinecap="round"
              />
            </svg>
          ) : (
            <svg
              width="50"
              height="50"
              viewBox="0 0 50 50"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M19.1042 30.8958L30.8959 19.1042M30.8959 30.8958L19.1042 19.1042M18.75 45.8333H31.25C41.6667 45.8333 45.8334 41.6667 45.8334 31.25V18.75C45.8334 8.33334 41.6667 4.16667 31.25 4.16667H18.75C8.33335 4.16667 4.16669 8.33334 4.16669 18.75V31.25C4.16669 41.6667 8.33335 45.8333 18.75 45.8333Z"
                stroke="black"
                stroke-width="4"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          )}
        </div>
        <div
          className={`w-fit absolute md:static md:hidden top-7 left-3 ${visibilityPopUp}`}
        >
          <Sidebar>
            <Sidebar.Items>
              <Sidebar.ItemGroup>
                {navbarTitles[0].titles.map((item, index) => (
                  <Link
                    activeClass="active"
                    to={item}
                    spy={true}
                    smooth={true}
                    offset={
                      index === navbarTitles[0].titles.length - 1 ? 450 : -120
                    }
                    duration={500}
                    onClick={() =>
                      setVisibilityPopUp(
                        visibilityPopUp === "hidden" ? "block" : "hidden"
                      )
                    }
                  >
                    <Sidebar.Item key={index}>{item}</Sidebar.Item>
                  </Link>
                ))}
              </Sidebar.ItemGroup>
            </Sidebar.Items>
          </Sidebar>
        </div>
        <nav className="container flex justify-between max-w-5xl">
          <Image
            src={logo}
            className="nav-logo md:static absolute right-4 -top-4"
            alt="Logo"
            priority
          />
          <ul className="md:flex md:items-center md:space-x-4 xl:space-x-8 hidden">
            {navbarTitles[0].titles.map((item, index) => (
              <Link
                activeClass="active"
                to={item}
                spy={true}
                smooth={true}
                offset={
                  index === navbarTitles[0].titles.length - 1 ? 450 : -150
                }
                duration={500}
                key={index}
              >
                <li>{item}</li>
              </Link>
            ))}
            <li>
              <Login></Login>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
