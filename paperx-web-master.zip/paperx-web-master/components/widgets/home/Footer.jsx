import Image from "next/image";
import React from "react";
import footerBackground from "../../../public/assets/img/footer/footer-background.svg";
import footer from "../../../public/assets/img/footer/footer-logo.svg";
import Link from "react-scroll/modules/components/Link";
import navbarTitles from "../../../utils/menuItems";
//footer linklerinden error
const Footer = () => {
  return (
    <footer
      style={{
        backgroundColor: "#263878",
        backgroundImage: `url(${footerBackground})`,
      }}
      className="relative"
      id="landing-footer"
    >
      <div className="md:flex pl-24 pr-24 pt-5 pb-5 container">
        <div className="p-5">
          <Image src={footer} alt="paper-x" />
        </div>
        <div
          className="text-white md:flex md:gap-16 md:ml-20"
          style={{ flexBasis: "40%" }}
        >
          <div className="footer-head flex-">
            <div variant="h6" color="inherit">
              <b>PAPER X</b>
            </div>
            <div className="p-1">
              <Link to="section3" offset={-70} duration={500}>
                <div
                  variant="body2"
                  color="inherit"
                  display="inline"
                  className="cursor-pointer"
                >
                  About
                </div>
              </Link>
            </div>
            <div className="p-1">
              <Link to="section4" offset={-70} duration={500}>
                <div
                  variant="body2"
                  color="inherit"
                  display="inline"
                  style={{ cursor: "pointer" }}
                >
                  Advantages
                </div>
              </Link>
            </div>
            <div className="p-1">
              <div variant="body2" color="inherit">
                Pricing
              </div>
            </div>
          </div>
          <div className="footer-head">
            <div variant="h6" color="inherit">
              <b>COMPANY</b>
            </div>
            <div className="p-1">
              <div variant="body2" color="inherit">
                Jobs
              </div>
            </div>
            <div className="p-1">
              <Link to="section5" offset={-70} duration={500}>
                <div
                  variant="body2"
                  color="inherit"
                  display="inline"
                  className="cursor-pointer"
                >
                  Contact Us
                </div>
              </Link>
            </div>
            <div className="p-1">
              <div variant="body2" color="inherit">
                Blog
              </div>
            </div>
          </div>
          <div className="footer-head">
            <div variant="h6" color="inherit">
              <b>LEGAL</b>
            </div>
            <div className="p-1">
              <div variant="body2" color="inherit">
                Terms & Conditions
              </div>
            </div>
            <div className="p-1">
              <div variant="body2" color="inherit">
                Privacy Policy
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container text-white pl-24 pr-24">
        <div align="right" color="inherit">
          <b>paper X</b>
          &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;All rights reserved.
          © 2021
        </div>
      </div>
      <Link
        activeClass="active"
        to={navbarTitles[0]?.titles[0]}
        spy={true}
        smooth={true}
        offset={-150}
        duration={500}
      >
        <div className="absolute -top-10 right-5">
          <svg
            width="60"
            height="60"
            viewBox="0 0 60 60"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M54.9998 19.8V40.225C54.9998 49.05 49.3223 55 40.8498 55H19.1748C10.6998 55 4.99976 49.05 4.99976 40.225V19.8C4.99976 10.95 10.6998 5 19.1748 5H40.8498C49.3223 5 54.9998 10.95 54.9998 19.8ZM28.1248 24.325V40.2C28.1248 41.25 28.9748 42.075 29.9998 42.075C31.0498 42.075 31.8748 41.25 31.8748 40.2V24.325L38.0498 30.525C38.3998 30.875 38.8998 31.075 39.3748 31.075C39.8473 31.075 40.3248 30.875 40.6998 30.525C41.4248 29.8 41.4248 28.6 40.6998 27.875L31.3248 18.45C30.6248 17.75 29.3748 17.75 28.6748 18.45L19.2998 27.875C18.5748 28.6 18.5748 29.8 19.2998 30.525C20.0498 31.25 21.2248 31.25 21.9748 30.525L28.1248 24.325Z"
              fill="#DF6B2E"
            />
          </svg>
        </div>
      </Link>
    </footer>
  );
};

export default Footer;
