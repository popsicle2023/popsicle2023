import Image from "next/image";
import React from "react";
import video from "../../../public/assets/img/demo/Video.png";
import divider from "../../../public/assets/img/demo/divider.png";
import Link from "next/link";

const Demo = (id) => {
  return (
    <demo
      className="demo h-[150vh] md:h-[88.3vh] bg-demo bg-no-repeat bg-cover flex bg-center items-center px-16 md:my-0 w-full md:w-full pb-16px pl-8 my-36"
      id={id.id}
    >

      <div className="font-sans text-3xl font-semibold">
        <div className="title">
          <h2 className="no-underline">Demo</h2>
          <Image src={divider} alt="divider" />
        </div>
        <div className="demo-thumbnail-wrapper ">
          <Image
            src={video}
            alt="demo video thumbnail"
            id="demo-section-thumbnail"
            className="h-full max-w-full "
          />
        </div>
      </div>
    </demo>
  );
};

export default Demo;
