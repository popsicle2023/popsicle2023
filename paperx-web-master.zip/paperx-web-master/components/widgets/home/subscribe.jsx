import Image from "next/image";
import React from "react";
import community from "../../../public/assets/img/community/community.svg";

const Subscribe = (id) => {
  return (
    <div
      className="subscribe-section p-16 h-[88.3vh] mt-6 flex justify-between items-center"
      id={id.id}
    >
      <div>
        <div className="left">
          <h3 className="font-bold text-5xl my-4 leading-[72px]">
            Join Our Community!
          </h3>
          <p className="mb-8">
            For pricing and other details:
            <a
              id="sub-join-by-mail"
              href="mailto:info@paper-x.com"
              target="_newtab"
            >
              info@paper-x.com
            </a>
          </p>
        </div>
        <div className="h-[67px] w-[611px] bg-white my-4 relative rounded-full flex items-center p-5 shadow-l">
          <input
            type="text"
            placeholder="Your email address"
            className="border-0 rounded-full"
          />
          <div className="absolute top-0 right-0 w-[199px] h-[67px] rounded-full flex items-center justify-center bg-blue-10 text-white">
            Subscribe
          </div>
        </div>
      </div>
      <div className="right">
        <Image src={community} alt="community" />
      </div>
    </div>
  );
};

export default Subscribe;
