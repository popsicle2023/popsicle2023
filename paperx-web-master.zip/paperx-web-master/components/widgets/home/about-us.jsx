import Image from "next/image";
import React from "react";
import divider from "../../../public/assets/img/about-us/divider.png";
import points from "../../../public/assets/img/about-us/points.png";
import business from "../../../public/assets/img/about-us/business.png";
const AboutUs = (id) => {
  return (
    <div className="px-16 my-16" id={id.id}>
      <div className="title">
        <h2>About PaperX</h2>
        <Image src={divider} alt="divider" />
      </div>
      <div className="first-paragraph">
        <p>
          <i>
            <b>
              An innovative, user-friendly and environmentally conscious online
              education management platform
            </b>
          </i>
        </p>
        <p>
          <br />
          PaperX extends and enhances the features of a traditional learning
          management system, integrating everything students and educators need
          for learning into a single, easy-to-use online education platform, all
          while eliminating unnecessary paper usage and contributing to a
          greener world.
          <br />
          <br />
          At PaperX, we believe that a learning management system should enrich
          the learning experience by providing a user-friendly platform which
          simplifies administrative management for educators while increasing
          transparency between students and their learning. We facilitate the
          opportunity for students to enjoy a secure and paperless online
          education, and at the same time make the online education process
          easier for educators to oversee.
          <br />
          <br />
          By providing all of one’s needs for learning management on one single
          platform, PaperX streamlines the education process for both educators
          and students, allowing them to focus on teaching and learning.
        </p>
        <p>
          <br />
          <b>Everything you need, all in one place</b>
          <br />
          <br />
          PaperX provides all of the features of traditional learning management
          systems, such as allowing students access to course resources and
          communications, while enhancing this with many additions for
          educators’ convenience. These include an intuitive system for
          educators to manage grades and provide feedback, online completion and
          submission of assignments, built in video conferencing, a
          self-proctoring and anti-cheat system for exams, opportunities for
          students to easily communicate with teachers and professors, and much
          more. The multifaceted nature of the PaperX platform reduces the need
          to use a variety of external tools and software to supplement online
          education management.
        </p>
        <p>
          <br />
          <b>A Paperless Education</b>
          <br />
          <br />
          We eliminate the time-consuming process of scanning and uploading
          handwritten assignments, exams, homework and the like, by allowing
          students to be assigned and complete quizzes, assignments or exams
          directly on the PaperX platform through the use of tablets,
          touchscreen devices or computers. Simultaneously, we offer a variety
          of tools for educators to grade, annotate and evaluate their students’
          work, making the often frustrating process of providing feedback
          online simple and intuitive. Not only is this process convenient for
          both students and educators, it also has the benefit of preventing
          unnecessary paper use and promoting a paperless online education,
          helping the environment. A win-win.
        </p>
        <p>
          <br />
          <br />
          <b>An Easier Grading Process</b>
          <br />
          <br /> PaperX greatly streamlines and modernizes the process of
          grading for educators. Our secure grading system automatically records
          the grades of assignments which are completed and marked on the PaperX
          platform into a built-in database. By eliminating the need for
          external spreadsheets and manual entry of grades, we save time for
          educators while also reducing errors. Furthermore, a wide array of
          data and statistics provides students with transparency about their
          grades and allows them to track the progress that they are making.
          Grading on the PaperX online education platform is intuitive and
          quick, eliminating the often lengthy and confusing current grading
          processes and enabling educators to spend more of their time on their
          students’ learning.
        </p>
      </div>
      <Image src={points} alt="Points" className="my-4" />
      <Image src={business} alt="Business" className="mb-4" />
    </div>
  );
};

export default AboutUs;
