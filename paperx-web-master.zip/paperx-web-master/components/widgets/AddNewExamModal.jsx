import React, { useEffect } from "react";
import { useState } from "react";
import {
  Button,
  Checkbox,
  Label,
  Modal,
  Radio,
  TextInput,
} from "flowbite-react";
import Dropdown from "./selectbox/Dropdown";
import DatePicker from "react-datepicker";
import calendarPng from "../../public/assets/img/exams/calendar.png";
import hourPng from "../../public/assets/img/exams/hour.png";
import infoPng from "../../public/assets/img/exams/info.png";
import closePng from "../../public/assets/img/exams/close.png";
import Image from "next/image";
import ExamService from "../../services/exams";
import { useDispatch, useSelector } from "react-redux";
import { setExamList } from "../../slices/exams";

const AddNewExamModal = () => {
  const exams = useSelector((store) => store.examReducer.examList);
  const [IsActive, SetIsActive] = useState(false);
  function onOpen() {
    SetIsActive(true);
  }
  function onClose() {
    SetIsActive(false);
  }
  const [startDate, setStartDate] = useState(new Date());

  const dispatch = useDispatch();
  const getPageData = async () => {
    dispatch(
      setExamList({
        examList: (await ExamService.GetExamList()).data.result.data,
      })
    );
  };
  useEffect(() => {
    getPageData();
  }, []);

  const addNewExam = async () => {
    if (form.examName != "" && form.whoWillUploadSubmissions != "" && form.releaseDate != "") {
      // toast.success(`New Course Added`, `Success`, {
      //   closeButton: true,
      // });
      // SetIsActive(false);

      // CourseService.AddCourse(form);
      // dispatch(
      //   setCourseList({
      //     courseList: (await CourseService.GetCourseList()).data.result.data,
      //   })
      // );
      console.log(form)
    }
  };

  const [form, setForm] = useState({
    examName: 'asd',
    whoWillUploadSubmissions: "asd",
    releaseDate: "asd",
    releaseDateEdt: "",
    dueDate: "",
    dueDateEdt: "",
    allowLateSubmissions: "",
    lateDueDate: "",
    lateDueDateEdt: "",
    submissionType: "",
    groupSubmission: false,
    limitGroupSize: "",
    fileVisibility: false,
  });

  const sections = "flex items-center md:w-6/12 mb-2 md:mb-0";

  return (
    <React.Fragment>
      <button
        className="flex px-[4.625rem] py-4 mt-7 border-dashed border-2 rounded-full border-indigo-600 text-center font-sans text-base"
        onClick={onOpen}
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="mr-[0.625rem]"
        >
          <path
            d="M19 11H13V5C13 4.73478 12.8946 4.48043 12.7071 4.29289C12.5196 4.10536 12.2652 4 12 4C11.7348 4 11.4804 4.10536 11.2929 4.29289C11.1054 4.48043 11 4.73478 11 5V11H5C4.73478 11 4.48043 11.1054 4.29289 11.2929C4.10536 11.4804 4 11.7348 4 12C4 12.2652 4.10536 12.5196 4.29289 12.7071C4.48043 12.8946 4.73478 13 5 13H11V19C11 19.2652 11.1054 19.5196 11.2929 19.7071C11.4804 19.8946 11.7348 20 12 20C12.2652 20 12.5196 19.8946 12.7071 19.7071C12.8946 19.5196 13 19.2652 13 19V13H19C19.2652 13 19.5196 12.8946 19.7071 12.7071C19.8946 12.5196 20 12.2652 20 12C20 11.7348 19.8946 11.4804 19.7071 11.2929C19.5196 11.1054 19.2652 11 19 11Z"
            fill="#3A5AFF"
          />
        </svg>
        <div className="text-blue-10">Create New Exam</div>
      </button>
      <Modal show={IsActive} size="5xl" popup={true}>
        <Modal.Body>
          <div className="sticky h-32 bg-white z-10 left-1/2 right-1/2 top-16 ">
            <span className="modal-title flex place-content-center h-full flex-wrap">
              Create New Exam
              <div
                className="absolute inset-y-0 right-10 -top-10 flex items-center pr-2 cursor-pointer z-30"
                onClick={onClose}
              >
                <Image src={closePng} alt="close" className="h-5 w-5" />
              </div>
            </span>
          </div>
          <div className="container space-y-6 pb-4 sm:pb-6 xl:pb-8">
            <div className="overflow-y-auto h-[50vh] relative pt-4 px-8">
              <div>
                <div className="text-base font-black my-2">
                  General Information
                </div>
                <div className="md:flex md:items-center gap-10">
                  <div className={sections}>
                    <span className="mr-2">Name:</span>
                    <TextInput
                      id="general-information"
                      type="text"
                      required={true}
                      className="w-full"
                      onChange={(e)=>setForm({ ...form, examName: e.target.value })}
                    />
                  </div>
                  <div className={sections}>
                    <span className="mr-2">
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M21 8.94C20.9896 8.84813 20.9695 8.75763 20.94 8.67V8.58C20.8919 8.47718 20.8278 8.38267 20.75 8.3L14.75 2.3C14.6673 2.22222 14.5728 2.15808 14.47 2.11C14.4402 2.10576 14.4099 2.10576 14.38 2.11C14.2784 2.05174 14.1662 2.01434 14.05 2H10C9.20435 2 8.44129 2.31607 7.87868 2.87868C7.31607 3.44129 7 4.20435 7 5V6H6C5.20435 6 4.44129 6.31607 3.87868 6.87868C3.31607 7.44129 3 8.20435 3 9V19C3 19.7956 3.31607 20.5587 3.87868 21.1213C4.44129 21.6839 5.20435 22 6 22H14C14.7956 22 15.5587 21.6839 16.1213 21.1213C16.6839 20.5587 17 19.7956 17 19V18H18C18.7956 18 19.5587 17.6839 20.1213 17.1213C20.6839 16.5587 21 15.7956 21 15V9C21 9 21 9 21 8.94ZM15 5.41L17.59 8H16C15.7348 8 15.4804 7.89464 15.2929 7.70711C15.1054 7.51957 15 7.26522 15 7V5.41ZM15 19C15 19.2652 14.8946 19.5196 14.7071 19.7071C14.5196 19.8946 14.2652 20 14 20H6C5.73478 20 5.48043 19.8946 5.29289 19.7071C5.10536 19.5196 5 19.2652 5 19V9C5 8.73478 5.10536 8.48043 5.29289 8.29289C5.48043 8.10536 5.73478 8 6 8H7V15C7 15.7956 7.31607 16.5587 7.87868 17.1213C8.44129 17.6839 9.20435 18 10 18H15V19ZM19 15C19 15.2652 18.8946 15.5196 18.7071 15.7071C18.5196 15.8946 18.2652 16 18 16H10C9.73478 16 9.48043 15.8946 9.29289 15.7071C9.10536 15.5196 9 15.2652 9 15V5C9 4.73478 9.10536 4.48043 9.29289 4.29289C9.48043 4.10536 9.73478 4 10 4H13V7C13 7.79565 13.3161 8.55871 13.8787 9.12132C14.4413 9.68393 15.2044 10 16 10H19V15Z"
                          fill="#3A5AFF"
                        />
                      </svg>
                    </span>
                    <span className="text-blue-10">
                      Select a file from your device
                    </span>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="mt-7 text-xs">
                    <div>Who Will Upload Submissions?</div>
                  </div>
                  <div className="md:flex md:items-center w-6/12">
                    <div className={`${sections} mt-2  gap-2 mr-2 md:mr-14`}>
                      <Radio
                        id="united-state"
                        name="countries"
                        value="USA"
                        defaultChecked={true}
                      />
                      <Label htmlFor="united-state">Students</Label>
                    </div>
                    <div className={`${sections} mt-2  gap-2 mr-2 md:mr-14`}>
                      <Radio
                        id="united-state"
                        name="countries"
                        value="USA"
                        defaultChecked={true}
                      />
                      <Label htmlFor="united-state">Instructors</Label>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="mt-4 md:mt-10">
                  <div className="text-base font-black my-2">
                    Date & Time Information
                  </div>
                </div>
                <div className="block md:flex gap-10">
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={calendarPng} alt="Calendar" />
                    </div>
                    <input
                      type="text"
                      id="release_date"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="release_date"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      Release Date
                    </label>
                  </div>
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={hourPng} alt="Hour" />
                    </div>
                    <input
                      type="text"
                      id="release_date_edt"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="release_date_edt"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      Release Time (EDT)
                    </label>
                  </div>
                </div>
                <div className="block md:flex gap-10">
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={calendarPng} alt="Calendar" />
                    </div>
                    <input
                      type="text"
                      id="due_date"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="due_date"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      DUE Date
                    </label>
                  </div>
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={hourPng} alt="Hour" />
                    </div>
                    <input
                      type="text"
                      id="floating_standard"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="floating_standard"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      DUE Date (EDT)
                    </label>
                  </div>
                </div>
              </div>
              <div>
                <div className="mt-4 md:mt-10">
                  <div className="text-base font-black my-2">
                    Allow Late Submissions
                  </div>
                </div>
                <div className="flex w-full gap-10">
                  <div className="flex items-center gap-2">
                    <Checkbox id="age" />
                    <Label htmlFor="age">All Students</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="age" />
                    <Label htmlFor="age">Disabled Students</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="age" />
                    <Label htmlFor="age">Others (Enter Manually)</Label>
                  </div>
                </div>
                <div className="block md:flex gap-10 my-2">
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={calendarPng} alt="Calendar" />
                    </div>
                    <input
                      type="text"
                      id="late_due_date"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="due_date"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      Late DUE Date
                    </label>
                  </div>
                  <div className="relative z-0 my-4 w-1/2">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                      <Image src={hourPng} alt="Hour" />
                    </div>
                    <input
                      type="text"
                      id="late_due_date_edt"
                      className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                      placeholder=" "
                    />
                    <label
                      htmlFor="floating_standard"
                      className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                    >
                      Late DUE Time (EDT)
                    </label>
                  </div>
                </div>
              </div>
              <div>
                <div className="mt-4 md:mt-10">
                  <div className="text-base font-black my-2">
                    Submission Type
                  </div>
                </div>
                <div>
                  <div
                    className={`!w-full ${sections} mt-2 gap-2 mr-2 md:mr-14`}
                  >
                    <div>
                      <Radio
                        id="united-state"
                        name="submission"
                        value="USA"
                        defaultChecked={true}
                      />
                      <Label htmlFor="united-state" className="ml-2">
                        Variable Length
                      </Label>
                      <div className="flex">
                        <Image
                          src={infoPng}
                          alt="Info Png"
                          className="w-4 h-4 ml-8 mt-1"
                        />
                        <div className="ml-2 text-[10px]">
                          Students submit any number of pages and indicate the
                          pages where their responses to each question are.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    className={`!w-full ${sections} mt-2 gap-2 mr-2 md:mr-14`}
                  >
                    <div>
                      <Radio
                        id="united-state"
                        name="submission"
                        value="USA"
                        defaultChecked={true}
                      />
                      <Label htmlFor="united-state">
                        Templated (Fixed Length)
                      </Label>
                      <div className="flex">
                        <Image
                          src={infoPng}
                          alt="Info Png"
                          className="w-4 h-4 ml-8 mt-1"
                        />
                        <div className="ml-2 text-[10px]">
                          Students submit any number of pages and indicate the
                          pages where their responses to each question are.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="mt-4 md:mt-10">
                  <div className="text-base font-black my-2">
                    Group Submission
                  </div>
                </div>
                <div className="md:flex">
                  <div className="flex items-center gap-2">
                    <Checkbox id="age" />
                    <Label htmlFor="age">Enable Group Submission</Label>
                  </div>
                  <div className="flex items-center md:ml-10">
                    <div className="text-xs mr-2">Limit Group Size:</div>
                    <div className="w-1/4">
                      <TextInput
                        id="password1"
                        type="password"
                        required={true}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="mt-4 md:mt-10">
                  <div className="text-base font-black my-2">
                    File Visibility
                  </div>
                </div>
                <div className="md:flex">
                  <div className="flex items-center gap-2">
                    <Checkbox id="age" />
                    <Label htmlFor="age">
                      Allow Students to view and download file
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="sticky h-24 bg-white z-10 left-1/2 right-1/2 top-16">
            <div className="modal-title flex place-content-center h-full flex-wrap">
              <button
                className="p-4 md:px-24 bg-orange rounded-full text-white"
                onClick={addNewExam}
              >
                Create New Exam
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </React.Fragment>
  );
};

export default AddNewExamModal;
