import { TextInput } from "flowbite-react";
import { useState } from "react";
import { toast } from "react-toastify";
import { Trash, Plus, X } from "tabler-icons-react";

export const Outline = ({ type, questionList, setQuestionList, outlineTitles }) => {
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
  const [questionName, setQuestionName] = useState("");
  const [questionScore, setQuestionScore] = useState("");
  const [showSubRatings, setShowSubRatings] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [selectedSubQuestion, setSelectedSubQuestion] = useState(null);
  const [subRatingTitle, setSubRatingTitle] = useState("");
  const [subRating, setSubRating] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (questionName == "" || questionScore == "") {
      toast.error("The Name And Score Is Required", "Error");
      return;
    }
    let subquestionCTRL = false
    const childPointsSum = (question) => {
      return question.childs.reduce((acc, subRating) => acc + Number(subRating.point), 0);
    }
    questionList?.map((question, index) => {
      if (question.childs.length > 0 && Number(question.point) !== Number(childPointsSum(question))) {
        subquestionCTRL = true
      }
    })

    if (subquestionCTRL) {
      toast.error("the sum of the sub-questions must be equal to the upper question", "Error");
      return;
    }
    if (Number(totalScore) + Number(questionScore) <= 100) {
      setQuestionList([
        ...questionList,
        { title: questionName, point: questionScore, childs: [] },
      ]);
      setQuestionName("");
      setQuestionScore("");
    } else {
      toast.error("The maximum score is 100", "Error");
    }
  };

  const handleSelectQuestion = (question) => {
    setSelectedQuestion(question);
    setShowSubRatings(true);
  };

  const handleAddSubRating = (e) => {
    e.preventDefault();
    if (subRating == "" || subRatingTitle == "") {
      toast.error("The Name And Score Is Required", "Error");
      return;
    }
    let subquestionCTRL = false;
    const childPointsSum = (question) => {
      return question.childs.reduce((acc, subRating) => acc + Number(subRating.point), 0);
    }
    questionList?.map((question, index) => {
      if (selectedQuestion == index && question.point < Number(subRating) + Number(childPointsSum(question))) {
        subquestionCTRL = true
      }
    })

    if (subquestionCTRL) {
      toast.error("the sum of the sub-questions must be equal to the upper question", "Error");
      return;
    }
    const newQuestion = [...questionList];
    newQuestion[selectedQuestion].childs.push({
      title: subRatingTitle,
      point: subRating,
    });
    setQuestionList(newQuestion);
    setSubRatingTitle("");
    setSubRating("");
    setShowSubRatings(false);
    setSelectedQuestion(-1);
  };
  const handleRemoveQuestion = (index) => {
    setQuestionList(questionList.filter((question, i) => i !== index));
  };

  const handleRemoveSubRating = (index, subIndex) => {
    const newQuestion = [...questionList];
    newQuestion[index].childs = newQuestion[index].childs.filter((subRating, i) => i !== subIndex);
    setQuestionList(newQuestion);
  };
  const onchangeHandler = (e, index, childIndex) => {
    if (e.target.value == "") {
      e.target.value = 0;
    }
    const newQuestion = [...questionList];
    newQuestion.map((v, i) => {
      if (childIndex == undefined) {
        if (i == index && e.target.value <= 100) v.point = e.target.value;
      } else {
        v.childs.map((cv, ci) => {
          if (i == index)
            if (ci == childIndex) {
              cv.point = e.target.value;
            }
        });
      }
    });
    setQuestionList(newQuestion);

  };
  const totalScore = questionList?.reduce(
    (acc, question) =>
      acc +
      Number(question.childs.length == 0 ? question.point : 0) +
      question.childs.reduce(
        (acc, subRating) => acc + Number(subRating.point),
        0
      ),
    0
  );
  console.log(outlineTitles)
  return (
    <div className="w-full flex-row">
      <div className="flex justify-between items-center">
        <span className="modal-subtitle ">Outlines</span>
        <span className="modal-subtitle ">
          <b>Total: </b>
          <b id="totalOutline">{totalScore}</b>
        </span>
      </div>
      {type == "withOutDocumentExam" ? (
        <div>
          <div className="pt-6">
            <ul className="">
              {questionList.map((question, index) => (
                <li key={index} className={"pt-4 p-4 mb-3"} style={{ border: selectedQuestion != index ? "1px solid #cbcb" : "1px solid #374899", borderRadius: "20px" }}>
                  <div className={AmI.roles.includes("student") ? "flex" : "flex justify-between"}                  >
                    <p className="text-lg font-medium">{question.title} :</p>
                    {AmI.roles.includes("student") || question.childs.length > 0 ? (
                      <p className="text-lg font-medium">{question.childs.reduce((acc, subRating) => acc + Number(subRating.point), 0)}</p>
                    ) : (
                      <TextInput
                        size={"sm"}
                        onChange={(e) => {
                          onchangeHandler(e, index);
                        }}
                        max="100"
                        type="number"
                        required
                        style={{ width: "60px" }}
                        value={Number(question.point)}
                      ></TextInput>
                    )}
                  </div>
                  <div className="mt-2">
                    <ul className="ml-10">
                      {question.childs.map((subRating, subIndex) => (
                        <li key={subIndex} className="pl-2">
                          <div
                            className={
                              AmI.roles.includes("student")
                                ? "flex"
                                : "flex justify-between"
                            }
                          >
                            <p className="text-lg font-medium">
                              {subRating.title} :
                            </p>
                            {AmI.roles.includes("student") || (outlineTitles != undefined && !outlineTitles?.includes(question.title + "/" + subRating.title)) ? (
                              <p className="text-lg font-medium">
                                {subRating.point}
                              </p>
                            ) : (
                              <TextInput
                                size={"sm"}
                                max="100"
                                required
                                type="number"
                                style={{ width: "60px" }}
                                onChange={(e) => {
                                  onchangeHandler(e, index, subIndex);
                                }}
                                value={Number(subRating.point)}
                              ></TextInput>
                            )}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) :
        ""
      }{
        type == "exam" ?
          <div>
            <div className="pt-6">
              <ul className="">
                {questionList.map((question, index) => (
                  <li key={index} className={"pt-4 p-4 mb-3"} style={{ border: selectedQuestion != index ? "1px solid #cbcb" : "1px solid #374899", borderRadius: "20px" }}>
                    <div className={AmI.roles.includes("student") ? "flex" : "flex justify-between"}                  >
                      <p className="text-lg font-medium">{question.title} :</p>
                      {AmI.roles.includes("student") || (outlineTitles != undefined && question.childs.length > 0 && (!outlineTitles?.includes(question.title))) ? (
                        <p className="text-lg font-medium">{question.childs.reduce((acc, subRating) => acc + Number(subRating.point), 0)}</p>
                      ) : (
                        <TextInput
                          size={"sm"}
                          onChange={(e) => {
                            onchangeHandler(e, index);
                          }}
                          max="100"
                          type="number"
                          required
                          style={{ width: "60px" }}
                          value={Number(question.point)}
                        ></TextInput>
                      )}
                    </div>
                    <div className="mt-2">
                      <ul className="ml-10">
                        {question.childs.map((subRating, subIndex) => (
                          <li key={subIndex} className="pl-2">
                            <div
                              className={
                                AmI.roles.includes("student")
                                  ? "flex"
                                  : "flex justify-between"
                              }
                            >
                              <p className="text-lg font-medium">
                                {subRating.title} :
                              </p>
                              {AmI.roles.includes("student") || (outlineTitles != undefined && !outlineTitles?.includes(question.title + "/" + subRating.title)) ? (
                                <p className="text-lg font-medium">
                                  {subRating.point}
                                </p>
                              ) : (
                                <TextInput
                                  size={"sm"}
                                  max="100"
                                  required
                                  type="number"
                                  style={{ width: "60px" }}
                                  onChange={(e) => {
                                    onchangeHandler(e, index, subIndex);
                                  }}
                                  value={Number(subRating.point)}
                                ></TextInput>
                              )}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          : ""}
      {
        type == undefined &&
        <div>
          <div className="pt-6">
            <ul className="">
              {questionList.map((question, index) => (
                <li key={index} className={"pt-4 p-4 mb-3"} style={{ border: selectedQuestion != index ? "1px solid #cbcb" : "1px solid #374899", borderRadius: "20px" }}
                >
                  <div className="flex justify-between">
                    <p className="text-lg font-medium">
                      Question:{question.title}
                    </p>
                    <p className="text-lg font-medium">
                      Point:{question.point}
                    </p>
                    <div>
                      <button onClick={() => handleSelectQuestion(index)}>
                        <Plus></Plus>
                      </button>
                      <button onClick={() => handleRemoveQuestion(index)}>
                        <Trash></Trash>
                      </button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <ul className="ml-10">
                      {question.childs.map((subRating, subIndex) => (
                        <li
                          key={subIndex}
                          style={{
                            borderTop: "1px solid #cbcbcb",
                          }}
                          className="p-2"
                        >
                          <div className="flex justify-between">
                            <p className="text-lg font-medium">
                              Sub-Question:
                              {subRating.title}
                            </p>
                            <p className="text-lg font-medium">
                              Sub-Point:
                              {subRating.point}
                            </p>
                            <button
                              onClick={() => handleRemoveSubRating(index, subIndex)}
                            >
                              <Trash></Trash>
                            </button>
                          </div>
                        </li>
                      ))}
                    </ul>
                    {showSubRatings && selectedQuestion === index && (
                      <form onSubmit={handleAddSubRating} className="flex ml-8">
                        <div className="w-6/12 mr-2 ">
                          <label className="mb-2">Sub-Outline Title:</label>
                          <TextInput
                            type="text"
                            size={"sm"}
                            value={subRatingTitle}
                            onChange={(e) => setSubRatingTitle(e.target.value)}
                            max="100"
                          />
                        </div>
                        <div className="w-6/12 mr-2 ">
                          <label className="mb-2">Sub-Outline Score:</label>
                          <div className="flex justify-between">
                            <TextInput
                              type="number"
                              size={"sm"}
                              value={subRating}
                              required
                              onChange={(e) => setSubRating(e.target.value)}
                              className="w-20"
                              max="100"
                            />
                            <div>
                              <button type="submit">
                                <Plus></Plus>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setShowSubRatings(false);
                                  setSelectedQuestion(-1);
                                }}
                              >
                                <X />
                              </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            <form onSubmit={handleSubmit} className="mb-4 flex">
              <div className="w-6/12 mr-2 ">
                <label className="mb-2">Question Name:</label>
                <TextInput
                  type="text"
                  size={"sm"}
                  required
                  value={questionName}
                  onChange={(e) => setQuestionName(e.target.value)}
                  max="100"
                />
              </div>
              <div className="w-6/12 ">
                <label className="mb-2">Question Score:</label>
                <div className="flex justify-between">
                  <TextInput
                    type="number"
                    size={"sm"}
                    value={questionScore}
                    onChange={(e) => setQuestionScore(e.target.value)}
                    className="w-24"
                    max="100"
                  />
                  <button type="submit">
                    <Plus></Plus>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  );
};
