import Image from "next/image"
import React from "react"
import robot from "../../public/assets/img/dash-board/robot_blue.png"
function WelcomeDashboardCard({ AmI }) {
	console.log(AmI)
	return (
		<div className="bg-white relative justify-center flex flex-col h-lg rounded-3xl my-8 mx-4 p-4 !items-start px-8 shadow-lg">
			<div className="text-4xl font-extrabold">
				Hello {AmI && AmI.displayName}
			</div>
			<div>It’s good to see you.</div>
			<Image
				src={robot}
				alt={"Robot"}
				style={{
					width: "min(230px, 100%)",
					height: "max(190px, 100%)",
					maxHeight: "auto",
					transform: "translate(-7px, -53px)",
				}}
				priority
				className="absolute w-1/4 h-1/4 right-6 top-0"
			/>
		</div>
	)
}

export default WelcomeDashboardCard
