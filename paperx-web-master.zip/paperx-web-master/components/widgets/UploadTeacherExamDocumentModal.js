import React, { useEffect, useState } from "react";
import { Button, Modal } from "flowbite-react";
import { Outline } from "./Outlines";
import SubmissionService from "../../services/SubmissionService";
import { toast } from "react-toastify";
import { AgGridReact } from "ag-grid-react";
import { Pencil } from "tabler-icons-react";
const UploadTeacherExamDocumentModal = ({ exam, ModalActive, SetModalActive, submissionList, studentList, getData }) => {
    const [selectedStudent, setSelectedStudent] = useState();
    const [submmisonscolumnDefs, SetSubmmisonscolumnDefs] = useState();
    useEffect(() => {
        SetSubmmisonscolumnDefs([
            {
                headerName: "Edit",
                width: 80,
                cellRenderer: (params) => {
                    let data = params.data;
                    let submission;
                    submissionList.map((value) => {
                        if (
                            exam._id == value.exam.id &&
                            value?.assigned?.username == params.data.username
                        )
                            submission = value;
                    });
                    return (
                        <button
                            onClick={() => {
                                SetSelectedStudent(data, submission);
                            }}
                        >
                            <Pencil />
                        </button>
                    );
                },
            },
            {
                headerName: "Name",
                field: "displayName",
            },
            {
                headerName: "Email",
                field: "email",
            },
            {
                headerName: "Exam Status",
                cellRenderer: (params) => {
                    var isSended;
                    submissionList.map((value) => {
                        if (
                            exam._id == value.exam.id &&
                            value?.assigned?.username == params.data.username
                        )
                            isSended = true;
                    });
                    if (isSended) return "Concluded";
                    else return "Not Concluded";
                },
            },
        ]);
    }, [studentList])
    const SetSelectedStudent = (student, submission) => {
        if (exam.outlines.length != 0) {
            if (submission != undefined)
                setQuestionList(submission.outlines)
            else
                setQuestionList(exam.outlines)
            setSelectedStudent(student)
        }
        else {
            toast.error("Please Enter Exam Answers First ")
        }
    }
    const [questionList, setQuestionList] = useState();
    useEffect(() => {
        exam.outlines.map((x) => {
            x.point = 0
            x.childs.map((sx) => {
                sx.point = 0
            })
        })
        setQuestionList(exam.outlines.map((x) => {
            x.point = 0
            x.childs.map((sx) => {
                sx.point = 0
            })
        }))
    }, [])
    const saveOutline = async () => {
        let totalScore = questionList.reduce(
            (acc, question) =>
                acc +
                +Number(question.point) +
                question.childs.reduce(
                    (acc, subRating) => acc + Number(subRating.point),
                    0
                ),
            0
        );
        if (totalScore > 100) {
            toast.error("The maximum score is 100", "Error");
            return;
        }
        var response = await SubmissionService.SubmissionEvaluate({
            exam: exam._id,
            assigned: {
                id: selectedStudent._id,
                username: selectedStudent.username,
            },
            outlines: questionList
        })
        if (response.data.message = "İşlem başarılı.") {
            getData(window.location.href.split("courseId=")[1]);
            setSelectedStudent(undefined)
            setQuestionList(exam.outlines.map((x) => {
                x.point = 0
                x.childs.map((sx) => {
                    sx.point = 0
                })
            }))
            toast.success("Document Sended", "Success!")
        }
        else {
            toast.error("Something Went Wrong", "Error")
        }
    }
    return (
        <div className="font-sans mt-4 m">
            {
                exam != undefined &&
                <Modal show={ModalActive} size="4xl" popup={true} onClose={() => { SetModalActive(false); }} >
                    <Modal.Header>
                        <span className="subTitle p-8">Students</span>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="p-2">
                            <div className="ag-theme-material h-[40vh]">
                                <AgGridReact
                                    animateRows={true}
                                    rowData={studentList}
                                    defaultColDef={{
                                        sortable: true,
                                        resizable: true,
                                        filter: true,
                                    }}
                                    pagination={true}
                                    columnDefs={submmisonscolumnDefs}
                                ></AgGridReact>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>

            }
            {
                selectedStudent &&
                <Modal show={selectedStudent != undefined} size="lg" popup={true} onClose={() => { setSelectedStudent(undefined); }} >
                    <Modal.Header />
                    <Modal.Body>
                        <Outline type={"withOutDocumentExam"} questionList={questionList} setQuestionList={setQuestionList}></Outline>
                        <div className="flex flex-col gap-4 mt-4">
                            <Button className="button-orange" onClick={saveOutline} >Save</Button>
                        </div>
                    </Modal.Body>
                </Modal>
            }

        </div >
    );
};


export default UploadTeacherExamDocumentModal