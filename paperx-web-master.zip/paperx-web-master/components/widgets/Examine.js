import React, { useEffect, useState } from 'react'
import { AgGridReact } from 'ag-grid-react';
import ExamineService from '../../services/ExamineService';
import Tabs from '../Tabs/Tabs';
import { StatusEnum } from '../../utils/Enums';
import moment from "moment";
import SaveExamine from './SaveExamine';
import SubmissionService from '../../services/SubmissionService';
import DrawingCanvas from './DrawingCanvas';
import { Download, Pencil, Upload } from 'tabler-icons-react';
import UploadExamDocument from './UploadExamDocument';
import Submissions from './Submissions';
import StudentService from '../../services/StudentService';
import UploadTeacherExamDocumentModal from './UploadTeacherExamDocumentModal';
import { useDispatch } from 'react-redux';
import { setselectedSubmission, selectedSubmissionUp, selectedSubmissionDown } from '../../slices/selected-submission'

function Examine({ type }) {
    const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
    const [imgPath, setImgPath] = useState(undefined);
    const dispatch = useDispatch();
    const [List, setList] = useState([]);
    const [selectedSubmission, setSelectedSubmission] = useState(0);
    const [submissionList, setSubmissionList] = useState([]);
    const [studentList, setStudentListList] = useState([]);

    const [selectedStudentData, setSelectedStudentData] = useState();
    const [selectedExamData, setSelectedExamData] = useState(undefined);

    const monthNames = ["Jan", "Feb", "Mar", "Ap", "May", "Jun",
        "Jul", "Au", "Sep", "Oct", "Nov", "Dec"
    ];

    const [TwiceStepModalActive, SetTwiceStepModalActive] = useState(false);
    const [uploadDocumentModalActive, SetuploadDocumentModalActive] = useState(false);
    const [uploadTeacherDocumentModalActive, SetuploadTeacherDocumentModalActive] = useState(false);
    const [uploadedData, SetUploadedData] = useState(undefined);

    useEffect(() => {
        getData(window.location.href.split("courseId=")[1]);
    }, [])

    async function getData(courseId) {
        setList((await ExamineService.GetListByType(type, courseId)).data.result.data)
        setSubmissionList((await SubmissionService.GetAllSubmissionByType(type, courseId)).data.result.data)
        setStudentListList((await StudentService.GetStudentsByAssignedCategoryId(courseId)).data.result.data)
        if (selectedStudentData != undefined) {
            setTimeout(async () => {
                let stud=(await SubmissionService.GetSubmissionById(selectedStudentData._id)).data.result;
                setSelectedStudentData(stud)
            }, 2550);
        }
    }


    function OpenUpdateModal(data) {
        SetUploadedData(data)
        SetTwiceStepModalActive(true);
    }
    function OpenViewStudentDocument(studentDatas) {
        dispatch(setselectedSubmission({ selectedSubmission: 0 }))
        let answer = studentDatas?.answers?.find(x => x.submissionId === (studentDatas?.submissions != undefined ? studentDatas?.submissions[0]?.id : 0))
        setImgPath(answer?.name != undefined ? answer?.name :
            (studentDatas?.submissions != undefined ? studentDatas?.submissions[0]?.name : ""))
        setSelectedStudentData(studentDatas)
    }
    async function downloadExamDocument(data) {
        data.files.forEach(async element => {
            const image = await fetch("/api/file/" + element.name)
            const imageBlog = await image.blob()
            const imageURL = URL.createObjectURL(imageBlog)
            const link = document.createElement('a')
            link.href = imageURL
            link.download = element.name
            document.body.appendChild(link)
            link.click()
            document.body.removeChild(link)
        });

    }
    async function uploadExamDocument(data) {
        setSelectedExamData(data)
        SetuploadDocumentModalActive(true)
    }
    async function uploadTeacherExamDocument(data) {
        setSelectedExamData(data)
        SetuploadTeacherDocumentModalActive(true)
    }
    const [columnDefs] = useState([
        {
            headerName: "",
            width: 150,
            cellRenderer: (params) => {
                let data = params.data
                if (AmI.roles.includes("student")) {
                    return (
                        <>
                            <button onClick={() => { downloadExamDocument(data) }}><Download></Download></button>
                            <button onClick={() => { uploadExamDocument(data) }}><Upload></Upload></button>
                        </>
                    )
                }
                else if (AmI.roles.includes("teacher") || AmI.roles?.includes("superUser")) {
                    return (
                        <>
                            <button onClick={() => { downloadExamDocument(data) }}><Download></Download></button>
                            <button onClick={() => { uploadTeacherExamDocument(data) }}><Upload></Upload></button>
                            <button onClick={() => { OpenUpdateModal(data) }}><Pencil /></button>
                        </>
                    )
                }
            },
        },
        {
            headerName: "Name",
            field: "name",
        },
        {
            headerName: "Relased  Due(EDT)",
            cellRenderer: (params) => {
                const getProgress = (startDate, endDate) => {
                    const total = +endDate - +startDate;
                    const elaps = Date.now() - total;
                    return Math.round((elaps / total) * 100);
                };

                // getProgress(start, end)
                return (
                    <div className="w-full p-2 text-sm">
                        <div className="processBar">
                            <div className="fillProcessBar" style={{ width: getProgress(new Date(params.data.startDate), new Date(params.data.endDate)) + "%" }}></div>
                        </div>
                        <div className="flex justify-between items-center" style={{ color: "#5C656A" }}>
                            <span>{monthNames[new Date(params.data.startDate).getMonth()] + moment(params.data.startDate).format("DD") + "," + params.data.startTime}</span> <span>{monthNames[new Date(params.data.endDate).getMonth()] + moment(params.data.endDate).format("DD") + "," + params.data.endTime}</span>
                        </div>
                    </div >
                )
            }
        },
        {
            headerName: "Submissions",
            cellRenderer: (params) => {
                return (<div>{params.data.submissionType}</div>)
            },
        },
        {
            headerName: "Graded",
            cellRenderer: (params) => {
                return (
                    <div className="w-full flex align-center p-2" >
                        <div className="processBar">
                            <div className="fillProcessBar" style={{ width: params.data.graded + "%" }}></div>
                            <div className="flex justify-end"><span className="text-sm">{params.data.graded + "%"}</span></div>
                        </div>
                    </div>
                )
            },
        },

    ])


    return (

        <div className="px-8">
            {
                selectedStudentData == undefined &&
                <div>
                    <Tabs>
                        <span label={`${type.charAt(0).toUpperCase() + type.slice(1)} (${List.filter(x => x.status == StatusEnum.created).length})`}>
                            <div className="ag-theme-material h-[60vh]" >
                                <AgGridReact
                                    defaultColDef={{
                                        sortable: true,
                                        resizable: true,
                                        filter: true,
                                    }}
                                    pagination={true}
                                    animateRows={true}
                                    rowData={List}
                                    columnDefs={columnDefs}>
                                </AgGridReact>
                            </div>
                        </span>
                        <span label={`Submisions (${submissionList.length})`}>
                            <Submissions submissionList={submissionList} OpenViewStudentDocument={OpenViewStudentDocument} />
                        </span>
                    </Tabs>
                    {
                        !AmI.roles.includes("student") ?
                            <SaveExamine type={type} getData={getData} uploadedData={uploadedData} SetUploadedData={SetUploadedData} TwiceStepModalActive={TwiceStepModalActive} SetTwiceStepModalActive={SetTwiceStepModalActive} />
                            : ""
                    }
                </div>
            }

            {
                selectedStudentData != undefined && selectedSubmission != undefined &&
                <DrawingCanvas imgPath={imgPath} setImgPath={setImgPath} selectedSubmission={selectedSubmission} setSelectedSubmission={setSelectedSubmission} getData={getData} studentDatas={selectedStudentData} setSelectedStudentData={setSelectedStudentData} />
            }
            {
                uploadDocumentModalActive &&
                <UploadExamDocument getData={getData} exam={selectedExamData} ModalActive={uploadDocumentModalActive} SetModalActive={SetuploadDocumentModalActive}></UploadExamDocument>
            }
            {
                uploadTeacherDocumentModalActive &&
                <UploadTeacherExamDocumentModal getData={getData} exam={selectedExamData} ModalActive={uploadTeacherDocumentModalActive} SetModalActive={SetuploadTeacherDocumentModalActive} studentList={studentList} submissionList={submissionList} />
            }
        </div >
    );
}

export default Examine