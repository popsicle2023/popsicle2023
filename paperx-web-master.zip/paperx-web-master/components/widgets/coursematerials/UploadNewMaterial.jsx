import Head from "next/head";
import { useState, React, useEffect } from "react";
import CourseMaterial from "../../../services/CourseMaterial";
import axios from "axios";
import { useSelector } from "react-redux";
// import UpdateCourseMaterial from "../../../services/CourseMaterial";

const materials = [
  {
    id: 1,
    description: "Introduction to Math 141-1",
    type: "video",
    uploadDate: "01.28.2021",
    minute: "53 min",
  },
  {
    id: 2,
    description: "Week 7 Online Class",
    type: "video",
    uploadDate: "01.28.2021",
    minute: "53 min",
  },
  {
    id: 3,
    description: "Introduction to Math 141-1",
    type: "video",
    uploadDate: "01.28.2021",
    minute: "53 min",
  },
];

export default function UploadNewMaterial({ type }) {
  const [isOpen, setIsOpen] = useState(false);
  const [courseList, setCourseList] = useState(materials);
  const [videos, setVideos] = useState({});
  const [printeds, setPrinteds] = useState({});

  // type==='video' ? console.log('olur gibi'):console.log('olmali')
  const getPageData = async () => {
    let courseId = window.location.href.split("courseId=")[1];
    const data = await CourseMaterial.GetCourseMaterialVideos(courseId);
    const videos = data.data.result.videos;
    const printeds = data.data.result.printeds;
    setVideos({ videos });
    setPrinteds({ printeds });
    console.log(videos);
    console.log(printeds);
    // dispatch(
    //   setCourses({ courses: (await HelperService.GetCourses()).data.result.data })
    // )
    // dispatch(
    //   setDepartments({ departments: (await HelperService.GetDepartments()).data.result.data })
    // )
    // dispatch(
    //   setSchools({ schools: (await HelperService.GetSchools()).data.result.data })
    // )
  };
  useEffect(() => {
    getPageData();
  }, []);
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    let courseId = window.location.href.split("courseId=")[1];

    Object.values(document.getElementById("fileUpload").files).forEach(
      function (file) {
        formData.append("videos", file);
      }
    );

    // formData.append("videos", event.target.querySelector("#fileUpload").files);

    // await UpdateCourseMaterial(courseId, 'test')
    await axios({
      url: "/api/course/" + courseId,
      method: "POST",
      headers: {
        "Content-Type": "multipart/form-data",
        "x-access-token": localStorage.getItem("token"),
      },
      data: formData,
    })
      .then((result) => {
        // console.log(result)
      })
      .catch((err) => {
        // console.log(err)
      });
    const newCourse = {
      id: courseList.length + 1,
      description: formData.get("description"),
      uploadDate: new Date().toLocaleDateString("en-US"),
      // type: formData.get('type'),
      // minute: formData.get('minute'),
    };
    setCourseList([...courseList, newCourse]);
    getPageData();
  };

  function fileControl(event) {
    console.log(event);
    console.log(event.target.files);
    var fileName = document.querySelector("#fileUpload").files[0]?.name;
    var fileExtension = fileName.substr(fileName.lastIndexOf(".") + 1);
    if (
      fileExtension == "pdf" ||
      fileExtension == "docx" ||
      fileExtension == "doc" ||
      fileExtension == "pptx" ||
      fileExtension == "ppt"
    ) {
      // type = 'printed';
      document.querySelector("#fileUpload").style.color = "green";
      document.querySelector("#fileUpload").style.fontSize = "20px";
      document.querySelector("#fileUpload").style.fontWeight = "bold";
      document.querySelector("#fileUpload").style.fontFamily = "sans-serif";
      document.querySelector("#fileUpload").style.backgroundColor = "white";
      document.querySelector("#fileUpload").style.cursor = "pointer";
      document.querySelector("#fileUpload").style.transition =
        "all 0.3s ease-in-out";
      document.querySelector("#fileUpload").style.outline = "none";
      document.querySelector("#fileUpload").style.boxShadow = "0 0 0 0";
      document.querySelector("#fileUpload").style.webkitBoxShadow = "0 0 0 0";
    } else if (
      fileExtension == "mp4" ||
      fileExtension == "mov" ||
      fileExtension == "avi" ||
      fileExtension == "wmv" ||
      fileExtension == "flv" ||
      fileExtension == "mkv"
    ) {
      // type = 'video';
      document.querySelector("#fileUpload").style.borderColor = "green";
      document.querySelector("#fileUpload").style.color = "green";
      document.querySelector("#fileUpload").style.borderStyle = "solid";
      document.querySelector("#fileUpload").style.borderWidth = "1px";
    } else {
      // type = 'error';
      document.querySelector("#fileUpload").style.color = "red";
      document.querySelector("#fileUpload").style.fontSize = "20px";
      document.querySelector("#fileUpload").style.fontWeight = "bold";
      document.querySelector("#fileUpload").style.fontFamily = "sans-serif";
      document.querySelector("#fileUpload").style.cursor = "pointer";
    }
  }

  // function fileUpload = async(event) => {

  //   const files = event.target.files;

  //   if (files.length === 0) return;

  //   const data = new FormData();
  //   data.append('file', files[0]);

  //   try{
  //     const response = await axios.post('/api/upload', data);
  //     console.log(response.data);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };

  function deleteCourseMaterial() {
    console.log(
      "Burada silme işlemi gerçekleşecek, hata verilmemesi için console'a yazıldı."
    );
  }

  //  Backend bağlandığında silme işlemi burada gerçekleşecek

  //  async function deleteCourseMaterial(course.id) {
  //    try {
  //      const response = await axios.delete(`/api/courseMaterial/${course.id}`);
  //      return response.data;
  //    } catch (error) {
  //      console.error(error);
  //    }
  //  }

  return (
    <div>
      <Head>
        <title>Course Materials</title>
      </Head>

      <main>
        <video controls>
          <source
            src={`http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4`}
            type="video/mp4"
          />
        </video>
        <div>
          {isOpen && (
            <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center">
              <div className="bg-blend-darken !impo">
                <div className="bg-white rounded-3xl">
                  <div className="text-right pt-8 pr-8">
                    <button onClick={() => setIsOpen(false)}>
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M15.71 8.29008C15.617 8.19635 15.5064 8.12196 15.3846 8.07119C15.2627 8.02042 15.132 7.99428 15 7.99428C14.868 7.99428 14.7373 8.02042 14.6154 8.07119C14.4936 8.12196 14.383 8.19635 14.29 8.29008L12 10.5901L9.71 8.29008C9.5217 8.10178 9.2663 7.99599 9 7.99599C8.7337 7.99599 8.47831 8.10178 8.29 8.29008C8.1017 8.47838 7.99591 8.73378 7.99591 9.00008C7.99591 9.26638 8.1017 9.52178 8.29 9.71008L10.59 12.0001L8.29 14.2901C8.19627 14.383 8.12188 14.4936 8.07111 14.6155C8.02034 14.7374 7.9942 14.8681 7.9942 15.0001C7.9942 15.1321 8.02034 15.2628 8.07111 15.3847C8.12188 15.5065 8.19627 15.6171 8.29 15.7101C8.38297 15.8038 8.49357 15.8782 8.61543 15.929C8.73729 15.9797 8.86799 16.0059 9 16.0059C9.13201 16.0059 9.26272 15.9797 9.38458 15.929C9.50644 15.8782 9.61704 15.8038 9.71 15.7101L12 13.4101L14.29 15.7101C14.383 15.8038 14.4936 15.8782 14.6154 15.929C14.7373 15.9797 14.868 16.0059 15 16.0059C15.132 16.0059 15.2627 15.9797 15.3846 15.929C15.5064 15.8782 15.617 15.8038 15.71 15.7101C15.8037 15.6171 15.8781 15.5065 15.9289 15.3847C15.9797 15.2628 16.0058 15.1321 16.0058 15.0001C16.0058 14.8681 15.9797 14.7374 15.9289 14.6155C15.8781 14.4936 15.8037 14.383 15.71 14.2901L13.41 12.0001L15.71 9.71008C15.8037 9.61712 15.8781 9.50652 15.9289 9.38466C15.9797 9.2628 16.0058 9.13209 16.0058 9.00008C16.0058 8.86807 15.9797 8.73736 15.9289 8.6155C15.8781 8.49364 15.8037 8.38304 15.71 8.29008ZM19.07 4.93008C18.1475 3.97498 17.0441 3.21316 15.824 2.68907C14.604 2.16498 13.2918 1.88911 11.964 1.87757C10.6362 1.86604 9.31943 2.11905 8.09046 2.62186C6.8615 3.12467 5.74498 3.8672 4.80605 4.80613C3.86713 5.74506 3.1246 6.86158 2.62179 8.09054C2.11898 9.3195 1.86596 10.6363 1.8775 11.9641C1.88904 13.2919 2.1649 14.6041 2.68899 15.8241C3.21308 17.0442 3.9749 18.1476 4.93 19.0701C5.85247 20.0252 6.95592 20.787 8.17596 21.3111C9.396 21.8352 10.7082 22.111 12.036 22.1226C13.3638 22.1341 14.6806 21.8811 15.9095 21.3783C17.1385 20.8755 18.255 20.133 19.194 19.194C20.1329 18.2551 20.8754 17.1386 21.3782 15.9096C21.881 14.6807 22.134 13.3639 22.1225 12.0361C22.111 10.7083 21.8351 9.39607 21.311 8.17603C20.7869 6.95599 20.0251 5.85255 19.07 4.93008ZM17.66 17.6601C16.352 18.9695 14.6305 19.7849 12.7888 19.9674C10.9471 20.1499 9.09901 19.6881 7.55953 18.6609C6.02004 17.6336 4.88436 16.1043 4.34598 14.3336C3.80759 12.5628 3.89981 10.6602 4.60692 8.94986C5.31403 7.23951 6.59228 5.82723 8.22389 4.95364C9.85551 4.08006 11.7395 3.79921 13.555 4.15895C15.3705 4.5187 17.005 5.49677 18.1802 6.92654C19.3554 8.35631 19.9985 10.1493 20 12.0001C20.0036 13.0514 19.7986 14.0929 19.3969 15.0645C18.9953 16.036 18.4049 16.9182 17.66 17.6601Z"
                          fill="#263238"
                        />
                      </svg>
                    </button>
                  </div>
                  <form onSubmit={handleSubmit}>
                    <div className="mb-4 text-center px-16">
                      <label
                        className="block text-gray-700 text-2xl font-bold pt-8"
                        htmlFor="description"
                      >
                        Upload New Course Material
                      </label>
                      <input
                        className="border-0 border-b-[1px] w-full mt-9 mb-[2.375rem] border-gray-300 text-gray-700"
                        id="description"
                        type="text"
                        placeholder="Title"
                        name="description"
                        required
                      />

                      <div className="flex">
                        <input
                          className="text-blue-10 font-sans text-sm mb-16"
                          id="fileUpload"
                          type="file"
                          placeholder="Select a file from your device"
                          name="fileUpload"
                          onChange={(e) => fileControl(e)}
                          required
                          multiple
                        />
                        <svg
                          width="26"
                          height="24"
                          viewBox="0 0 26 24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M14.1085 12.0001L10.3799 15.5401C10.1837 15.7274 10.0736 15.9809 10.0736 16.2451C10.0736 16.5092 10.1837 16.7627 10.3799 16.9501C10.4778 17.0438 10.5943 17.1182 10.7226 17.1689C10.851 17.2197 10.9886 17.2458 11.1277 17.2458C11.2667 17.2458 11.4044 17.2197 11.5328 17.1689C11.6611 17.1182 11.7776 17.0438 11.8755 16.9501L16.3414 12.7101C16.4401 12.6171 16.5185 12.5065 16.572 12.3846C16.6255 12.2628 16.653 12.1321 16.653 12.0001C16.653 11.868 16.6255 11.7373 16.572 11.6155C16.5185 11.4936 16.4401 11.383 16.3414 11.2901L11.8755 7.00005C11.7771 6.90737 11.6604 6.83405 11.532 6.78428C11.4037 6.73452 11.2663 6.70929 11.1277 6.71005C10.9891 6.70929 10.8517 6.73452 10.7233 6.78428C10.595 6.83405 10.4783 6.90737 10.3799 7.00005C10.1837 7.18741 10.0736 7.44087 10.0736 7.70505C10.0736 7.96924 10.1837 8.22269 10.3799 8.41005L14.1085 12.0001Z"
                            fill="#3A5AFF"
                          />
                        </svg>
                      </div>

                      <button
                        className="items-center w-full justify-between mb-16 text-base py-4 bg-orange hover:bg-orange-600 text-white font-bold  rounded-full focus:outline-none focus:shadow-outline"
                        type="submit"
                      >
                        Upload
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-[1.125rem] max-h-[75vh] overflow-y-auto">
          {/* {courseList.length > 0 ? ( */}
          {console.log(videos)}
          {videos?.videos?.length > 0 ? (
            <>
              <ul>
                {videos?.videos?.map((course) => (
                  <li key={course.id} className="mb-3">
                    <div className="course-material-general-area flex justify-between items-center p-3 text-base font-bold shadow-md text-gray-900 rounded-2xl  bg-white hover:bg-gray-200 group hover:shadow dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-white">
                      <span className="course-material-general-area-info flex-1 ml-3 whitespace-nowrap">
                        {course.name}
                        <div className="course-material-general-area-info__desc flex course-material-general-area">
                          <div className="flex items-center pr-4">
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 14 14"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              className="pr-1"
                            >
                              <path
                                d="M7.00016 8.33325C7.13202 8.33325 7.26091 8.29415 7.37054 8.2209C7.48018 8.14764 7.56562 8.04353 7.61608 7.92171C7.66654 7.79989 7.67974 7.66585 7.65402 7.53653C7.6283 7.4072 7.5648 7.28842 7.47157 7.19518C7.37833 7.10195 7.25954 7.03845 7.13022 7.01273C7.0009 6.98701 6.86686 7.00021 6.74504 7.05067C6.62322 7.10112 6.5191 7.18657 6.44585 7.29621C6.3726 7.40584 6.3335 7.53473 6.3335 7.66659C6.3335 7.8434 6.40373 8.01297 6.52876 8.13799C6.65378 8.26301 6.82335 8.33325 7.00016 8.33325ZM10.3335 8.33325C10.4654 8.33325 10.5942 8.29415 10.7039 8.2209C10.8135 8.14764 10.899 8.04353 10.9494 7.92171C10.9999 7.79989 11.0131 7.66585 10.9874 7.53653C10.9616 7.4072 10.8981 7.28842 10.8049 7.19518C10.7117 7.10195 10.5929 7.03845 10.4636 7.01273C10.3342 6.98701 10.2002 7.00021 10.0784 7.05067C9.95656 7.10112 9.85244 7.18657 9.77918 7.29621C9.70593 7.40584 9.66683 7.53473 9.66683 7.66659C9.66683 7.8434 9.73707 8.01297 9.86209 8.13799C9.98712 8.26301 10.1567 8.33325 10.3335 8.33325ZM7.00016 10.9999C7.13202 10.9999 7.26091 10.9608 7.37054 10.8876C7.48018 10.8143 7.56562 10.7102 7.61608 10.5884C7.66654 10.4666 7.67974 10.3325 7.65402 10.2032C7.6283 10.0739 7.5648 9.95508 7.47157 9.86185C7.37833 9.76861 7.25954 9.70512 7.13022 9.6794C7.0009 9.65367 6.86686 9.66687 6.74504 9.71733C6.62322 9.76779 6.5191 9.85324 6.44585 9.96287C6.3726 10.0725 6.3335 10.2014 6.3335 10.3333C6.3335 10.5101 6.40373 10.6796 6.52876 10.8047C6.65378 10.9297 6.82335 10.9999 7.00016 10.9999ZM10.3335 10.9999C10.4654 10.9999 10.5942 10.9608 10.7039 10.8876C10.8135 10.8143 10.899 10.7102 10.9494 10.5884C10.9999 10.4666 11.0131 10.3325 10.9874 10.2032C10.9616 10.0739 10.8981 9.95508 10.8049 9.86185C10.7117 9.76861 10.5929 9.70512 10.4636 9.6794C10.3342 9.65367 10.2002 9.66687 10.0784 9.71733C9.95656 9.76779 9.85244 9.85324 9.77918 9.96287C9.70593 10.0725 9.66683 10.2014 9.66683 10.3333C9.66683 10.5101 9.73707 10.6796 9.86209 10.8047C9.98712 10.9297 10.1567 10.9999 10.3335 10.9999ZM3.66683 8.33325C3.79868 8.33325 3.92758 8.29415 4.03721 8.2209C4.14684 8.14764 4.23229 8.04353 4.28275 7.92171C4.33321 7.79989 4.34641 7.66585 4.32069 7.53653C4.29496 7.4072 4.23147 7.28842 4.13823 7.19518C4.045 7.10195 3.92621 7.03845 3.79689 7.01273C3.66757 6.98701 3.53352 7.00021 3.41171 7.05067C3.28989 7.10112 3.18577 7.18657 3.11252 7.29621C3.03926 7.40584 3.00016 7.53473 3.00016 7.66659C3.00016 7.8434 3.0704 8.01297 3.19543 8.13799C3.32045 8.26301 3.49002 8.33325 3.66683 8.33325ZM11.6668 1.66659H11.0002V0.999919C11.0002 0.823108 10.9299 0.653538 10.8049 0.528514C10.6799 0.40349 10.5103 0.333252 10.3335 0.333252C10.1567 0.333252 9.98712 0.40349 9.86209 0.528514C9.73707 0.653538 9.66683 0.823108 9.66683 0.999919V1.66659H4.3335V0.999919C4.3335 0.823108 4.26326 0.653538 4.13823 0.528514C4.01321 0.40349 3.84364 0.333252 3.66683 0.333252C3.49002 0.333252 3.32045 0.40349 3.19543 0.528514C3.0704 0.653538 3.00016 0.823108 3.00016 0.999919V1.66659H2.3335C1.80306 1.66659 1.29436 1.8773 0.919283 2.25237C0.54421 2.62744 0.333496 3.13615 0.333496 3.66659V11.6666C0.333496 12.197 0.54421 12.7057 0.919283 13.0808C1.29436 13.4559 1.80306 13.6666 2.3335 13.6666H11.6668C12.1973 13.6666 12.706 13.4559 13.081 13.0808C13.4561 12.7057 13.6668 12.197 13.6668 11.6666V3.66659C13.6668 3.13615 13.4561 2.62744 13.081 2.25237C12.706 1.8773 12.1973 1.66659 11.6668 1.66659ZM12.3335 11.6666C12.3335 11.8434 12.2633 12.013 12.1382 12.138C12.0132 12.263 11.8436 12.3333 11.6668 12.3333H2.3335C2.15669 12.3333 1.98712 12.263 1.86209 12.138C1.73707 12.013 1.66683 11.8434 1.66683 11.6666V5.66659H12.3335V11.6666ZM12.3335 4.33325H1.66683V3.66659C1.66683 3.48977 1.73707 3.32021 1.86209 3.19518C1.98712 3.07016 2.15669 2.99992 2.3335 2.99992H11.6668C11.8436 2.99992 12.0132 3.07016 12.1382 3.19518C12.2633 3.32021 12.3335 3.48977 12.3335 3.66659V4.33325ZM3.66683 10.9999C3.79868 10.9999 3.92758 10.9608 4.03721 10.8876C4.14684 10.8143 4.23229 10.7102 4.28275 10.5884C4.33321 10.4666 4.34641 10.3325 4.32069 10.2032C4.29496 10.0739 4.23147 9.95508 4.13823 9.86185C4.045 9.76861 3.92621 9.70512 3.79689 9.6794C3.66757 9.65367 3.53352 9.66687 3.41171 9.71733C3.28989 9.76779 3.18577 9.85324 3.11252 9.96287C3.03926 10.0725 3.00016 10.2014 3.00016 10.3333C3.00016 10.5101 3.0704 10.6796 3.19543 10.8047C3.32045 10.9297 3.49002 10.9999 3.66683 10.9999Z"
                                fill="#5C656A"
                              />
                            </svg>
                            <p className="text-xs text-gray font-sans font-normal">
                              {/* Uploaded {course.uploadDate} */}
                              Uploaded yok
                            </p>
                          </div>

                          <div className="flex items-center">
                            <svg
                              width="16"
                              height="16"
                              viewBox="0 0 16 16"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M12.1999 5.72675L12.8065 5.12675C12.9321 5.00121 13.0026 4.83095 13.0026 4.65341C13.0026 4.47588 12.9321 4.30562 12.8065 4.18008C12.681 4.05455 12.5107 3.98402 12.3332 3.98402C12.1557 3.98402 11.9854 4.05455 11.8599 4.18008L11.2599 4.78675C10.3256 4.06398 9.17775 3.67184 7.99652 3.67184C6.81529 3.67184 5.66749 4.06398 4.73319 4.78675L4.12652 4.17341C4.0001 4.04788 3.82899 3.9777 3.65083 3.97833C3.47267 3.97896 3.30206 4.05033 3.17652 4.17675C3.05099 4.30317 2.98081 4.47428 2.98144 4.65244C2.98206 4.8306 3.05343 5.00121 3.17985 5.12675L3.79319 5.73341C3.06187 6.66511 2.66505 7.81564 2.66652 9.00008C2.66434 9.85036 2.8655 10.6888 3.2532 11.4456C3.64091 12.2023 4.20393 12.8554 4.89532 13.3504C5.5867 13.8453 6.3864 14.1678 7.22773 14.2909C8.06906 14.414 8.92762 14.3341 9.73182 14.058C10.536 13.7819 11.2625 13.3175 11.8508 12.7035C12.4391 12.0896 12.872 11.3439 13.1135 10.5286C13.355 9.71333 13.3981 8.85214 13.2392 8.01684C13.0802 7.18154 12.7239 6.39635 12.1999 5.72675ZM7.99986 13.0001C7.20873 13.0001 6.43537 12.7655 5.77757 12.326C5.11978 11.8864 4.60709 11.2617 4.30434 10.5308C4.00159 9.79991 3.92237 8.99564 4.07671 8.21972C4.23105 7.4438 4.61202 6.73106 5.17143 6.17165C5.73084 5.61224 6.44357 5.23128 7.21949 5.07694C7.99542 4.9226 8.79968 5.00181 9.53059 5.30456C10.2615 5.60731 10.8862 6.12 11.3257 6.7778C11.7653 7.4356 11.9999 8.20896 11.9999 9.00008C11.9999 10.0609 11.5784 11.0784 10.8283 11.8285C10.0781 12.5787 9.06072 13.0001 7.99986 13.0001ZM6.66652 3.00008H9.33319C9.51 3.00008 9.67957 2.92984 9.80459 2.80482C9.92962 2.67979 9.99986 2.51023 9.99986 2.33341C9.99986 2.1566 9.92962 1.98703 9.80459 1.86201C9.67957 1.73699 9.51 1.66675 9.33319 1.66675H6.66652C6.48971 1.66675 6.32014 1.73699 6.19512 1.86201C6.07009 1.98703 5.99985 2.1566 5.99985 2.33341C5.99985 2.51023 6.07009 2.67979 6.19512 2.80482C6.32014 2.92984 6.48971 3.00008 6.66652 3.00008ZM8.66652 7.00008C8.66652 6.82327 8.59628 6.6537 8.47126 6.52868C8.34624 6.40365 8.17667 6.33341 7.99986 6.33341C7.82304 6.33341 7.65347 6.40365 7.52845 6.52868C7.40343 6.6537 7.33319 6.82327 7.33319 7.00008V8.26008C7.18223 8.3951 7.07584 8.57277 7.02807 8.76958C6.9803 8.96639 6.99342 9.17307 7.06568 9.36226C7.13795 9.55145 7.26595 9.71424 7.43277 9.82909C7.59958 9.94394 7.79733 10.0054 7.99986 10.0054C8.20238 10.0054 8.40013 9.94394 8.56694 9.82909C8.73376 9.71424 8.86176 9.55145 8.93403 9.36226C9.00629 9.17307 9.01941 8.96639 8.97164 8.76958C8.92387 8.57277 8.81748 8.3951 8.66652 8.26008V7.00008Z"
                                fill="#5C656A"
                              />
                            </svg>
                            <p className="text-xs text-gray font-sans font-normal">
                              {course.duration}
                            </p>
                          </div>
                        </div>
                      </span>

                      <button
                        type="button"
                        className="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-blue-700 focus:outline-none bg-white rounded-3xl border-2 border-blue-700 hover:bg-blue-700 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                        onClick={() => deleteCourseMaterial(course.id)}
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-3xl text-sm px-10 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                      >
                        Watch
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <div className="card bg-blue-400 rounded-lg">
              <div className="flex flex-row items-center">
                <div className="ml-4 mr-2 my-7 card-image">
                  <svg
                    width="48"
                    height="48"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M38.5803 7.42003C38.7662 7.60749 38.9874 7.75628 39.2311 7.85782C39.4748 7.95935 39.7363 8.01163 40.0003 8.01163C40.2643 8.01163 40.5257 7.95935 40.7694 7.85782C41.0132 7.75628 41.2344 7.60749 41.4203 7.42003C41.5969 7.22563 41.739 7.0024 41.8403 6.76003C41.9428 6.51959 41.9971 6.26139 42.0003 6.00003C42.0018 5.73682 41.9514 5.4759 41.8518 5.23222C41.7523 4.98855 41.6056 4.76691 41.4203 4.58003L41.1203 4.34004C41.0088 4.26434 40.8877 4.20381 40.7603 4.16003C40.3961 4.00688 39.9946 3.96503 39.6067 4.03978C39.2187 4.11453 38.8615 4.30252 38.5803 4.58003C38.3949 4.76691 38.2483 4.98855 38.1487 5.23222C38.0492 5.4759 37.9988 5.73682 38.0003 6.00003C38.0034 6.26139 38.0578 6.51959 38.1603 6.76003C38.2616 7.0024 38.4036 7.22563 38.5803 7.42003V7.42003ZM40.0003 10C39.4698 10 38.9611 10.2107 38.5861 10.5858C38.211 10.9609 38.0003 11.4696 38.0003 12V20C38.0003 20.5305 38.211 21.0392 38.5861 21.4142C38.9611 21.7893 39.4698 22 40.0003 22C40.5307 22 41.0394 21.7893 41.4145 21.4142C41.7896 21.0392 42.0003 20.5305 42.0003 20V12C42.0003 11.4696 41.7896 10.9609 41.4145 10.5858C41.0394 10.2107 40.5307 10 40.0003 10ZM40.1203 26C39.5954 25.9379 39.0673 26.086 38.6513 26.412C38.2353 26.7381 37.9653 27.2155 37.9003 27.74C37.4761 31.1267 35.8293 34.2418 33.2695 36.4995C30.7098 38.7573 27.4134 40.0021 24.0003 40H12.8203L14.1003 38.74C14.4728 38.3653 14.6819 37.8584 14.6819 37.33C14.6819 36.8017 14.4728 36.2948 14.1003 35.92C12.1353 33.9631 10.7957 31.4668 10.2514 28.7475C9.70721 26.0282 9.98284 23.2085 11.0434 20.6461C12.1039 18.0837 13.9016 15.894 16.2083 14.3547C18.5151 12.8154 21.2271 11.9959 24.0003 12C26.4525 11.9963 28.8616 12.6452 30.9803 13.88C31.4315 14.0839 31.9422 14.1132 32.4138 13.9623C32.8853 13.8113 33.2841 13.4908 33.533 13.0628C33.7818 12.6347 33.8631 12.1296 33.761 11.6451C33.6589 11.1606 33.3807 10.7312 32.9803 10.44C30.2585 8.83941 27.1578 7.9969 24.0003 8.00003C20.6152 8.01116 17.3019 8.9766 14.4407 10.7855C11.5794 12.5944 9.28626 15.1735 7.82442 18.2267C6.36257 21.2798 5.7913 24.6833 6.17617 28.0465C6.56104 31.4096 7.88646 34.5961 10.0003 37.24L6.58028 40.58C6.30276 40.8613 6.11477 41.2184 6.04002 41.6064C5.96527 41.9944 6.00712 42.3958 6.16028 42.76C6.31032 43.1253 6.56511 43.4379 6.89256 43.6586C7.22 43.8793 7.60543 43.9981 8.00028 44H24.0003C28.3862 44 32.6213 42.3986 35.9099 39.4967C39.1985 36.5947 41.3145 32.5919 41.8603 28.24C41.8939 27.9786 41.8755 27.7131 41.8061 27.4588C41.7367 27.2045 41.6178 26.9664 41.4561 26.7582C41.2943 26.5501 41.0931 26.3759 40.8638 26.2458C40.6346 26.1157 40.3819 26.0321 40.1203 26Z"
                      fill="#3A5AFF"
                    />
                  </svg>
                </div>
                <div className="card-text">
                  <p className="text-2xl font-sans">
                    You haven’t added any video materials for this course yet!
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
        <button
          className="flex px-[4.625rem] py-4 mt-8 border-dashed border-2 rounded-full border-indigo-600 text-center font-sans text-base"
          onClick={() => setIsOpen(true)}
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mr-[0.625rem]"
          >
            <path
              d="M19 11H13V5C13 4.73478 12.8946 4.48043 12.7071 4.29289C12.5196 4.10536 12.2652 4 12 4C11.7348 4 11.4804 4.10536 11.2929 4.29289C11.1054 4.48043 11 4.73478 11 5V11H5C4.73478 11 4.48043 11.1054 4.29289 11.2929C4.10536 11.4804 4 11.7348 4 12C4 12.2652 4.10536 12.5196 4.29289 12.7071C4.48043 12.8946 4.73478 13 5 13H11V19C11 19.2652 11.1054 19.5196 11.2929 19.7071C11.4804 19.8946 11.7348 20 12 20C12.2652 20 12.5196 19.8946 12.7071 19.7071C12.8946 19.5196 13 19.2652 13 19V13H19C19.2652 13 19.5196 12.8946 19.7071 12.7071C19.8946 12.5196 20 12.2652 20 12C20 11.7348 19.8946 11.4804 19.7071 11.2929C19.5196 11.1054 19.2652 11 19 11Z"
              fill="#3A5AFF"
            />
          </svg>
          Upload New Material
        </button>
      </main>
    </div>
  );
}
