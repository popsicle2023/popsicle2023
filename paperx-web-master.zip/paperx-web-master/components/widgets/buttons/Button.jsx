import React from "react";

const Button = ({ blue, value, className }) => {
  return (
    <>
      {blue ? (
        <div
          className={`p-3 border-2 font-semibold text-base border-blue-10 border-solid rounded-full text-white bg-blue-10 cursor-pointer ${className}`}
        >
          {value}
        </div>
      ) : (
        <div
          className={`p-3 border-2 font-semibold text-base border-blue-10 border-solid rounded-full text-blue-10 cursor-pointer ${className}`}
        >
          {value}
        </div>
      )}
    </>
  );
};

export default Button;
