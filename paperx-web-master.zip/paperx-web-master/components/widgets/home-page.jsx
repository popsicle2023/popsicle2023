import Image from "next/image";
import React from "react";
import backgroundPicture from "../../public/assets/img/home-page/homepage.png";
import AboutUs from "./home/about-us";
import Advantages from "./home/advantages";
import Demo from "./home/demo";
import Subscribe from "./home/subscribe";
import Header from "./home/Header";
import Footer from "./home/Footer";
import navbarTitles from "../../utils/menuItems";

const HomePage = () => {
  return (
    <>
      <Header />
      <div
        className="flex flex-col-reverse justify-end items-end xl:flex xl:flex-row xl:justify-start xl:items-center h-[150vh] md:h-[88.3vh] bg-home-page md:bg-home-page md:bg-no-repeat bg-cover relative top-0 md:top-0 px-16 w-full md:w-full mb-[9rem] overflow-hidden"
        id={navbarTitles[0].titles[0]}
        style={{ marginTop: "91px" }}
      >
        <div className="z-10 ml-5 mt-60 md:mt-0 md:ml-0">
          <p className="flex mt-8 md:mt-24 text-3xl mb-4">
            Less energy, more efficiency!
          </p>
          <h1 className="text-font-10 text-6xl font-semibold font-sans">
            Fast, Reliable
            <br /> Paperless <br /> Online Education
          </h1>
        </div>
        <div className="right-side md:absolute right-24 top-40 md:right-16 md:top-0 -bottom-16 z-0">
          <Image
            priority
            className="main-picture"
            src={backgroundPicture}
            alt="paper-x"
          />
        </div>
      </div>
      <Demo id={navbarTitles[0].titles[1]} />
      <AboutUs id={navbarTitles[0].titles[2]} />
      <Advantages id={navbarTitles[0].titles[3]} />
      <Subscribe id={navbarTitles[0].titles[4]} />
      <Footer />
    </>
  );
};

export default HomePage;
