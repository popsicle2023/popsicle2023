import React from "react";
import { DateRange } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
const Calendar = ({ selectedDate, setSelectedDate }) => {

  const onChange = dates => {
    setSelectedDate([dates.selection]);
  }
  return (
    <DateRange
      editableDateInputs={true}
      onChange={onChange}
      moveRangeOnFirstSelection={false}
      ranges={selectedDate}
    />
  );
};

export default Calendar;

