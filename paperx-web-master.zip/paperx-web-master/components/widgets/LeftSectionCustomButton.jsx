import Image from "next/image";
import React from "react";
import house from "../../public/assets/img/dash-board/house.svg";
import SideBarCustomTitle from "../../utils/menuItems";
const SideBarCustomButton = () => {
  return (
    <div className="text-orange flex gap-x-4 py-4 pl-4 my-4 ml-4 pr-8 bg-primary right-0 rounded-l-full font-bold">
      <Image
        src={house}
        alt="House"
        width={25}
        height={25}
        className="h-auto w-auto"
      />
      <div>{SideBarCustomTitle[1].dashboard.titles[0]}</div>
    </div>
  );
};

export default SideBarCustomButton;
