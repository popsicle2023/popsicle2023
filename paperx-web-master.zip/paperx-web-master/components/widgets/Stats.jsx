import React from "react";
import logoUniversity from "../../public/assets/img/demo/u_university.svg";
import logoGraduationCap from "../../public/assets/img/demo/u_graduation-cap.svg";
import Image from "next/image";

const Stats = () => {
  return (
    <div id="stat-section">
      <div className="details">
        <Image
          src={logoUniversity}
          alt="Logo University"
          width={35}
          height={35}
          className="h-auto w-auto"
        />
        <h1 className="number">100+</h1>
        <p className="name">University</p>
      </div>
      <div className="details">
        <Image
          src={logoGraduationCap}
          alt="Logo Graduation Cap"
          width={35}
          height={35}
          className="h-auto w-auto"
        />
        <h1 className="number">10.000+</h1>
        <p className="name">Users</p>
      </div>
    </div>
  );
};

export default Stats;
