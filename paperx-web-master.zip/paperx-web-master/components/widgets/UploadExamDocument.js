import React, { useEffect } from "react";
import { useState } from "react";
import { Modal } from "flowbite-react";
import { toast } from "react-toastify";
import axios from "axios";
const UploadExamDocument = ({ exam, ModalActive, SetModalActive, getData }) => {
    const saveData = () => {
        if (document.getElementById("uploadexamfiles").files.length == 0) {
            toast.error("Please Select File", "Error!")
            return;
        }
        let formData = new FormData();
        Object.values(document.getElementById("uploadexamfiles").files).forEach(function (file, index) {
            formData.append("submissions", file)
        });
        formData.append("exam", exam._id)

        axios({
            method: 'post',
            url: "/api/submission",
            headers: {
                "Content-Type": "multipart/form-data",
                "x-access-token": localStorage.getItem("token"),
            },
            data: formData
        })
            .then(async function (response) {
                if (response.data.message = "İşlem başarılı.") {
                    getData(window.location.href.split("courseId=")[1]);
                    SetModalActive(false);
                    toast.success("Document Sended", "Success!")
                }
                else {
                    toast.error("Something Went Wrong", "Error")
                }
            })
            .catch(function (error) {
                console.log(error);
            });

    }

    return (
        <div className="font-sans mt-4 m">
            {
                exam != undefined &&
                <Modal show={ModalActive} size="md" popup={true} onClose={() => { SetModalActive(false); }} >
                    <Modal.Header />
                    <Modal.Body>
                        <div className="container">
                            <div className="flex justify-center">
                                <span className="modal-title">Upload Document</span>
                            </div>
                            <div className="flex-row mt-8">
                                <label className="mr-3">
                                    {exam.name}
                                </label>
                                <input
                                    className="text-blue-10 font-sans text-sm  w-6/12"
                                    id="uploadexamfiles"
                                    type="file"
                                    placeholder="Select a file from your device"
                                    name="files"
                                    multiple
                                    required
                                />
                            </div>
                            <div className="mt-12 flex justify-center">
                                <button className="w-6/12 rounded-3xl border-0  pt-3 pb-3 bg-createnewcoursebtn text-white" onClick={saveData}>
                                    Send Document
                                </button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>

            }
        </div >
    );
};


export default UploadExamDocument