import { AgGridReact } from "ag-grid-react";
import React, { useState } from "react";
import Edit from "../../public/assets/img/exams/edit.png";
import Image from "next/image";
import moment from "moment";

function Submissions({ OpenViewStudentDocument, submissionList }) {
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
  const [submmisonscolumnDefs] = useState([
    {
      headerName: "Edit",
      width: 80,
      cellRenderer: (params) => {
        let data = params.data;
        if ((params.data.submissions?.length === (params.data?.answers != undefined ? params.data?.answers?.length : 0) || params.data.submissions == undefined && !params.data.outlines?.length < 1)&&AmI.roles?.includes("student")) {
          return (
            <button
              onClick={() => {
                OpenViewStudentDocument(data);
              }}
            >
              <Image src={Edit} alt="editicon" />
            </button>
          );
        }
        else if((params.data.submissions?.length === (params.data?.answers != undefined ? params.data?.answers?.length : 0) || params.data.submissions == undefined && !params.data.outlines?.length < 1)||(AmI.roles.includes("teacher") ||
        AmI.roles?.includes("superUser"))){
          return (
            <button
              onClick={() => {
                OpenViewStudentDocument(data);
              }}
            >
              <Image src={Edit} alt="editicon" />
            </button>
          );
        }
      },
    },
    {
      headerName: "Name",
      field: "exam.name",
    },
    {
      headerName: "Uploader Name",
      cellRenderer: (params) => {
        if (params.data.uploader?.displayName != undefined)
          return params.data.uploader?.displayName;
        else return params.data.assigned?.username;
      },
    },
    {
      headerName: "Exam Status",
      cellRenderer: (params) => {
        if ((params.data.submissions?.length === (params.data?.answers != undefined ? params.data?.answers?.length : 0) || params.data.submissions == undefined && !params.data.outlines?.length < 1))
          return "Concluded";
        else return "Not Concluded";
      },
    },
    {
      headerName: "Sended Date",
      cellRenderer: (params) => {
        return moment(params.data.uploader?.createAt).format(
          "DD/MM/YYYY hh:mm"
        );
      },
    },
    {
      headerName: "Uploader Email",
      field: "uploader.email",
    },
  ]);
  return (
    <div className="ag-theme-material h-[60vh]">
      <AgGridReact
        defaultColDef={{
          sortable: true,
          resizable: true,
          filter: true,
        }}
        pagination={true}
        animateRows={true}
        rowData={submissionList}
        columnDefs={submmisonscolumnDefs}
      ></AgGridReact>
    </div>
  );
}

export default Submissions;
