import React from "react";
import { useState, useEffect, useRef } from "react";
import styled from "./dropdown.module.scss";

const Dropdown = () => {
  const [open, setOpen] = useState(false);
  const [seasons, setSeasons] = useState("Seasons");
  const dropDownData = [
    "Spring 2022",
    "Summer 2022",
    "Fall 2022",
    "Winter 2022",
  ];
  let menuRef = useRef();
  useEffect(() => {
    let handler = (e) => {
      if (!menuRef.current?.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
    };
  });

  function DropDownItem(props) {
    return (
      <li
        className={styled.dropDownItem}
        onClick={(e) => {
          setSeasons(e.target.lastChild.innerHTML || e.target.innerHTML);
          setOpen(!open);
        }}
      >
        <a>{props.text}</a>
      </li>
    );
  }
  const listDropDownItems = dropDownData.map((value, index) => (
    <DropDownItem key={index} text={value} />
  ));

  return (
    <div className="menu-container relative" ref={menuRef}>
      <div
        className={styled.menuTrigger}
        onClick={() => {
          setOpen(!open);
        }}
      >
        {seasons}
      </div>
      <div
        className={`${styled.dropDownMenu} ${
          open ? styled.active : styled.inactive
        }`}
      >
        <ul>{listDropDownItems}</ul>
      </div>
    </div>
  );
};

export default Dropdown;
