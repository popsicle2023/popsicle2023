import React, { useEffect, useState } from 'react'
import profile from "../../public/assets/img/dash-board/profile.png";
import Image from "next/image";
import { Search } from "tabler-icons-react";
import { TextInput } from 'flowbite-react';


function AssigmentList({ list, showAssignModal }) {
    const [AssignListSearchValue, setAssignListSearchValue] = useState("");

    const onSearch = (e) => {
        setAssignListSearchValue(e.target.value);
    };
    return (
        <>
            <span className="contentTitle ">Student List</span>
            <div className="content mt-4 pb-2">
                <div className='relative'>
                    <TextInput
                        type="text"
                        placeholder="Search for a Student "
                        className="searchbar"
                        size="sm"
                        onChange={onSearch}
                        value={AssignListSearchValue}
                    />
                    <Search
                        size={20}
                        strokeWidth={2}
                        color={"#263238"}
                        className="absolute top-[12px] left-3"
                    />
                </div>
                <div className="h-[70vh] overflow-auto scrollbar">
                    {list.filter(
                        (data) =>
                            data.displayName.toLowerCase().indexOf(AssignListSearchValue.toLowerCase()) >= 0 ||
                            data.email.toLowerCase().indexOf(AssignListSearchValue.toLowerCase()) >= 0
                    ).map((value, index) => {
                        return (
                            <div key={index} className="flex items-center justify-between m-2 tableRow pt-2 pb-2 mx-6">
                                <div className="h-12   flex justify-start items-center rounded-full ">
                                    <Image src={profile} alt="Profile Photo" />
                                    <span className='tableText  ml-2'>{value.displayName}</span>
                                </div>
                                <span className='tableText'>{value.email}</span>
                                <button className='tableButton px-8 py-2' onClick={() => showAssignModal(value)}>Assign TA</button>
                            </div>
                        )
                    })}
                </div>
            </div>
        </>
    )
}

export default AssigmentList