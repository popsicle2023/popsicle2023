import React, { useEffect } from "react";
import { useState } from "react";
import { Button, Modal, TextInput, Tooltip } from "flowbite-react";
import logo from "../../public/assets/img/homework/Logo.png";
import blackboard from "../../public/assets/img/homework/blackboard.png";
import webwork from "../../public/assets/img/homework/webwork.png";
import calendar from "../../public/assets/img/dash-board/calendar.png";
import Image from "next/image";
import DatePicker from "react-datepicker";
import { toast } from "react-toastify";
import * as moment from 'moment'
import axios from "axios";
import { SubmissionTypeEnum, TypeEnum, UploadSubmissionsEnum } from "../../utils/Enums";
import { Outline } from "./Outlines";

const SaveExamine = ({ type, getData, TwiceStepModalActive, SetTwiceStepModalActive, uploadedData, SetUploadedData }) => {
    const [FirstStepModalActive, SetFirstStepModalActive] = useState(false);
    const [outlines, setOutlines] = useState([]);
    const [formExamine, setFormExamine] = useState({
        name: "",
        uploadSubmissions: "student",
        submissionType: "variable",
        endDate: new Date(),
        lateDate: new Date(),
        startDate: new Date(),
        groupSubmissionLimit: "",
        isEnabledGroupSubmission: false,
        isPublished: true,
        isRegrades: false,
        fileVisibility: true,
        files: [],
    });
    const [checkboxs, setcheckboxs] = useState({
        allStudents: false,
        disabledStudents: false,
        others: false,
        shareInstructors: false,
        shareStudents: false,
        shareTAs: false,
    });
    const [form, setForm] = useState({
        checkedRadio: "paperx"
    });
    useEffect(() => {
        if (uploadedData != undefined) {
            setFormExamine({
                name: uploadedData.name,
                uploadSubmissions: uploadedData.uploadSubmissions,
                submissionType: uploadedData.submissionType,
                endDate: Date.parse(uploadedData.endDate + " " + uploadedData.endTime),
                lateDate: Date.parse(uploadedData.lateDate + " " + uploadedData.lateTime),
                startDate: Date.parse(uploadedData.startDate + " " + uploadedData.startTime),
                groupSubmissionLimit: uploadedData.groupSubmissionLimit,
                isEnabledGroupSubmission: uploadedData.isEnabledGroupSubmission,
                fileVisibility: uploadedData.fileVisibility,
                groupSubmissionLimit: uploadedData.groupSubmissionLimit,
                isPublished: uploadedData.isPublished == undefined ? false : uploadedData.isPublished,
                isRegrades: uploadedData.isRegrades == undefined ? false : uploadedData.isRegrades,
                files: uploadedData.files,
            });
            setOutlines(uploadedData.outlines)
            let OthersChecked = uploadedData.allowLateSubmissions.indexOf("Others") > -1
            let AllStudentsChecked = uploadedData.allowLateSubmissions.indexOf("All Students") > -1
            let DisplayStudentsChecked = uploadedData.allowLateSubmissions.indexOf("Disabled Students") > -1
            setcheckboxs({
                allStudents: AllStudentsChecked,
                disabledStudents: DisplayStudentsChecked,
                others: OthersChecked,
                shareInstructors: uploadedData.shareInstructors,
                shareStudents: uploadedData.shareStudents,
                shareTAs: uploadedData.shareTAs,
            })
        }
        else {
            setFormExamine({
                name: "",
                uploadSubmissions: UploadSubmissionsEnum.student,
                submissionType: SubmissionTypeEnum.variable,
                endDate: new Date(),
                lateDate: new Date(),
                startDate: new Date(),
                groupSubmissionLimit: "",
                isEnabledGroupSubmission: false,
                fileVisibility: true,
                isPublished: true,
                isRegrades: false,
                files: [],
            })
            setOutlines([])
            setcheckboxs({
                allStudents: false,
                disabledStudents: false,
                others: false,
                shareInstructors: false,
                shareStudents: false,
                shareTAs: false,
            })
        }
    }, [uploadedData])
    const saveData = async () => {
        if (document.getElementById("files").files.length == 0 && uploadedData == undefined) {
            toast.error("Please Select File", "Error!")
            return;
        }
        if (document.getElementById("totalOutline")?.innerText != 100 && uploadedData != undefined) {
            toast.error("Outline required equals 100", "Error!")
            return;
        }
        if (formExamine.name == "") {
            toast.error("Name is required", "Error!")
            return;
        }
        let formData = new FormData();
        Object.values(document.getElementById("files").files).forEach(function (file, index) {
            formData.append("files", file)
        });

        checkboxs.allStudents == true ? formData.append('allowLateSubmissions', "All Students") : false
        checkboxs.disabledStudents == true ? formData.append('allowLateSubmissions', "Disabled Students") : false
        checkboxs.others == true ? formData.append('allowLateSubmissions', "Others") : false

        if (uploadedData == undefined) {
            formData.append('name', formExamine.name);
            formData.append('course', window.location.href.split("courseId=")[1]);
            formData.append('subType', form.checkedRadio)
        }
        formData.append('isPublished', formExamine.isPublished);
        formData.append('isRegrades', formExamine.isRegrades);
        formData.append('fileVisibility', formExamine.fileVisibility);
        formData.append('isEnabledGroupSubmission', formExamine.isEnabledGroupSubmission);
        formData.append('groupSubmissionLimit', formExamine.groupSubmissionLimit);
        formData.append('uploadSubmissions', formExamine.uploadSubmissions);
        formData.append('startDate', moment(formExamine.startDate).format("yyyy-MM-DD"));
        formData.append('endDate', moment(formExamine.endDate).format("yyyy-MM-DD"));
        formData.append('startTime', moment(formExamine.startTime).format("hh:mm"));
        formData.append('endTime', moment(formExamine.endTime).format("hh:mm"));
        formData.append('submissionType', formExamine.submissionType);
        formData.append('lateDate', moment(formExamine.lateDate).format("yyyy-MM-DD"))
        formData.append('lateTime', moment(formExamine.lateDate).format("hh:mm"))
        formData.append('shareInstructors', checkboxs.shareInstructors)
        formData.append('shareStudents', checkboxs.shareStudents)
        formData.append('shareTAs', checkboxs.shareTAs)
        // formData.append('outlines', JSON.stringify(outlines))

        let url = '/api/examine';
        if (uploadedData != undefined) {
            url = `/api/${type}/` + uploadedData._id;
        }
        else {
            url = `/api/${type}`;
        }
        axios({
            method: 'post',
            url: url,
            headers: {
                "Content-Type": "multipart/form-data",
                "x-access-token": localStorage.getItem("token"),
            },
            data: formData
        })
            .then(async function (response) {
                if (response.data.message = "başarılı") {
                    if (uploadedData != undefined) {
                        await axios({
                            method: 'put',
                            url: url,
                            headers: {
                                "Content-Type": "application/json",
                                "x-access-token": localStorage.getItem("token"),
                            },
                            data: {
                                outlines: outlines
                            }
                        })
                    }
                    getData(window.location.href.split("courseId=")[1]);
                    SetTwiceStepModalActive(false);
                    if (uploadedData != undefined) {
                        toast.success("Updated " + type, "Success")
                    }
                    else {
                        toast.success("Added New " + type, "Success")
                    }

                }
                else {
                    toast.error("Something Went Wrong", "Error")
                }
            })
            .catch(function (error) {
                if (error.response.data.isShowMessage) {
                    toast.error(error.response.data.message, "Error")
                }
                console.log(error);
            });


    }

    return (
        <div className="font-sans mt-4 m">
            <button className="text-cardblue border border-cardblue border-dashed w-md rounded-3xl p-2" onClick={() => { SetFirstStepModalActive(true); SetUploadedData(undefined) }}>
                + Create New {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
            <Modal show={FirstStepModalActive} size="md" popup={true} onClose={() => { SetFirstStepModalActive(false); }} >
                <Modal.Header />
                <Modal.Body>
                    <div className="container">
                        <div className="flex justify-center">
                            <span className="modal-title">Create New {type.charAt(0).toUpperCase() + type.slice(1)}</span>
                        </div>

                        <div className="flex-row">
                            <div className="flex items-center justify-center mt-4">
                                <input
                                    type="radio"
                                    name="type"
                                    value="paperx"
                                    onChange={(e) => setForm({ ...form, checkedRadio: e.target.value })}
                                    checked={form.checkedRadio === "paperx"}
                                />
                                <label htmlFor="paperx" className="ml-2">
                                    <Image
                                        src={logo}
                                        alt="Paper-x logo"
                                        priority
                                        width={100}
                                    />
                                </label>
                            </div>
                            <div className="flex items-center justify-center mt-4">
                                <input
                                    type="radio"
                                    name="type"
                                    value="blackboard"
                                    onChange={(e) => setForm({ ...form, checkedRadio: e.target.value })}
                                />
                                <label htmlFor="blackboard" className="ml-2">
                                    <Image
                                        src={blackboard}
                                        alt="blackboard"
                                        priority
                                        width={100}
                                    />
                                </label>
                            </div>
                            <div className="flex items-center justify-center mt-4">
                                <input
                                    type="radio"
                                    name="type"
                                    value="webwork"
                                    onChange={(e) => setForm({ ...form, checkedRadio: e.target.value })}
                                />
                                <label htmlFor="paperx" className="ml-2">
                                    <Image
                                        src={webwork}
                                        alt="webwork"
                                        priority
                                        width={100}
                                    />
                                </label>
                            </div>
                        </div>

                        <div className="mt-12 flex justify-center">
                            <button className="w-6/12 rounded-3xl border-0  pt-3 pb-3 bg-createnewcoursebtn text-white" onClick={() => { SetFirstStepModalActive(false); SetTwiceStepModalActive(true); }}>
                                Continue
                            </button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
            <Modal show={TwiceStepModalActive} size="4xl" popup={true} onClose={() => { SetTwiceStepModalActive(false); }}>
                <Modal.Header />
                <Modal.Body>
                    <div className="container ">
                        <div className="flex justify-center">
                            <span className="modal-title">
                                {uploadedData == undefined ? "Create New " + type.charAt(0).toUpperCase() + type.slice(1) :
                                    "Update " + type.charAt(0).toUpperCase() + type.slice(1)}
                            </span>

                        </div>
                        <div className="h-[60vh] overflow-auto p-6 scrollbar">
                            <div className="mt-7">
                                <div className="flex items-center justify-between">
                                    <span className="modal-subtitle ">
                                        General Information
                                    </span>
                                </div>
                            </div>
                            <div className="mt-4 ">
                                <div className="w-6/12">
                                    <label>Name:</label>
                                    <TextInput type="text" name="name" sizing="sm" value={formExamine.name} onChange={(e) => setFormExamine({ ...formExamine, name: e.target.value })} />
                                </div>
                                <div className="flex mt-4  justify-end">
                                    <input
                                        className="text-blue-10 font-sans text-sm  w-6/12"
                                        id="files"
                                        type="file"
                                        placeholder="Select a file from your device"
                                        name="files"
                                        multiple
                                        required
                                    />
                                    <div className="w-6/12">
                                        {
                                            formExamine.files.length > 0 &&
                                            <span><b>Uploaded  Documents:</b></span>
                                        }
                                        {
                                            formExamine.files.length > 0 &&
                                            formExamine.files.map((value, index) => {
                                                return (
                                                    <li className="flex  items-center" key={index}>{value.originalName}
                                                    </li>
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                            </div>
                            <div className="mt-4 flex-row">
                                <div className="">
                                    <label>Who Will Upload Submissions?</label>
                                </div>
                                <div className="w-6/12">
                                    <input
                                        type="radio"
                                        id="student"
                                        name="uploadSubmissions"
                                        onChange={(e) => setFormExamine({ ...formExamine, uploadSubmissions: UploadSubmissionsEnum.student })}
                                        checked={formExamine.uploadSubmissions === UploadSubmissionsEnum.student}
                                    />
                                    <label htmlFor="student" className="ml-2">
                                        students
                                    </label>
                                    <input
                                        type="radio"
                                        name="uploadSubmissions"
                                        className="ml-4"
                                        onChange={(e) => setFormExamine({ ...formExamine, uploadSubmissions: UploadSubmissionsEnum.teacher })}
                                        checked={formExamine.uploadSubmissions === UploadSubmissionsEnum.teacher}
                                    />
                                    <label htmlFor="Instructors" className="ml-2">
                                        Teachers
                                    </label>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Date & Time Information
                                    </span>
                                </div>
                                <div className="mt-4 flex">
                                    <div className="w-6/12 pr-6 relative">
                                        <label>Due Date:</label>
                                        <div>
                                            <DatePicker
                                                selected={formExamine.endDate} onChange={(date) => setFormExamine({ ...formExamine, endDate: date })}
                                                timeFormat="HH:mm"
                                                timeIntervals={20}
                                                timeCaption="time"
                                                dateFormat="dd.MM.yyyy h:mm"
                                                showTimeSelect

                                            />
                                            <Image
                                                src={calendar}
                                                alt="calendar"
                                                className="absolute right-8 bottom-2"
                                                priority
                                                width={20}
                                            />
                                        </div>
                                    </div>
                                    <div className="w-6/12 pl-6 relative">
                                        <label>Late Due Date:</label>
                                        <div>
                                            <DatePicker
                                                selected={formExamine.lateDate} onChange={(date) => setFormExamine({ ...formExamine, lateDate: date })}
                                                timeFormat="HH:mm"
                                                timeIntervals={20}
                                                timeCaption="time"
                                                dateFormat="dd.MM.yyyy h:mm"
                                                showTimeSelect

                                            />
                                            <Image
                                                src={calendar}
                                                alt="calendar"
                                                className="absolute right-2 bottom-2"
                                                priority
                                                width={20}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-4 flex">
                                    <div className="w-6/12 pr-6 relative">
                                        <label>Release  Date:</label>
                                        <div>
                                            <DatePicker
                                                selected={formExamine.startDate} onChange={(date) => setFormExamine({ ...formExamine, startDate: date })}
                                                timeFormat="HH:mm"
                                                timeIntervals={20}
                                                timeCaption="time"
                                                dateFormat="dd.MM.yyyy h:mm"
                                                showTimeSelect

                                            />
                                            <Image
                                                src={calendar}
                                                alt="calendar"
                                                className="absolute right-8 bottom-2"
                                                priority
                                                width={20}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Allow Late Submissions
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="checkbox" name="AllStudents" checked={checkboxs.allStudents} onChange={(e) => setcheckboxs({ ...checkboxs, allStudents: !checkboxs.allStudents })}></input>
                                        <label className="ml-2">All Students</label>
                                    </div>
                                    <div className="flex items-center mr-4">
                                        <input type="checkbox" name="DisabledStudents" checked={checkboxs.disabledStudents} onChange={(e) => setcheckboxs({ ...checkboxs, disabledStudents: !checkboxs.disabledStudents })}></input>
                                        <label className="ml-2">Disabled Students</label>
                                    </div>
                                    <div className="flex items-center">
                                        <input type="checkbox" name="Others" checked={checkboxs.others} onChange={(e) => setcheckboxs({ ...checkboxs, others: !checkboxs.others })}></input>
                                        <label className="ml-2">Others</label>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Submission Type
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="Submission" checked={formExamine.submissionType == SubmissionTypeEnum.variable} onChange={(e) => setFormExamine({ ...formExamine, submissionType: SubmissionTypeEnum.variable })}></input>
                                        <label className="ml-2">Variable Lenght</label><Tooltip content="Students submit any number of pages and indicate the pages where their responses to each question are."><span className="question-mark">?</span></Tooltip>
                                    </div>
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="Submission" checked={formExamine.submissionType == SubmissionTypeEnum.templated} onChange={(e) => setFormExamine({ ...formExamine, submissionType: SubmissionTypeEnum.templated })}></input>
                                        <label className="ml-2">Templated (fixed Length)</label><Tooltip content="Students submit work where answers are in fixed locations (like worksheets)."><span className="question-mark">?</span></Tooltip>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Group Submission
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <div className="flex-col">
                                            <input type="checkbox" name="isEnabledGroupSubmission" checked={formExamine.isEnabledGroupSubmission} onChange={(e) => setFormExamine({ ...formExamine, isEnabledGroupSubmission: !formExamine.isEnabledGroupSubmission })}></input>
                                            <label className="ml-2">Enable Group Submission</label>
                                        </div>
                                        <div className="flex-col  ml-4">
                                            <label className="ml-2">Limit Group Size:</label>
                                        </div>
                                        <div className="flex-col">
                                            <TextInput type="number" name="groupSubmissionLimit" value={formExamine.groupSubmissionLimit} sizing="sm" onChange={(e) => setFormExamine({ ...formExamine, groupSubmissionLimit: e.target.value })} />
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        File Visibility
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="checkbox" name="fileVisibility" checked={formExamine.fileVisibility} onChange={(e) => setFormExamine({ ...formExamine, fileVisibility: !formExamine.fileVisibility })}></input>
                                        <label className="ml-2">Allow Students to view and download file</label>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Published Settings
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="isPublished" value="true" checked={formExamine.isPublished == true} onChange={(e) => setFormExamine({ ...formExamine, isPublished: true })}></input>
                                        <label className="mr-2 ml-1">On</label>
                                    </div>
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="isPublished" value="false" checked={formExamine.isPublished == false || formExamine.isPublished == undefined} onChange={(e) => setFormExamine({ ...formExamine, isPublished: false })}></input>
                                        <label className="ml-1 ">Off</label>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Regrades Settings
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="isRegrades" value="true" checked={formExamine.isRegrades == true} onChange={(e) => { setFormExamine({ ...formExamine, isRegrades: true }) }}></input>
                                        <label className="mr-2 ml-1">On</label>
                                    </div>
                                    <div className="flex items-center mr-4">
                                        <input type="radio" name="isRegrades" value="false" checked={formExamine.isRegrades == false || formExamine.isRegrades == undefined} onChange={(e) => setFormExamine({ ...formExamine, isRegrades: false })}></input>
                                        <label className="ml-1 ">Off</label>
                                    </div>
                                </div>
                                <div className="mt-8">
                                    <span className="modal-subtitle ">
                                        Share Settings
                                    </span>
                                </div>
                                <div className="mt-4 flex ">
                                    <div className="flex items-center mr-4">
                                        <input type="checkbox" name="AllStudents" checked={checkboxs.shareInstructors} onChange={(e) => setcheckboxs({ ...checkboxs, shareInstructors: !checkboxs.shareInstructors })}></input>
                                        <label className="ml-2">Share course with Instructors</label>
                                    </div>
                                    <div className="flex items-center mr-4">
                                        <input type="checkbox" name="DisabledStudents" checked={checkboxs.shareTAs} onChange={(e) => setcheckboxs({ ...checkboxs, shareTAs: !checkboxs.shareTAs })}></input>
                                        <label className="ml-2">Share course with TAs</label>
                                    </div>
                                    <div className="flex items-center">
                                        <input type="checkbox" name="Others" checked={checkboxs.shareStudents} onChange={(e) => setcheckboxs({ ...checkboxs, shareStudents: !checkboxs.shareStudents })}></input>
                                        <label className="ml-2">Share course with Students</label>
                                    </div>
                                </div>
                                {
                                    uploadedData != undefined &&
                                    <div className="mt-8 flex">
                                        <div className="w-full">
                                            <Outline questionList={outlines} setQuestionList={setOutlines} ></Outline>
                                        </div>
                                    </div>
                                }
                            </div>
                        </div>
                        <div className="mt-12 flex justify-center">
                            <button className="w-6/12 rounded-3xl border-0  pt-3 pb-3 bg-createnewcoursebtn text-white " onClick={saveData}>
                                {uploadedData == undefined ? "Create New " + type.charAt(0).toUpperCase() + type.slice(1) :
                                    "Update " + type.charAt(0).toUpperCase() + type.slice(1)
                                }
                            </button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </div >
    );
};

export default SaveExamine;
