import React, { useEffect, useState } from 'react'
import Image from 'next/image'
import profile from "../../public/assets/img/dash-board/profile.png";
import trash from "../../public/assets/img/assignment/trash.png";
import RightSection from './RightSection';
import { Search } from "tabler-icons-react";
import { TextInput } from 'flowbite-react';

function AssignedList({ list, showDeleteModal }) {
    const [AssignedListSearchValue, setAssignedListSearchValue] = useState("");
    const onSearch = (e) => {
        setAssignedListSearchValue(e.target.value);
    };
    if (list.length > 0) {
        return (
            <>
                <span className="contentTitle ">Assigned List</span>
                <div className="relative mt-4">
                    <div>
                        <TextInput
                            type="text"
                            placeholder="Search for a Student "
                            className="searchbar"
                            size="sm"
                            onChange={onSearch}
                            value={AssignedListSearchValue}
                        />
                        <Search
                            size={20}
                            strokeWidth={2}
                            color={"#263238"}
                            className="absolute top-[12px] left-3"
                        />

                    </div>
                </div>
                <div className="h-[75vh] my-4 overflow-auto scrollbar">
                    {
                        list.filter(
                            (data) =>
                                data.displayName.toLowerCase().indexOf(AssignedListSearchValue.toLowerCase()) >= 0 ||
                                data.email.toLowerCase().indexOf(AssignedListSearchValue.toLowerCase()) >= 0
                        ).map((value, index) => {
                            return (
                                <div key={index} className="pt-2 pb-2 px-4  bg-white mb-2 assignedCard">
                                    <div className='flex justify-between'>
                                        <div className="h-12 flex justify-start items-center rounded-full ">
                                            <Image src={profile} alt="Profile Photo" />
                                            <span className='font-semibold text-[14px]  ml-2'>{value.displayName}</span>
                                        </div>
                                        <button onClick={() => showDeleteModal(value)}><Image src={trash} alt="Trash Icon" /></button>
                                    </div>
                                    <div className='flex-col'>
                                        <div className='flex-col'>
                                            <span className='font-semibold text-[14px]'>Email: </span> <span className='label-value'>{value.email}</span>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>

            </>
        )
    }
    else {
        return (
            <RightSection></RightSection>
        )
    }
}

export default AssignedList