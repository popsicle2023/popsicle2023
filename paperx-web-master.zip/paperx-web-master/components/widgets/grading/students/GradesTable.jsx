import React from "react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState } from "react";
import { AgGridReact } from "ag-grid-react";

const GradesTable = () => {
	const [rowData] = useState([
		{
			submissionType: "Final",
			yourEstGrade: "25",
			estCourseAverage: 36,
		},
		{
			submissionType: "Homework",
			yourEstGrade: "24",
			estCourseAverage: 47,
		},
		{
			submissionType: "Midterms",
			yourEstGrade: "12",
			estCourseAverage: 68,
		},
	]);

	const [columnDefs] = useState([
		{ field: "submissionType" },
		{ field: "yourEstGrade" },
		{ field: "estCourseAverage" },
		{ field: "graded" },
	]);

	return (
		<div className="ag-theme-alpine mx-4 h-[70vh]">
			<AgGridReact
				rowData={rowData}
				columnDefs={columnDefs}
				animateRows={true}
			></AgGridReact>
		</div>
	);
};

export default GradesTable;
