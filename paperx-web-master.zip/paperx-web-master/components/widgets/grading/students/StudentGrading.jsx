import React from "react";
import robot from "../../../../public/assets/img/grading/robot_right.png";
import ellipse from "../../../../public/assets/img/grading/ellipse.png";
import Image from "next/image";
import GradesTable from "./GradesTable";

const StudentGrading = () => {
	const gradeList = ["Homework", "Midterms", "Quizzes", "Other"];
	const gradeColorList = ["bg-blue", "bg-blue-10", "bg-orange", "bg-orange-10"];

	const CreateGradeScrollBar = () => {
		return (
			<>
				<div className="bg-white w-full h-8 flex my-3 rounded-full">
					{gradeColorList.map((value, index) => {
						return (
							<>
								{index === 0 ? (
									<span
										key={index}
										className={`h-8 ${value} basis-1/5 rounded-l-full mr-0.5`}
									></span>
								) : (
									<span className={`h-8 ${value} basis-1/5 mr-0.5`}></span>
								)}
							</>
						);
					})}
				</div>
				<div className="gradeTitle flex">
					{gradeList.map((value, index) => {
						return (
							<div key={index} className="flex mr-5">
								<div
									className={`h-3 w-3 rounded-full ${gradeColorList[index]} self-center mr-1`}
								></div>
								<span>{value}</span>
							</div>
						);
					})}
				</div>
			</>
		);
	};

	return (
		<>
			<div className="bg-blue-20 relative h-lg rounded-3xl my-8 mt-16 mx-4 p-4 px-8 shadow-lg">
				<Image
					src={robot}
					alt={"Robot"}
					style={{
						width: "min(230px, 100%)",
						height: "max(190px, 100%)",
						maxHeight: "auto",
						transform: "translate(3px, -3px)",
					}}
					className="absolute w-1/4 h-1/4 left-6 -top-16"
					priority
				/>
				<div className="ml-40 mr-4">
					<div className="flex justify-between">
						<div className="text-xl">
							Your Estimated Current Grade: <span></span>
						</div>
						<div className="text-xl">
							Estimated Course Average: <span></span>
						</div>
					</div>
					<CreateGradeScrollBar />
				</div>
			</div>
			<GradesTable />
		</>
	);
};

export default StudentGrading;
