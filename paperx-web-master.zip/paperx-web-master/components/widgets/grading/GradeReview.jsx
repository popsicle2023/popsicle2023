import React from "react";
import GradeStatistics from "../GradeStatistics";
import GradingChart from "../GradingChart";
import Table from "../Table";

export default function GradeReview() {
  var courseName = "MATH 141-1 Midterm";
  var gradeStatics = {
    Minimum: "25.0",
    Median: "89.0",
    Maximum: "100.0",
    Mean: "86.21",
    StdDev: "12.78",
  };
  var gradeChartData = [
    {
      userCount: 10,
      graduationScoreTotal: 10,
    },
    {
      userCount: 10,
      graduationScoreTotal: 10,
    },
    {
      userCount: 20,
      graduationScoreTotal: 20,
    },
    {
      userCount: 30,
      graduationScoreTotal: 30,
    },
    {
      userCount: 40,
      graduationScoreTotal: 40,
    },
    {
      userCount: 50,
      graduationScoreTotal: 50,
    },
    {
      userCount: 70,
      graduationScoreTotal: 70,
    },
    {
      userCount: 80,
      graduationScoreTotal: 80,
    },
    {
      userCount: 90,
      graduationScoreTotal: 90,
    },
    {
      userCount: 100,
      graduationScoreTotal: 100,
    },
  ];

  return (
    <>
      <div className="flex">
        <div className="flex w-full mx-8 mt-4">
          <div className="w-full">
            <div className="flex items-center ">
              <span className="pageTitle">TA Assigment</span>
              <span className="pageSubTitle">{courseName}</span>
            </div>
            <div className="mt-4">
              <span className="contentTitle">
                <button className="">Grade Statistics</button>
                <button className="pl-2">Grading List</button>
              </span>
            </div>
            <GradeStatistics data={gradeStatics}></GradeStatistics>
            <div className="content mt-4 pb-2">
              <GradingChart data={gradeChartData}></GradingChart>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
