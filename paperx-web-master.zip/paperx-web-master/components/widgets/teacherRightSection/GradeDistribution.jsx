import React from "react";
import robot from "../../../public/assets/img/right-section/robot.png";
import pencil from "../../../public/assets/img/right-section/pencil.png";
import divider from "../../../public/assets/img/right-section/divider.png";
import Image from "next/image";
import { Button, Modal } from "flowbite-react";
import EditCourseGradeDistribution from "../EditCourseGradeDistribution";

const RightSectionGradeDistribution = (hidden) => {

  return (
    <>
      <div className="bg-blue-20 w-full h-[80vh] rounded-[20px] my-6 py-6 p-4">
        <div className="flex justify-between items-center">
          <div className="text-xl font-semibold">Course Grade Distribution</div>
          <EditCourseGradeDistribution></EditCourseGradeDistribution>

        </div>
        <div className="flex justify-between items-center">
          {
            <div className="w-[25%] h-full flex justify-center items-center mr-2">
              {/* {
                  rightSectionData[1].course_home_page.course_grade_distribution
                    .DEFAULT.svg_left
                } */}
            </div>
          }
          <span className="flex justify-center items-center">
            You haven’t edited the grade distribution yet!
          </span>
          <Image
            src={robot}
            alt="Robot"
            style={{ width: "auto", height: "auto" }}
            priority
          />
        </div>
        <Image src={divider} alt="Divider" className="my-10 w-80 h-0.5" />
        <div>
          <div className="flex justify-between items-center">
            <div className="text-xl font-semibold">Course Information </div>
            <Image
              src={pencil}
              alt="Pencil"
              style={{ width: "35px", height: "35px", objectFit: "contain" }}
            />
          </div>
          <div className="mt-2 text-sm">
            {/* {console.log(
          Object.keys(
            rightSectionData[1].course_home_page.course_information
          )
        )} */}
            {/* {Object.entries(
              rightSectionData[1].course_home_page.course_information
            ).map((value, index) => {
              console.log(value)
              return (
                <div className="flex items-start mb-3" key={index}>
                  <span className="" key={index}>
                    {value[0]} : &nbsp;
                  </span>
                  <span className="font-semibold">{value[1]}</span>
                </div>
              );
            })} */}
          </div>
        </div>
        <div>
          <>
            <Modal show={false}>
              <Modal.Header>Terms of Service</Modal.Header>
              <Modal.Body>
                <div className="space-y-6">
                  <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    With less than a month to go before the European Union
                    enacts new consumer privacy laws for its citizens, companies
                    around the world are updating their terms of service
                    agreements to comply.
                  </p>
                  <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    The European Union’s General Data Protection Regulation
                    (G.D.P.R.) goes into effect on May 25 and is meant to ensure
                    a common set of data rights in the European Union. It
                    requires organizations to notify users as soon as possible
                    of high-risk data breaches that could personally affect
                    them.
                  </p>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <Button>I accept</Button>
                <Button color="gray">Decline</Button>
              </Modal.Footer>
            </Modal>
          </>
        </div>
      </div>
    </>
  );
};

export default RightSectionGradeDistribution;
