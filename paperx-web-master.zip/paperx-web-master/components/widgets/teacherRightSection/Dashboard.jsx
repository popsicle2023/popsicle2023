import React, { useEffect, useState } from "react";
import UserService from "../../../services/UserSevice";
import { useDispatch, useSelector } from "react-redux";
import { setShecudler } from "../../../slices/shecudler";
import Image from "next/image";
import elipse from "../../../public/assets/img/dash-board/elipse.png";
import watch from "../../../public/assets/img/dash-board/watch.png";
import calendar from "../../../public/assets/img/dash-board/calendar.png";
import Calendar from "../calendar/Calendar";
import * as moment from "moment";
const RightSectionDashboard = () => {
  const [selectedDate, setSelectedDate] = useState([
    {
      startDate: new Date(),
      endDate: null,
      key: "selection",
    },
  ]);
  const dispatch = useDispatch();
  async function getData() {
    console.log("test");
    var Schedules = await UserService.Schedules(
      moment(selectedDate[0].startDate).format("yyyy-MM-DD"),
      moment(selectedDate[0].endDate).format("yyyy-MM-DD")
    );
    dispatch(setShecudler({ Schedules: Schedules.data.result.data }));
  }
  useEffect(() => {
    getData();
  }, []);

  useEffect(() => {
    getData();
  }, [selectedDate]);
  const selectedPage = useSelector((store) => store.shecudlerReducer.Schedules);
  return (
    <>
      <div className="mt-4">
        <Calendar
          setSelectedDate={setSelectedDate}
          selectedDate={selectedDate}
        ></Calendar>
        {/* <div className="mt-4 shecdule mb-4">Your Schedule</div> */}
        {/* <div className="overflow-auto h-[40vh] scrollbar">
          {selectedPage?.map((item, index) => {
            return (
              <div key={index}>
                <div className="flex items-center">
                  <Image src={elipse} alt="elipse" className="mr-2"></Image>
                  <span className="shecdule">{item.name}</span>
                </div>
                <div className="shecduleitem shecduleSubTitle">
                  <div className="flex items-center">
                    <Image
                      src={calendar}
                      alt="calendar"
                      className="mr-2"
                    ></Image>
                    {new Date(item.endDate).toLocaleString("default", {
                      month: "long",
                    })}
                  </div>
                  <div className="flex items-center mt-2">
                    <Image src={watch} alt="watch" className="mr-2"></Image>
                    {item.endTime}
                  </div>
                </div>
              </div>
            );
          })}
        </div> */}
      </div>
    </>
  );
};

export default RightSectionDashboard;
