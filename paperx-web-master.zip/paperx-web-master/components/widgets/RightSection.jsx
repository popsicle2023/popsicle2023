import { useSelector } from "react-redux";
import Dashboard from "./teacherRightSection/Dashboard";
import GradeDistribution from "./teacherRightSection/GradeDistribution";

const RightSection = () => {
  const selectedCourseId = useSelector((store) => store.pageSettings.selectedCourseId);
  return (
    <div className="font-sans mr-6 bg-primary">
      {selectedCourseId !== "" && selectedCourseId !== undefined ? (
        <GradeDistribution />
      ) : (
        <Dashboard />
      )}
    </div>
  );
};

export default RightSection;
