import React from 'react'



function Table({ tableData }) {
    const TableModelHTML = ({ value, tableModel }) => {
        if (tableModel.html == undefined) {
            return (
                <span className='font-semibold text-[14px]'>{value[tableModel.dataName]}</span>
            )
        }
        else {
            return (
                <div>
                    <tableModel.html data={value}></tableModel.html>
                </div>
            )
        }
    }
    return (
        <>
            <table className='table'>
                <thead>
                    <tr>
                        {
                            tableData.tableModel.map((value, index) => {
                                return (
                                    <td key={index}>
                                        <div className='font-semibold text-[16px] w-full flex justify-center'>
                                            {
                                                typeof (value.header) == "string" ?
                                                    value.header
                                                    :
                                                    <value.header ></value.header>
                                            }
                                        </div>
                                    </td>
                                )
                            })
                        }
                    </tr>
                </thead>
                <tbody>
                    {
                        tableData.data.map((value, index) => {
                            return (
                                <tr key={index}>
                                    {
                                        tableData.tableModel.map((tableModel, indexx) => {
                                            return (
                                                <td key={indexx}>
                                                    <TableModelHTML value={value} tableModel={tableModel}></TableModelHTML>
                                                </td>
                                            )

                                        })

                                    }
                                </tr>

                            )
                        })
                    }
                </tbody>
            </table>
        </>
    )

}

export default Table;
