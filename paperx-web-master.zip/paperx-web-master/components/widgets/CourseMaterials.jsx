import React, { useEffect, useState } from "react";
import Tabs from "../Tabs/Tabs";
import CourseMaterial from "../../services/CourseMaterial";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-material.css";
import { AgGridReact } from "ag-grid-react";
import axios from "axios";
import { useRef } from "react";
import { PlayerPlay, Trash } from "tabler-icons-react";
import WhatchVideo from "./WhatchVideo";
import ReactPDF from "@react-pdf/renderer";

const CourseMaterials = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [videos, setVideos] = useState();
  const [printeds, setPrinteds] = useState();
  const gridApi = useRef(null);
  const [selectedVideo, setSelectedVideo] = useState();
  const [selectedPrinted, setSelectedPrinted] = useState();
  const [showPopup, setShowVideoPopup] = useState(false);
  const [tabs, setTabs] = useState("videos");

  const getPageData = async () => {
    let courseId = window.location.href.split("courseId=")[1];
    const data = await CourseMaterial.GetCourseMaterialVideos(courseId);
    // const dataVideos = data.data.result.videos;
    const dataPrinteds = data.data.result.printeds;
    const dataVideos = Object.keys(data.data.result.videos).map((key) => {
      return Object.assign({}, data.data.result.videos[key], {
        ["button"]: "button",
      });
    });

    dataVideos?.length > 0 ? setVideos(dataVideos) : setVideos(0);
    dataPrinteds?.length > 0 ? setPrinteds(dataPrinteds) : setPrinteds(0);
    // setVideos({ ...videos, button: "whatch" });
  };

  const openPopup = (src) => {
    setShowVideoPopup(true);
    setSelectedVideo(src);
    setSelectedPrinted(src);
  };
  const closePopup = () => {
    setShowVideoPopup(false);
    setSelectedVideo("");
    setSelectedPrinted("");
  };
  const onGridReady = (params) => {
    gridApi.current = params.api;
  };
  const [columnDefs, setColumnDefs] = useState([
    { field: "name" },
    { field: "size" },
    { field: "sizeType" },
    {
      field: "button",
      cellRenderer: (params) => (
        <div>
          <button
            onClick={(e) => {
              openPopup(params.data.name);
            }}
          >
            <PlayerPlay />
          </button>
          <button
            onClick={(e) => {
              openPopup(params.data.name);
            }}
          >
            <Trash />
          </button>
        </div>
      ),
    },
  ]);
  useEffect(() => {
    if (tabs === "videos") {
      setColumnDefs([
        { field: "name" },
        { field: "size" },
        { field: "sizeType" },
        {
          field: "button",
          cellRenderer: (params) => (
            <div>
              <button
                onClick={(e) => {
                  openPopup(params.data.name);
                }}
              >
                <PlayerPlay />
              </button>
              <button
                onClick={(e) => {
                  openPopup(params.data.name);
                }}
              >
                <Trash />
              </button>
            </div>
          ),
        },
      ]);
    } else {
      setColumnDefs([
        { field: "name" },
        { field: "size" },
        { field: "sizeType" },
        {
          field: "button",
          cellRenderer: (params) => (
            <div>
              <button
                onClick={(e) => {
                  openPopup(params.data);
                }}
              >
                <PlayerPlay />
              </button>
              <button
                onClick={(e) => {
                  openPopup(params.data);
                }}
              >
                <Trash />
              </button>
            </div>
          ),
        },
      ]);
    }
  }, [tabs]);

  useEffect(() => {
    getPageData();
  }, []);
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    let courseId = window.location.href.split("courseId=")[1];

    if (tabs === "videos") {
      Object.values(document.getElementById("fileUpload").files).forEach(
        function (file) {
          formData.append("videos", file);
        }
      );
    } else {
      Object.values(document.getElementById("fileUpload").files).forEach(
        function (file) {
          formData.append("printeds", file);
        }
      );
    }

    // formData.append("videos", event.target.querySelector("#fileUpload").files);

    // await UpdateCourseMaterial(courseId, 'test')
    await axios({
      url: "/api/course/" + courseId,
      method: "POST",
      headers: {
        "Content-Type": "multipart/form-data",
        "x-access-token": localStorage.getItem("token"),
      },
      data: formData,
    })
      .then((result) => {
        // console.log(result)
      })
      .catch((err) => {
        // console.log(err)
      });

    getPageData();
    setIsOpen(false);
  };

  function fileControl(event) {
    var fileName = document.querySelector("#fileUpload").files[0]?.name;
    var fileExtension = fileName.substr(fileName.lastIndexOf(".") + 1);
    if (
      fileExtension == "pdf" ||
      fileExtension == "docx" ||
      fileExtension == "doc" ||
      fileExtension == "pptx" ||
      fileExtension == "ppt"
    ) {
      // type = 'printed';
      document.querySelector("#fileUpload").style.color = "green";
      document.querySelector("#fileUpload").style.fontSize = "20px";
      document.querySelector("#fileUpload").style.fontWeight = "bold";
      document.querySelector("#fileUpload").style.fontFamily = "sans-serif";
      document.querySelector("#fileUpload").style.backgroundColor = "white";
      document.querySelector("#fileUpload").style.cursor = "pointer";
      document.querySelector("#fileUpload").style.transition =
        "all 0.3s ease-in-out";
      document.querySelector("#fileUpload").style.outline = "none";
      document.querySelector("#fileUpload").style.boxShadow = "0 0 0 0";
      document.querySelector("#fileUpload").style.webkitBoxShadow = "0 0 0 0";
    } else if (
      fileExtension == "mp4" ||
      fileExtension == "mov" ||
      fileExtension == "avi" ||
      fileExtension == "wmv" ||
      fileExtension == "flv" ||
      fileExtension == "mkv" ||
      fileExtension == "jpg" ||
      fileExtension == "png"
    ) {
      // type = 'video';
      document.querySelector("#fileUpload").style.borderColor = "green";
      document.querySelector("#fileUpload").style.color = "green";
      document.querySelector("#fileUpload").style.borderStyle = "solid";
      document.querySelector("#fileUpload").style.borderWidth = "1px";
    } else {
      // type = 'error';
      document.querySelector("#fileUpload").style.color = "red";
      document.querySelector("#fileUpload").style.fontSize = "20px";
      document.querySelector("#fileUpload").style.fontWeight = "bold";
      document.querySelector("#fileUpload").style.fontFamily = "sans-serif";
      document.querySelector("#fileUpload").style.cursor = "pointer";
    }
  }

  return (
    <div className="px-2">
      {showPopup && (
        <WhatchVideo
          video={selectedVideo}
          closePopup={closePopup}
          printed={selectedPrinted}
          tab={tabs}
        />
      )}
      <div className="text-blue-10 text-4xl mt-6 font-semibold bg-primary font-sans">
        <div className="pt-[1.688rem]">
          <div className="text-gray-100 font-semibold text-2xl font-sans">
            <Tabs setTabs={setTabs}>
              <span
                label={`Video Course Materials (${
                  videos?.length > 0 ? videos?.length : 0
                })`}
              >
                <div className="ag-theme-material h-[40vh] px-8">
                  <AgGridReact
                    suppressRowHoverHighlight={true}
                    animateRows={true}
                    rowData={videos}
                    columnDefs={columnDefs}
                    onGridReady={onGridReady}
                    rowSelection={true}
                  ></AgGridReact>
                </div>
              </span>
              <span
                label={`Printed Course Materials (${
                  printeds?.length > 0 ? printeds?.length : 0
                })`}
              >
                <div className="ag-theme-material h-[40vh] px-8">
                  <AgGridReact
                    animateRows={true}
                    rowData={printeds}
                    columnDefs={columnDefs}
                  ></AgGridReact>
                </div>
              </span>
              {/* <span
                label={`Video Course Materials (${
                  videos?.length > 0 ? videos?.length : 0
                })`}
              >
                <UploadNewMaterial type="video" />
              </span>
              <span
                label={`Printed Course Materials (${
                  printeds?.length > 0 ? printeds?.length : 0
                })`}
              >
                <UploadNewMaterial type="printed" />
              </span> */}
            </Tabs>
            {isOpen && (
              <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center">
                <div className="bg-blend-darken !impo">
                  <div className="bg-white rounded-3xl">
                    <div className="text-right pt-8 pr-8">
                      <button onClick={() => setIsOpen(false)}>
                        <svg
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M15.71 8.29008C15.617 8.19635 15.5064 8.12196 15.3846 8.07119C15.2627 8.02042 15.132 7.99428 15 7.99428C14.868 7.99428 14.7373 8.02042 14.6154 8.07119C14.4936 8.12196 14.383 8.19635 14.29 8.29008L12 10.5901L9.71 8.29008C9.5217 8.10178 9.2663 7.99599 9 7.99599C8.7337 7.99599 8.47831 8.10178 8.29 8.29008C8.1017 8.47838 7.99591 8.73378 7.99591 9.00008C7.99591 9.26638 8.1017 9.52178 8.29 9.71008L10.59 12.0001L8.29 14.2901C8.19627 14.383 8.12188 14.4936 8.07111 14.6155C8.02034 14.7374 7.9942 14.8681 7.9942 15.0001C7.9942 15.1321 8.02034 15.2628 8.07111 15.3847C8.12188 15.5065 8.19627 15.6171 8.29 15.7101C8.38297 15.8038 8.49357 15.8782 8.61543 15.929C8.73729 15.9797 8.86799 16.0059 9 16.0059C9.13201 16.0059 9.26272 15.9797 9.38458 15.929C9.50644 15.8782 9.61704 15.8038 9.71 15.7101L12 13.4101L14.29 15.7101C14.383 15.8038 14.4936 15.8782 14.6154 15.929C14.7373 15.9797 14.868 16.0059 15 16.0059C15.132 16.0059 15.2627 15.9797 15.3846 15.929C15.5064 15.8782 15.617 15.8038 15.71 15.7101C15.8037 15.6171 15.8781 15.5065 15.9289 15.3847C15.9797 15.2628 16.0058 15.1321 16.0058 15.0001C16.0058 14.8681 15.9797 14.7374 15.9289 14.6155C15.8781 14.4936 15.8037 14.383 15.71 14.2901L13.41 12.0001L15.71 9.71008C15.8037 9.61712 15.8781 9.50652 15.9289 9.38466C15.9797 9.2628 16.0058 9.13209 16.0058 9.00008C16.0058 8.86807 15.9797 8.73736 15.9289 8.6155C15.8781 8.49364 15.8037 8.38304 15.71 8.29008ZM19.07 4.93008C18.1475 3.97498 17.0441 3.21316 15.824 2.68907C14.604 2.16498 13.2918 1.88911 11.964 1.87757C10.6362 1.86604 9.31943 2.11905 8.09046 2.62186C6.8615 3.12467 5.74498 3.8672 4.80605 4.80613C3.86713 5.74506 3.1246 6.86158 2.62179 8.09054C2.11898 9.3195 1.86596 10.6363 1.8775 11.9641C1.88904 13.2919 2.1649 14.6041 2.68899 15.8241C3.21308 17.0442 3.9749 18.1476 4.93 19.0701C5.85247 20.0252 6.95592 20.787 8.17596 21.3111C9.396 21.8352 10.7082 22.111 12.036 22.1226C13.3638 22.1341 14.6806 21.8811 15.9095 21.3783C17.1385 20.8755 18.255 20.133 19.194 19.194C20.1329 18.2551 20.8754 17.1386 21.3782 15.9096C21.881 14.6807 22.134 13.3639 22.1225 12.0361C22.111 10.7083 21.8351 9.39607 21.311 8.17603C20.7869 6.95599 20.0251 5.85255 19.07 4.93008ZM17.66 17.6601C16.352 18.9695 14.6305 19.7849 12.7888 19.9674C10.9471 20.1499 9.09901 19.6881 7.55953 18.6609C6.02004 17.6336 4.88436 16.1043 4.34598 14.3336C3.80759 12.5628 3.89981 10.6602 4.60692 8.94986C5.31403 7.23951 6.59228 5.82723 8.22389 4.95364C9.85551 4.08006 11.7395 3.79921 13.555 4.15895C15.3705 4.5187 17.005 5.49677 18.1802 6.92654C19.3554 8.35631 19.9985 10.1493 20 12.0001C20.0036 13.0514 19.7986 14.0929 19.3969 15.0645C18.9953 16.036 18.4049 16.9182 17.66 17.6601Z"
                            fill="#263238"
                          />
                        </svg>
                      </button>
                    </div>
                    <form onSubmit={handleSubmit}>
                      <div className="mb-4 text-center px-16">
                        <label
                          className="block text-gray-700 text-2xl font-bold pt-8"
                          htmlFor="description"
                        >
                          Upload New Course Material
                        </label>
                        <input
                          className="border-0 border-b-[1px] w-full mt-9 mb-[2.375rem] border-gray-300 text-gray-700"
                          id="description"
                          type="text"
                          placeholder="Title"
                          name="description"
                          required
                        />

                        <div className="flex">
                          <input
                            className="text-blue-10 font-sans text-sm mb-16"
                            id="fileUpload"
                            type="file"
                            placeholder="Select a file from your device"
                            name="fileUpload"
                            onChange={(e) => fileControl(e)}
                            required
                            multiple
                          />
                          <svg
                            width="26"
                            height="24"
                            viewBox="0 0 26 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M14.1085 12.0001L10.3799 15.5401C10.1837 15.7274 10.0736 15.9809 10.0736 16.2451C10.0736 16.5092 10.1837 16.7627 10.3799 16.9501C10.4778 17.0438 10.5943 17.1182 10.7226 17.1689C10.851 17.2197 10.9886 17.2458 11.1277 17.2458C11.2667 17.2458 11.4044 17.2197 11.5328 17.1689C11.6611 17.1182 11.7776 17.0438 11.8755 16.9501L16.3414 12.7101C16.4401 12.6171 16.5185 12.5065 16.572 12.3846C16.6255 12.2628 16.653 12.1321 16.653 12.0001C16.653 11.868 16.6255 11.7373 16.572 11.6155C16.5185 11.4936 16.4401 11.383 16.3414 11.2901L11.8755 7.00005C11.7771 6.90737 11.6604 6.83405 11.532 6.78428C11.4037 6.73452 11.2663 6.70929 11.1277 6.71005C10.9891 6.70929 10.8517 6.73452 10.7233 6.78428C10.595 6.83405 10.4783 6.90737 10.3799 7.00005C10.1837 7.18741 10.0736 7.44087 10.0736 7.70505C10.0736 7.96924 10.1837 8.22269 10.3799 8.41005L14.1085 12.0001Z"
                              fill="#3A5AFF"
                            />
                          </svg>
                        </div>

                        <button
                          className="items-center w-full justify-between mb-16 text-base py-4 bg-orange hover:bg-orange-600 text-white font-bold  rounded-full focus:outline-none focus:shadow-outline"
                          type="submit"
                        >
                          Upload
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            )}
            <button
              className="flex px-[4.625rem] py-4 mt-8 border-dashed border-2  ml-8 rounded-full border-indigo-600 text-center font-sans text-base"
              onClick={() => setIsOpen(true)}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="mr-[0.625rem]"
              >
                <path
                  d="M19 11H13V5C13 4.73478 12.8946 4.48043 12.7071 4.29289C12.5196 4.10536 12.2652 4 12 4C11.7348 4 11.4804 4.10536 11.2929 4.29289C11.1054 4.48043 11 4.73478 11 5V11H5C4.73478 11 4.48043 11.1054 4.29289 11.2929C4.10536 11.4804 4 11.7348 4 12C4 12.2652 4.10536 12.5196 4.29289 12.7071C4.48043 12.8946 4.73478 13 5 13H11V19C11 19.2652 11.1054 19.5196 11.2929 19.7071C11.4804 19.8946 11.7348 20 12 20C12.2652 20 12.5196 19.8946 12.7071 19.7071C12.8946 19.5196 13 19.2652 13 19V13H19C19.2652 13 19.5196 12.8946 19.7071 12.7071C19.8946 12.5196 20 12.2652 20 12C20 11.7348 19.8946 11.4804 19.7071 11.2929C19.5196 11.1054 19.2652 11 19 11Z"
                  fill="#3A5AFF"
                />
              </svg>
              Upload New Material
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseMaterials;
