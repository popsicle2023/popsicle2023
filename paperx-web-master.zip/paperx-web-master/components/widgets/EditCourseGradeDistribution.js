import React, { useState } from 'react'
import pencil from "../../public/assets/img/right-section/pencil.png";
import { Button, Dropdown, Modal, TextInput } from 'flowbite-react';
import Image from 'next/image';

function EditCourseGradeDistribution() {
    const [IsActive, SetIsActive] = useState(false);

    return (
        <>
            <div className="font-sans mt-4 m">

                <a onClick={() => { SetIsActive(true) }}>
                    <Image
                        src={pencil}
                        alt="Pencil"
                        style={{ width: "28px", objectFit: "contain" }}
                    />
                </a>
                <Modal show={IsActive} size="xl" popup={true} onClose={() => { SetIsActive(false) }}>
                    <Modal.Header />
                    <Modal.Body>
                        <div className="container">
                            <div className="flex justify-center">
                                <span className="modal-title">Edit Course Grade Distribution </span>
                            </div>
                            <div className="mt-7">
                                <span className="form-title">
                                    General Information
                                </span>
                            </div>

                            <div className="flex justify-between">
                                <div className="mt-5 mr-5 w-6/12">
                                    <label>School Name</label>
                                    <Dropdown
                                        isSearchable
                                        placeHolder="Select..."
                                        name="schoolName"
                                    />
                                </div>
                                <div className="mt-5 mr-5 w-6/12 flex">
                                    <label>Grade Distribution:</label>
                                    <TextInput></TextInput>
                                </div>
                            </div>


                            <div className="mt-12 flex justify-center">
                                <Button id="savebutton" className="button-orange" disabled={false} >
                                    Create New Course
                                </Button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            </div >
        </>
    )
}

export default EditCourseGradeDistribution