import { Button, Modal } from "flowbite-react";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import SubmissionService from "../../services/SubmissionService";
import "tui-image-editor/dist/tui-image-editor.css";
const ImageEditor = dynamic(() => import("@toast-ui/react-image-editor"), {
  ssr: false,
});
import dynamic from "next/dynamic";
import { Outline } from "./Outlines";
import Image from "next/image";
import exams from "../../services/exams";
import { ChevronsLeft, ChevronsRight } from "tabler-icons-react";
import { useDispatch, useSelector } from "react-redux";
import { setselectedSubmission, selectedSubmissionUp, selectedSubmissionDown } from '../../slices/selected-submission'

const DrawingCanvas = ({
  type,
  getData,
  setSelectedStudentData,
  studentDatas,
  imgPath,
  setImgPath
}) => {
  const imageEditorRef = React.createRef();
  const [pending, setPending] = useState(false);
  const [questionList, setQuestionList] = useState([]);
  const [AmI, SetAmI] = useState(JSON.parse(localStorage.getItem("WhoAmI")));
  const selectedSubmission = useSelector((store) => store.selectedSubmissionReducer.selectedSubmission);
  const dispatch = useDispatch();
  useEffect(() => {
    if (studentDatas.outlines != undefined)
      setQuestionList(studentDatas.outlines);
    else {
      if (!AmI.roles.includes("student")) getOutlinesByExam();
    }
  }, []);

  const getOutlinesByExam = async () => {
    var respone = await exams.GetExamById(studentDatas.exam.id);
    setQuestionList(respone.data.result.outlines);
  };

  function urltoFile(url, filename, mimeType) {
    return fetch(url)
      .then(function (res) {
        return res.arrayBuffer();
      })
      .then(function (buf) {
        return new File([buf], filename, { type: mimeType });
      });
  }

  const SavePoints = async () => {
    let total = questionList?.reduce(
      (acc, question) =>
        acc +
        Number(question.childs.length == 0 ? question.point : 0) +
        question.childs.reduce(
          (acc, subRating) => acc + Number(subRating.point),
          0
        ),
      0
    )
    if (total > 100) {
      toast.error("The maximum score is 100", "Error");
      return false;
    }
    var myImage = document.getElementsByClassName("lower-canvas")[0]?.toDataURL("image/png");
    let formData = new FormData();
    var sfile = urltoFile(myImage, studentDatas.submissions[selectedSubmission].id, "image/png");
    const promise1 = Promise.resolve(sfile);
    await promise1.then((value) => {
      // console.log((value.size / (1024*1024)).toFixed(2))

      formData.append("answers", value);
    });
    formData.append("submissionId", studentDatas.submissions[selectedSubmission].id);
    setPending(true)
    toast.info("This Process is in progress, Please Wait...", "Success");
    await SubmissionService.SendSubmissionAnswer(
      studentDatas._id,
      formData
    ).then(response => {
      SubmissionService.UpdateSubmissionFile(
        studentDatas._id,
        { outlines: questionList }
      ).then(response => {
        setPending(false)
        if ((response.data.message = "başarılı")) {
          getData(window.location.href.split("courseId=")[1]);
          toast.success("Saved Your Settings", "Success");
        }
      });

    });

  };
  const upCount = () => {
    let answer = studentDatas.answers?.find(x => x.submissionId === studentDatas.submissions[selectedSubmission + 1]?.id);
    if (answer?.name != undefined) {
      setImgPath(answer.name)
    }
    else {
      setImgPath(studentDatas.submissions[selectedSubmission + 1].name)
    }
    dispatch(setselectedSubmission({ selectedSubmission: selectedSubmission + 1 }))

  }
  const downCount = () => {
    let answer = studentDatas.answers?.find(x => x.submissionId === studentDatas.submissions[selectedSubmission - 1]?.id);
    if (answer?.name !== undefined) {
      setImgPath(answer.name)
    }
    else {
      setImgPath(studentDatas.submissions[selectedSubmission - 1].name)
    }
    dispatch(setselectedSubmission({ selectedSubmission: selectedSubmission - 1 }))
  }
  const onSelectedSubmission = (isUp) => {
    setTimeout(() => {
      let studentData = studentDatas;
      if (isUp)
        upCount()
      else
        downCount()
      setSelectedStudentData(undefined)
      setTimeout(() => {
        setSelectedStudentData(studentData)
      }, 30);
    }, 30);
  }
  return (
    <>

      <div>
        <div className="flex p-4 overflow-auto">
          {
            imgPath &&
            (studentDatas.submissions != undefined ||
              studentDatas.answers != undefined) &&
            <div className="w-8/12 pr-16">
              {
                studentDatas?.submissions &&
                ((AmI.roles.includes("teacher") ||
                  AmI.roles?.includes("superUser"))
                  ? (
                    <div className="h-[70vh]">
                      <ImageEditor
                        ref={imageEditorRef}
                        includeUI={{
                          loadImage: { path: `/api/file/${imgPath}`, name: imgPath, },
                          logo: false,
                          menu: ["shape", "text", "draw", "icon"],
                          uiSize: { height: "100%", },
                          menuBarPosition: "bottom",
                        }}
                        selectionStyle={{ cornerSize: 20, rotatingPointOffset: 70, }}
                        usageStatistics={true}
                      />
                    </div>
                  ) : (
                    <div className="h-[70vh]">
                      <Image src={`/api/file/${imgPath}`} alt="exam paper" width={600} height={600} />
                    </div>
                  ))
              }
            </div>
          }
          <div className={(studentDatas.submissions != undefined ||
            studentDatas.answers != undefined) ? "w-4/12 flex-row" : "w-full flex-row"}>
            <Outline
              outlineTitles={studentDatas?.submissions != undefined ? studentDatas?.submissions[selectedSubmission].outlineTitles : []}
              type="exam"
              questionList={questionList}
              setQuestionList={setQuestionList}
            />
          </div>
        </div>
        <div className="flex justify-between">
          {
            studentDatas.submissions != undefined &&
            <div className="flex justify-around w-full">
              <div className="w-4/12">
                <ChevronsLeft onClick={() => { onSelectedSubmission(false) }} hidden={studentDatas?.submissions[selectedSubmission - 1]?.name == undefined} />
              </div>
              <div className="w-4/12">
                {selectedSubmission + 1}
              </div>
              <div className="w-4/12">
                <ChevronsRight onClick={() => { onSelectedSubmission(true) }} hidden={studentDatas?.submissions[selectedSubmission + 1]?.name == undefined} />
              </div>
            </div>
          }
          <div className="flex justify-end">
            <Button className="mr-4" color={"dark"} onClick={() => { setSelectedStudentData(undefined); }}>Close</Button>
            {
              studentDatas?.submissions != undefined &&
              <Button onClick={SavePoints} disabled={pending}>Save</Button>
            }
          </div>
        </div>
      </div>

    </>
  );
};

export default DrawingCanvas;
