import Image from "next/image";
import React from "react";
import webwork from "../../public/assets/img/about-us/webwork.png";

const Compatable = () => {
  return (
    <div className="{classes.root}">
      <div className="compatible-column">
        <div className="compatible-left-row">
          <h2>Compatible with</h2>
        </div>
        <div className="compatible-middle-row">
          <Image
            src={webwork}
            alt="Webwork University"
            width={35}
            height={35}
            className="h-auto w-auto"
          />
        </div>
        <div className="compatible-right-row">
          <h2>Blackboard</h2>
        </div>
      </div>
    </div>
  );
};

export default Compatable;
