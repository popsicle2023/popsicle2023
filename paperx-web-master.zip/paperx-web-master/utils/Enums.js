export const StatusEnum = {
    created: "created", completed: "completed", published: "published", regrades: "regrades"
}
export const TypeEnum = {
    exam: "exam", homework: "homework", quiz: "quiz"
}
export const UploadSubmissionsEnum = {
    student: "student", teacher: "teacher"
}
export const SubmissionTypeEnum = {
    variable: "variable", templated: "templated"
}