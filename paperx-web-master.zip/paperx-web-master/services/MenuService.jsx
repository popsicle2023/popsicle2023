import api from "../api";

class MenuService {
    async GetMenu() {
        return await api.post('/api/menu-tree', {
            "level": -1
        }).then(async response => {
            return await response;
        });
    }
}
export default new MenuService();
