import api from "../api";

class CourseMaterialService {
  // async GetCourseMaterialList() {
  //   return await api.get("/api/courses").then(async (response) => {
  //     return await response;
  //   });
  // }
  async GetCourseMaterialVideos(id) {
    return await api.get("/api/course/" + id).then(async (response) => {
      return await response;
    });
  }
  // async GetCourseMaterialById(id) {
  //   return await api.get("/api/exams/" + id).then(async (response) => {
  //     return await response;
  //   });
  // }
  // async AddCourseMaterial(data) {
  //   return await api.post("/api/exam", data).then(async (response) => {
  //     return await response;
  //   });
  // }
  async UpdateCourseMaterial(id, data) {
    console.log(id, data);
    return await api.post("/api/course/" + id, data).then(async (response) => {
      return await response;
    });
  }
  // async SetCourseMaterial(id, data) {
  //   return await api.put("/api/exam/" + id, data).then(async (response) => {
  //     return await response;
  //   });
  // }
}
export default new CourseMaterialService();
