import api from "../api";

class ExamService {
	async getGradeList() {
		return null;
	}

	// async GetExamList() {
	//   return await api.get("/api/exams").then(async (response) => {
	//     return await response;
	//   });
	// }
	// async GetExamById(id) {
	//   return await api.get("/api/exam/" + id).then(async (response) => {
	//     return await response;
	//   });
	// }
	// async AddExam(data) {
	//   return await api.post("/api/exam", data).then(async (response) => {
	//     return await response;
	//   });
	// }
	// async UpdateExam(id, data) {
	//   return await api.post("/api/exam/" + id, data).then(async (response) => {
	//     return await response;
	//   });
	// }
	// async SetExam(id, data) {
	//   return await api.put("/api/exam/" + id, data).then(async (response) => {
	//     return await response;
	//   });
	// }
}
export default new ExamService();
