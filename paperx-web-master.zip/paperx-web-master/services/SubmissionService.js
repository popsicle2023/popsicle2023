import axios from "axios";
import api from "../api";

class SubmissionService {
    async GetAllSubmissionByType(type, courseId) {
        return await api.get(`/api/submissions?examType=${type}&courseId=${courseId}`).then(async response => {
            return await response;
        });
    }
    async GetSubmissionById(submissionId){
        return await api.get(`/api/submission/${submissionId}`).then(async response => {
            return await response;
        });
    }
    async UpdateSubmissionFile(submissionId, data) {
        return await api.put(`/api/submission/${submissionId}`, data).then(async response => {
            return await response;
        });
    }
    async SubmissionEvaluate(data) {
        return await api.post(`/api/submission-evaluate`, data).then(async response => {
            return await response;
        });
    }
    async SendSubmissionAnswer(submissionId, data) {
        axios({
            method: 'post',
            url: `/api/submission-answer/${submissionId}`,
            headers: {
                "Content-Type": "multipart/form-data",
                "x-access-token": localStorage.getItem("token"),
            },
            data: data
        })
            .then(async function (response) {
                return await response
            })
            .catch(function (error) {
                console.log(error);
            });
    }
}
export default new SubmissionService();
