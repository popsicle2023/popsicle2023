import { useDispatch } from "react-redux";
import api from "../api";

class UserService {
  users() {
    return api.get("/users");
  }
  async GetUsersByCourseId(courseId) {
    return api.get("/users", { courseId: courseId }).then(async (response) => {
      return await response;
    });
  }
  async WhoAmI() {
    if (
      localStorage.getItem("WhoAmI") == "undefined" ||
      localStorage.getItem("WhoAmI") == undefined
    )
      return api
        .post("/api/whoami", {
          level: -1,
        })
        .then(async (response) => {
          localStorage.setItem("WhoAmI", JSON.stringify(response.data.result));
          return await response.data.result;
        });
    else return await localStorage.getItem("WhoAmI");
  }
  async Schedules(startDate, endDate) {
    return api
      .get("/api/schedules", {
        startDate: startDate,
        endDate: endDate,
      })
      .then(async (response) => {
        return await response;
      });
  }
}

export default new UserService();
