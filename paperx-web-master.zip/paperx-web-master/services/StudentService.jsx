import api from "../api";

class StudentService {
    async GetStudentsByCategoryId(id) {
        return await api.get('/api/students?courseId='+id).then(async response => {
            return await response;
        });
    }
    async GetStudentsByAssignedCategoryId(id) {
        return await api.get('/api/students?courseIdEq='+id).then(async response => {
            return await response;
        });
    }
}
export default new StudentService();
