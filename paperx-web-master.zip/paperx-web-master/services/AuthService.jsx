import { toast } from "react-toastify";
import api from "../api";
import TokenService from "./TokenService";
import UserService from "./UserSevice";
class AuthService {
    async login(username, password, rememberMe) {
        return api
            .post("/api/login", {
                unameOrEmail: username,
                password,
                rememberMe,
            })
            .then(async (response) => {
                if (response.data.isShowMessage) {
                    toast.error(response.data.message, "Error!");
                }
                if (response.data.result.token) {
                    await UserService.WhoAmI();
                    localStorage.setItem("expiredDate", new Date());
                    await TokenService.setToken(response.data.result.token);
                    return response;
                }
            });
    }

    checkAuth() {
        if (TokenService.getToken() != undefined) {
            return true;
        } else {
            return false;
        }
    }
    logout() {
        localStorage.clear();
        TokenService.removeToken();
    }
    async resetPassword(password) {
        return api
            .post(`/api/user/${JSON.parse(await localStorage.getItem("WhoAmI")).id}`, {
                password: password,
                requirePasswordChange: false
            })
            .then(async response => {
                if (response.data.isShowMessage) {
                    toast.error(response.data.message, "Error!")
                }
                toast.success("Password Reset Succsesfully!", "Succes")
                window.location.href = "/dashboard";
                return response;
            });
    }

    logout() {
        localStorage.clear();
        TokenService.removeToken();
    }
    getCurrentUser() {
        return TokenService.getUser();
    }
}

export default new AuthService();
