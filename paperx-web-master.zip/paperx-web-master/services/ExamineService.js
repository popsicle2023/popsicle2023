import api from "../api";

class FileService {
    async GetListByType(type, courseid) {
        return await api.get('/api/examines?type=' + type + '&course.id=' + courseid).then(async response => {
            return await response;
        });
    }

}
export default new FileService();
