class TokenService {
    getLocalAccessToken() {
        const token = JSON.parse(localStorage.getItem("token"));
        return token;
    }

    // updateLocalAccessToken(token) {
    //     let accessToken = JSON.parse(localStorage.getItem("token"));
    //     localStorage.setItem("token", JSON.stringify(accessToken));
    // }

    getToken() {
        return JSON.parse(localStorage.getItem("token"));
    }

    async setToken(token) {
        localStorage.setItem("token", JSON.stringify(token));
    }

    removeToken() {
        localStorage.removeItem("token");
    }
}

export default new TokenService();