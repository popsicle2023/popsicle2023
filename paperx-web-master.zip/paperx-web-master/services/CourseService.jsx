import api from "../api";

class CourseService {
    async GetCourseList() {
        return await api.get('/api/courses').then(async response => {
            return await response;
        });
    }
    async GetCourseById(id) {
        return await api.get('/api/course/' + id).then(async response => {
            return await response;
        });
    }
    async AddCourse(data) {
        return await api.post('/api/course', data).then(async response => {
            return await response;
        });
    }
    async UpdateCourse(id, data) {
        return await api.post('/api/course/' + id, data).then(async response => {
            return await response;
        });
    }
    async SetCourse(id, data) {
        return await api.put('/api/course/' + id, data).then(async response => {
            return await response;
        });
    }
}
export default new CourseService();
