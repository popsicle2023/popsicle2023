import api from "../api";

class FileService {
    async GetFile(filename) {
        return await api.get('/api/file/'+filename, {
            filename: filename
        }).then(async response => {
            return await response;
        });
    }

}
export default new FileService();
