import api from "../api";

class HelperService {
    async GetSchools() {
        return await api.get('/api/helper/schools').then(async response => {
            return await response;
        });
    }
    async GetDepartments() {
        return await api.get('/api/helper/departments').then(async response => {
            return await response;
        });
    }
    async GetCourses() {
        return await api.get('/api/helper/courses').then(async response => {
            return await response;
        });
    }
}
export default new HelperService();
