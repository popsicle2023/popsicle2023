import api from "../api";
import { toast } from "react-toastify";

class ExamService {
    async GetHomeWorksByCategoryId(id) {
        return await api.get('/api/homeworks?course.id=' + id).then(async response => {
            return await response;
        }).catch();
    }
    async AddNewHomeWork(data) {

        return await api.post('/api/homework', data).then(async response => {
            return await response;
        });
    }


}
export default new ExamService();
