import { configureStore } from "@reduxjs/toolkit";
import pageSettingsReducer from "./slices/course-list";
import headerReducer from "./slices/header";
import loginReducer from "./slices/login";
import shecudlerReducer from "./slices/shecudler";
import pagesReducer from "./slices/pages";
import helperReducer from "./slices/helper";
import selectedSubmissionReducer from "./slices/selected-submission";
import examReducer from "./slices/exams";
import myCustomApiService from "./utils/menuItems";


export const store = configureStore({
  reducer: {
    pageSettings: pageSettingsReducer,
    loginReducer: loginReducer,
    headerReducer: headerReducer,
    helperReducer: helperReducer,
    shecudlerReducer: shecudlerReducer,
    pagesReducer: pagesReducer,
    selectedSubmissionReducer:selectedSubmissionReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      thunk: {
        extraArgument: myCustomApiService,
      },
      serializableCheck: false,
    }),
});
