- [Kullanıcı Rolleri](#kullanıcı-rolleri)
- [Dummy Kullanıcı Bilgileri](#dummy-kullanıcı-bilgileri)
- [Web Servis Methodları](#web-servis-methodları)
  - [Response](#response)
      - [code](#code)
  - [GET /menu-tree](#get-menu-tree)
      - [Girdi](#girdi)
      - [Çıktı](#çıktı)
      - [Örnek 1](#örnek-1)
        - [Request](#request)
        - [Response](#response-1)
      - [Örnek 2](#örnek-2)
        - [Request](#request-1)
        - [Response](#response-2)
      - [Örnek 3](#örnek-3)
        - [Request](#request-2)
        - [Response](#response-3)
  - [POST /whoami](#post-whoami)
      - [Girdi](#girdi-1)
      - [Çıktı](#çıktı-1)
  - [POST /login](#post-login)
      - [Girdi](#girdi-2)
      - [Çıktı](#çıktı-2)
      - [Örnek 1](#örnek-1-1)
        - [Request](#request-3)
        - [Response](#response-4)
      - [Örnek 2](#örnek-2-1)
        - [Request](#request-4)
        - [Response](#response-5)
  - [POST /forgot](#post-forgot)
  - [POST /reset](#post-reset)
      - [Girdi](#girdi-3)
      - [Çıktı](#çıktı-3)
      - [Örnek](#örnek)
        - [Request](#request-5)
        - [Response](#response-6)
  - [GET /users](#get-users)
      - [Girdi](#girdi-4)
      - [Çıktı](#çıktı-4)
      - [Örnek 1](#örnek-1-2)
        - [Request](#request-6)
        - [Response](#response-7)
      - [Örnek 2](#örnek-2-2)
        - [Request](#request-7)
        - [Response](#response-8)
      - [Örnek 3](#örnek-3-1)
        - [Request](#request-8)
        - [Response](#response-9)
      - [Örnek 4](#örnek-4)
        - [Request](#request-9)
        - [Response](#response-10)
  - [GET /user/:id](#get-userid)
      - [Girdi](#girdi-5)
      - [Çıktı](#çıktı-5)
      - [Örnek](#örnek-1)
        - [Request (/user/63a3634d50f0fdade97e8d45)](#request-user63a3634d50f0fdade97e8d45)
        - [Response](#response-11)
  - [POST /user](#post-user)
      - [Girdi](#girdi-6)
      - [Çıktı](#çıktı-6)
      - [Örnek 1](#örnek-1-3)
        - [Request](#request-10)
        - [Response](#response-12)
      - [Örnek 2](#örnek-2-3)
        - [Request](#request-11)
        - [Response](#response-13)
  - [POST /user/:id](#post-userid)
      - [Girdi](#girdi-7)
      - [Çıktı](#çıktı-7)
      - [Örnek 1](#örnek-1-4)
        - [Request (/user/639e415e5880681729f0ac2b)](#request-user639e415e5880681729f0ac2b)
        - [Response](#response-14)
      - [Örnek 2](#örnek-2-4)
        - [Request (/user/639e415e5880681729f0ac2b)](#request-user639e415e5880681729f0ac2b-1)
        - [Response](#response-15)
  - [GET /students](#get-students)
      - [Girdi](#girdi-8)
      - [Çıktı](#çıktı-8)
      - [Örnek 1](#örnek-1-5)
        - [Request](#request-12)
        - [Response](#response-16)
      - [Örnek 2](#örnek-2-5)
        - [Request](#request-13)
        - [Response](#response-17)
  - [GET /student/:id](#get-studentid)
      - [Girdi](#girdi-9)
      - [Çıktı](#çıktı-9)
      - [Örnek](#örnek-2)
        - [Request (/user/63a3634d50f0fdade97e8d45)](#request-user63a3634d50f0fdade97e8d45-1)
        - [Response](#response-18)
  - [GET /teachers](#get-teachers)
      - [Girdi](#girdi-10)
      - [Çıktı](#çıktı-10)
      - [Örnek 1](#örnek-1-6)
        - [Request](#request-14)
        - [Response](#response-19)
      - [Örnek 2](#örnek-2-6)
        - [Request](#request-15)
        - [Response](#response-20)
  - [GET /teacher/:id](#get-teacherid)
      - [Girdi](#girdi-11)
      - [Çıktı](#çıktı-11)
      - [Örnek](#örnek-3)
        - [Request (/user/63a3634d50f0fdade97e8d45)](#request-user63a3634d50f0fdade97e8d45-2)
        - [Response](#response-21)
  - [GET /courses](#get-courses)
      - [Girdi](#girdi-12)
      - [Çıktı](#çıktı-12)
      - [Örnek](#örnek-4)
        - [Request](#request-16)
        - [Response](#response-22)
  - [GET /course/:id](#get-courseid)
      - [Girdi](#girdi-13)
      - [Çıktı](#çıktı-13)
      - [Örnek](#örnek-5)
        - [Request (/course/639f1add84cf308199dc3736)](#request-course639f1add84cf308199dc3736)
        - [Response](#response-23)
  - [POST /course](#post-course)
      - [Girdi](#girdi-14)
      - [Çıktı](#çıktı-14)
      - [Örnek 1](#örnek-1-7)
        - [Request](#request-17)
        - [Response](#response-24)
      - [Örnek 2](#örnek-2-7)
        - [Request](#request-18)
        - [Response](#response-25)
      - [Örnek 3](#örnek-3-2)
        - [Request](#request-19)
        - [Response](#response-26)
  - [POST,PUT /course/:id](#postput-courseid)
      - [Girdi](#girdi-15)
      - [Çıktı](#çıktı-15)
      - [Örnek 1](#örnek-1-8)
        - [Request (/course/639f1add84cf308199dc3736)](#request-course639f1add84cf308199dc3736-1)
        - [Response](#response-27)
      - [Örnek 2](#örnek-2-8)
        - [Request (/course/639f1add84cf308199dc3736)](#request-course639f1add84cf308199dc3736-2)
        - [Response](#response-28)
      - [Örnek 3](#örnek-3-3)
        - [Request (/course/63a37398b54d184ab996fabb)](#request-course63a37398b54d184ab996fabb)
        - [Response](#response-29)
  - [POST,PUT /course-assign](#postput-course-assign)
      - [Girdi](#girdi-16)
      - [Çıktı](#çıktı-16)
  - [POST,PUT /course-uploads](#postput-course-uploads)
      - [Girdi](#girdi-17)
      - [Çıktı](#çıktı-17)
  - [PUT /course-uploads/:id](#put-course-uploadsid)
      - [Girdi](#girdi-18)
      - [Çıktı](#çıktı-18)
  - [GET /exams](#get-exams)
      - [Girdi](#girdi-19)
      - [Çıktı](#çıktı-19)
  - [GET /exam/:id](#get-examid)
      - [Girdi](#girdi-20)
      - [Çıktı](#çıktı-20)
  - [POST /exam](#post-exam)
      - [Girdi](#girdi-21)
      - [Çıktı](#çıktı-21)
  - [POST,PUT /exam/:id](#postput-examid)
      - [Girdi](#girdi-22)
      - [Çıktı](#çıktı-22)
  - [GET /homeworks](#get-homeworks)
      - [Girdi](#girdi-23)
      - [Çıktı](#çıktı-23)
  - [GET /homework/:id](#get-homeworkid)
      - [Girdi](#girdi-24)
      - [Çıktı](#çıktı-24)
  - [POST /homework](#post-homework)
      - [Girdi](#girdi-25)
      - [Çıktı](#çıktı-25)
  - [POST,PUT /homework/:id](#postput-homeworkid)
      - [Girdi](#girdi-26)
      - [Çıktı](#çıktı-26)
  - [GET /quizzes](#get-quizzes)
      - [Girdi](#girdi-27)
      - [Çıktı](#çıktı-27)
  - [GET /quiz/:id](#get-quizid)
      - [Girdi](#girdi-28)
      - [Çıktı](#çıktı-28)
  - [POST /quiz](#post-quiz)
      - [Girdi](#girdi-29)
      - [Çıktı](#çıktı-29)
  - [POST,PUT /quiz/:id](#postput-quizid)
      - [Girdi](#girdi-30)
      - [Çıktı](#çıktı-30)
  - [GET /examines](#get-examines)
      - [Girdi](#girdi-31)
      - [Çıktı](#çıktı-31)
  - [GET /examine/:id](#get-examineid)
      - [Girdi](#girdi-32)
      - [Çıktı](#çıktı-32)
  - [POST /examine](#post-examine)
      - [Girdi](#girdi-33)
      - [Çıktı](#çıktı-33)
  - [POST,PUT /examine/:id](#postput-examineid)
      - [Girdi](#girdi-34)
      - [Çıktı](#çıktı-34)
  - [GET /submissions](#get-submissions)
      - [Girdi](#girdi-35)
      - [Çıktı](#çıktı-35)
  - [GET /submission/:id](#get-submissionid)
      - [Girdi](#girdi-36)
      - [Çıktı](#çıktı-36)
  - [POST /submission](#post-submission)
      - [Girdi](#girdi-37)
      - [Çıktı](#çıktı-37)
  - [PUT /submission/:id](#put-submissionid)
      - [Girdi](#girdi-38)
      - [Çıktı](#çıktı-38)
  - [POST /submission-answer/:id](#post-submission-answerid)
      - [Girdi](#girdi-39)
      - [Çıktı](#çıktı-39)
  - [POST /submission-evaluate](#post-submission-evaluate)
      - [Girdi](#girdi-40)
      - [Çıktı](#çıktı-40)
  - [GET /schedules](#get-schedules)
      - [Girdi](#girdi-41)
      - [Çıktı](#çıktı-41)
      - [Örnek](#örnek-6)
        - [Request](#request-20)
        - [Response](#response-30)
  - [GET /grades](#get-grades)
      - [Girdi](#girdi-42)
      - [Çıktı](#çıktı-42)
  - [GET /grade-submissions/:id](#get-grade-submissionsid)
      - [Girdi](#girdi-43)
      - [Çıktı](#çıktı-43)
  - [GET /manage-submissions/:id](#get-manage-submissionsid)
      - [Girdi](#girdi-44)
      - [Çıktı](#çıktı-44)
  - [GET /grade-review/:id](#get-grade-reviewid)
      - [Girdi](#girdi-45)
      - [Çıktı](#çıktı-45)
  - [GET /grades-established/:courseId](#get-grades-establishedcourseid)
      - [Girdi](#girdi-46)
      - [Çıktı](#çıktı-46)
  - [GET /grades-stats/:courseId](#get-grades-statscourseid)
      - [Girdi](#girdi-47)
      - [Çıktı](#çıktı-47)
- [Helper Methodları](#helper-methodları)
  - [GET /helper/schools](#get-helperschools)
      - [Girdi](#girdi-48)
      - [Çıktı](#çıktı-48)
      - [Örnek 1](#örnek-1-9)
        - [Request](#request-21)
        - [Response](#response-31)
      - [Örnek 2](#örnek-2-9)
        - [Request](#request-22)
        - [Response](#response-32)
      - [Örnek 3](#örnek-3-4)
        - [Request](#request-23)
        - [Response](#response-33)
  - [GET /helper/departments](#get-helperdepartments)
      - [Girdi](#girdi-49)
      - [Çıktı](#çıktı-49)
      - [Örnek 1](#örnek-1-10)
        - [Request](#request-24)
        - [Response](#response-34)
      - [Örnek 2](#örnek-2-10)
        - [Request](#request-25)
        - [Response](#response-35)
      - [Örnek 3](#örnek-3-5)
        - [Request](#request-26)
        - [Response](#response-36)
  - [GET /helper/courses](#get-helpercourses)
      - [Girdi](#girdi-50)
      - [Çıktı](#çıktı-50)
      - [Örnek 1](#örnek-1-11)
        - [Request](#request-27)
        - [Response](#response-37)
      - [Örnek 2](#örnek-2-11)
        - [Request](#request-28)
        - [Response](#response-38)
      - [Örnek 3](#örnek-3-6)
        - [Request](#request-29)
        - [Response](#response-39)
  - [GET /helper/students](#get-helperstudents)
      - [Girdi](#girdi-51)
      - [Çıktı](#çıktı-51)
      - [Örnek 1](#örnek-1-12)
        - [Request](#request-30)
        - [Response](#response-40)
      - [Örnek 2](#örnek-2-12)
        - [Request](#request-31)
        - [Response](#response-41)
      - [Örnek 3](#örnek-3-7)
        - [Request](#request-32)
        - [Response](#response-42)
  - [GET /helper/teachers](#get-helperteachers)
      - [Girdi](#girdi-52)
      - [Çıktı](#çıktı-52)
      - [Örnek 1](#örnek-1-13)
        - [Request](#request-33)
        - [Response](#response-43)
      - [Örnek 2](#örnek-2-13)
        - [Request](#request-34)
        - [Response](#response-44)
      - [Örnek 3](#örnek-3-8)
        - [Request](#request-35)
        - [Response](#response-45)
  - [GET /helper/grades](#get-helpergrades)
      - [Girdi](#girdi-53)
      - [Çıktı](#çıktı-53)
      - [Örnek 1](#örnek-1-14)
        - [Request](#request-36)
        - [Response](#response-46)
      - [Örnek 2](#örnek-2-14)
        - [Request](#request-37)
        - [Response](#response-47)
      - [Örnek 3](#örnek-3-9)
        - [Request](#request-38)
        - [Response](#response-48)
  - [GET /helper/homeworks](#get-helperhomeworks)
      - [Girdi](#girdi-54)
      - [Çıktı](#çıktı-54)
      - [Örnek 1](#örnek-1-15)
        - [Request](#request-39)
        - [Response](#response-49)
      - [Örnek 2](#örnek-2-15)
        - [Request](#request-40)
        - [Response](#response-50)
      - [Örnek 3](#örnek-3-10)
        - [Request](#request-41)
        - [Response](#response-51)
- [Dosya Methodları](#dosya-methodları)
  - [GET /file/:filename](#get-filefilename)
      - [Girdi](#girdi-55)
      - [Çıktı](#çıktı-55)
      - [Örnek](#örnek-7)
        - [Request (/file/Courses-videos-9bc24e510dd5a6250)](#request-filecourses-videos-9bc24e510dd5a6250)
        - [Response (FILE)](#response-file)


# Kullanıcı Rolleri

|   Değer   |                    Tanım                     |
| :-------: | :------------------------------------------: |
| superUser | En üst seviye yetki ve herşeye erişim hakkı. |
|   admin   |  Kullanıcı yönetimi ve geniş erişim hakkı.   |
|  student  |            Öğrenci erişim hakkı.             |
|  teacher  |            Öğretmen erişim hakkı.            |
|  forgot   |           Parola sıfırlama hakkı.            |
| anonymous |     Kısıtlamasız ekranlara erişim hakkı.     |

# Web Servis Methodları

RESTFul mimarisi ile geliştirilmiştir. JSON veri tibi ile iletişim sağlanır. Web servislerin bazıları yetki bazlı kısıtlamalıdır.
Web servislerini yetkili kullanabilmek için 2 alternatif vardır.

Bunlardan biri tarayıcı/client üzerinde **login** işlemini gerçekleştirmek.
Login işlemi gerçekleştirildiğinde ``token`` bilgisi **cookies**'e yazılır. Web servislerde kullanıcı/oturum bilgileri cookies'den okunur.

Bir diğer alternatif ise ``Bearer`` token olarak login servisinden dönen **token** değerini kullanmaktır. ("authorization": "Bearer ...")

``POST`` ve ``PUT`` metodlarında **content-type** türü ``application/json`` veya ``multipart/form-data`` olabilir. ("content-type": "application/json", "content-type": "multipart/form-data; boundary=<calculated when request is sent>")
``GET`` metodlarında veri **query** olarak iletilir. (URL?param1=value1&param2=value2...)

Örnek postman koleksiyonuna [Paper-X_API.postman_collection.json](Paper-X_API.postman_collection.json) dosyasından ulaşabilirsiniz.

## Response

Response objesinin dış iskeleti tüm methodlarda aynıdır. Methodlarda farklılık gösteren tek alan ``result`` alanıdır.
Her methodun altında kendi **result** değerleri belirtilmiştir.

| Parametre |   Tip   |                            Açıklama                             |       Örnek       |
| :-------: | :-----: | :-------------------------------------------------------------: | :---------------: |
|   code    | number  | Başarı durumunu ifade eder. Enum değerler alır. (code tablosu). |         0         |
|  message  | string  |                         Mesaj metnidir.                         | "İşlem başarılı." |
|  isShow   | boolean |         Son kullanıcıya gösterilme durumunu ifade eder.         |       true        |
|  result   | object  |                Method özelinde sonuç objesidir.                 |        {}         |

#### code

| Değer |       Tanım        |
| :---: | :----------------: |
|   0   |     Başarılı.      |
|   1   | Validasyon Hatası. |
|   2   |   Sistem Hatası.   |
|   3   |  Veri Bulunamadı.  |
|   4   |   Yetki Hatası.    |

## GET /menu-tree

![alt](./materials/img/menu.png)

Navigasyon ağacının derinlik seviyesine göre recursive olarak döner.

Eğer sadece navigasyon menüsündeki ilk basamadaki elemanların getirilmesi istenirse **level** parametresi boş bırakılır veya **1** değeri ile doldurulur. İlk basamaktan sonraki yani bir elemanın alt elemanı(ları) da gelsin istenirse o zaman da inilecek derinliğe göre (2, 3, 4 vb.) level parametresi doldurulur.

``level``değeri **-1** verilirse navigasyon elemanlarının tümü hiyerarşik olarak döner.

Üst elemanın sahip olduğu alt elemanların (child) getirilmesi istenirse **parent** parametresi, üst navigasyon elemanına (parent) ait ``id`` bilgisi ile doldurulur.

#### Girdi

| Parametre  |  Tip   | Zorunluluk | Varsayılan |                                             Açıklama                                              |           Örnek            |
| :--------: | :----: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :------------------------: |
|   level    | number |   Hayır    |     1      |                             Navigasyon ağacının derinlik seviyesidir.                             |             1              |
|   parent   | string |   Hayır    |            |                        Alt elemanı bulunan navigasyon elemanının idsidir.                         | "639e3719c6c9d24344357ec8" |
|    name    | string |   Hayır    |            |                        Navigasyon elemanın ismidir. Regex araması yapılır.                        |        "Ana Sayfa"         |
|   _limit   | number |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |             50             |
|   _skip    | number |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |             20             |
|  _sortBy   | string |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |         "username"         |
| _sortValue | number |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |             -1             |
|  _project  | string |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |  "name,startDate,endDate"  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|   Parametre    |      Tip      |                        Açıklama                         |           Örnek            |
| :------------: | :-----------: | :-----------------------------------------------------: | :------------------------: |
|      data      |     array     |                 Navigasyon elemanları.                  |        [{...},...]         |
|    data.id     |    string     |                 Navigasyon eleman idsi.                 | "639e3719c6c9d24344357ec8" |
|  data.parent   |    string     |   Alt navigasyon elemanının bağlı olduğu üst eleman.    | "639e3e4e5880681729ef8b5d" |
|   data.name    |    string     |                 Navigasyon eleman ismi.                 |          "Item 1"          |
| data.iconClass |    string     |           Navigasyon eleman ikon class ismi.            |        "fa fa-xxx"         |
|   data.href    |    string     |       Navigasyon elemanın bağlantı adres bilgisi.       |          "/home"           |
|  data.childs   | array\<data\> | Alt navigasyon elemanları. Şeması ``data`` ile aynıdır. |         [\<data\>]         |

#### Örnek 1

##### Request
```json
{}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "id": "639e3e4e5880681729ef8b5d",
                "parent": "",
                "name": "Item 4",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": []
            },
            {
                "id": "639e3e4e5880681729ef8b5f",
                "parent": "",
                "name": "Item 1",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": []
            }
        ]
    }
}
```

#### Örnek 2

##### Request
```json
{
    "parent": "639e3e4e5880681729ef8b5f"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "id": "639e3e4e5880681729ef8b66",
                "parent": "639e3e4e5880681729ef8b5f",
                "name": "Item 6",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": []
            },
            {
                "id": "639e3e4e5880681729ef8b6a",
                "parent": "639e3e4e5880681729ef8b5f",
                "name": "Item 5",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": []
            }
        ]
    }
}
```

#### Örnek 3

##### Request
```json
{
    "level": -1
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "id": "639e3e4e5880681729ef8b5d",
                "parent": "",
                "name": "Item 4",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": [
                    {
                        "id": "639e3e4e5880681729ef8b68",
                        "parent": "639e3e4e5880681729ef8b5d",
                        "name": "Item 3",
                        "iconClass": "fa fa-xxx",
                        "href": "#",
                        "childs": [
                            {
                                "id": "639e3e4e5880681729ef8b63",
                                "parent": "639e3e4e5880681729ef8b68",
                                "name": "Item 2",
                                "iconClass": "fa fa-xxx",
                                "href": "#",
                                "childs": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "639e3e4e5880681729ef8b5f",
                "parent": "",
                "name": "Item 1",
                "iconClass": "fa fa-xxx",
                "href": "#",
                "childs": [
                    {
                        "id": "639e3e4e5880681729ef8b6a",
                        "parent": "639e3e4e5880681729ef8b5f",
                        "name": "Item 5",
                        "iconClass": "fa fa-xxx",
                        "href": "#",
                        "childs": []
                    },
                    {
                        "id": "639e3e4e5880681729ef8b66",
                        "parent": "639e3e4e5880681729ef8b5f",
                        "name": "Item 6",
                        "iconClass": "fa fa-xxx",
                        "href": "#",
                        "childs": []
                    }
                ]
            }
        ]
    }
}
```

## POST /whoami

![alt](./materials/img/whoami.png)

Oturum bilgilerini döner. Kullanıcı giriş yapmamışsa (login) bilgiler "anonymous" olarak döner. Herhangi bir girdisi yoktur.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|  Parametre  |       Tip       |          Açıklama          |          Örnek          |
| :---------: | :-------------: | :------------------------: | :---------------------: |
|  username   |     string      |       Kullanıcı adı.       |       "superUser"       |
| displayName |     string      | Görünen adı, isim soyisim. | "Üst Yetkili Kullanıcı" |
|    email    |     string      |       Eposta adresi.       | "superUser@paper-x.com" |
|    roles    | array\<string\> |    Sahip olduğu roller.    |      ["superUser"]      |
|     ip      |     string      |         Ip adresi.         |       "127.0.0.1"       |

## POST /login

![alt](./materials/img/login.png)

1 günlük token üretir. Eğer **rememberMe** parametresi ``true`` gönderilirse 1 haftalık token üretilir.
Üretilen token'ı cookies'e kaydeder.

#### Girdi

|  Parametre   |   Tip   | Zorunluluk | Varsayılan |             Açıklama              |      Örnek       |                   Resim                    |
| :----------: | :-----: | :--------: | :--------: | :-------------------------------: | :--------------: | :----------------------------------------: |
| unameOrEmail | string  |    Evet    |            | Kullanıcı adı veya eposta adresi. |   "superUser"    |  ![alt](./materials/img/login_email.png)   |
|   password   | string  |    Evet    |            |              Parola.              | "1q2w3e4r5t6y7u" |   ![alt](./materials/img/login_pass.png)   |
|  rememberMe  | boolean |   Hayır    |   false    |        Beni hatırla alanı.        |       true       | ![alt](./materials/img/login_remember.png) |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|       Parametre       |   Tip   |                              Açıklama                              |                    Örnek                     |
| :-------------------: | :-----: | :----------------------------------------------------------------: | :------------------------------------------: |
|         token         | string  |                JWT kütüphanesi ile üretilmiş token                 | "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImt..." |
| requirePasswordChange | boolean | Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir |                    false                     |

#### Örnek 1
##### Request
```json
{
    "unameOrEmail": "superUser",
    "password": "1q2w3e4r5t6y7u"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6Ik..."
    }
}
```
```json
{
    "responseCookies": {
        "token": {
            "Path": "/",
            "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6I..."
        }
    }
}
```

#### Örnek 2
##### Request
```json
{
    "unameOrEmail": "superUser",
    "password": "1q2w3e4r5t6y7u",
    "rememberMe": true
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6Ik..."
    }
}
```
```json
{
    "responseCookies": {
        "token": {
            "Path": "/",
            "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6I..."
        }
    }
}
```

## POST /forgot

TODO: Mail SMTP sunucu ayarları yapıldığında o ayarlar kullanılarak oluşturulacaktır.

## POST /reset

Parolamı unuttum ile tetiklenen (forgot) ve özel bir link ile açıldıktan sonra çağrılan parola oluşturma/sıfırlama web servisidir.
Bu web servisi sadece **forgot** rolüne sahip hesaplar kullanabilir. Bu rol sadece bu web servis için kullanılmaktadır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan | Açıklama |      Örnek       |
| :-------: | :----: | :--------: | :--------: | :------: | :--------------: |
| password  | string |    Evet    |            | Parola.  | "1q2w3e4r5t6y7u" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }}) Herhangi bir çıktı vermemektedir.
Başarı durumu **code** değerinden anlaşılabilir.

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

#### Örnek
##### Request
```json
{
    "password": "q1w2e3r4t5y6u7"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

## GET /users

![alt](./materials/img/roster.png)

Kullanıcı listesini döner. Sadece "admin" ve "superUser" rollerine açıktır.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                                             Açıklama                                              |           Örnek            |
| :-------------------: | :------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :------------------------: |
|          _id          |     string\<objectId\>     |   Hayır    |            |                                            Id bilgisi.                                            | "63a3634d50f0fdade97e8d41" |
|       username        |           string           |   Hayır    |            |                                          Kullanıcı adı.                                           |        "superUser"         |
|      displayName      |           string           |   Hayır    |            |                                Görünen adı, isim soyisim. (Regex).                                |  "Üst Yetkili Kullanıcı"   |
|         email         |           string           |   Hayır    |            |                                          Eposta adresi.                                           |  "superUser@paper-x.com"   |
|         roles         |           string           |   Hayır    |            |                                       Sahip olduğu roller.                                        |        "superUser"         |
|        passive        |          boolean           |   Hayır    |            |                                         Pasiflik durumu.                                          |           false            |
|      department       |           string           |   Hayır    |            |                                        Departman bilgisi.                                         |   "Chemical Engineering"   |
|        office         |           string           |   Hayır    |            |                                           Ofis bilgisi.                                           |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |   Hayır    |            |                                    Ofis günü.(hafanın günleri)                                    |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |   Hayır    |            |                                        Ofis başlama saati.                                        |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |   Hayır    |            |                                         Ofis bitiş saati.                                         |          "15:00"           |
|       zoomLink        |       string\<url\>        |   Hayır    |            |                                            Zoom linki.                                            |        zoom.com/123        |
|      courseIdNe       |           string           |   Hayır    |            |                            Kurs id'sine eşit olmayan. Kursa atanmamış.                            | "63a3634d50f0fdade97e8d41" |
|      courseIdEq       |           string           |   Hayır    |            |                              Kurs id'sine eşit olan. Kursa atanmış.                               | "63a3634d50f0fdade97e8d41" |
|       courseId        |           string           |   Hayır    |            |             Kurs id'sine eşit olanların assign değeri true, olmayanların false döner.             | "63a3634d50f0fdade97e8d41" |
| requirePasswordChange |          boolean           |   Hayır    |            |                Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir                 |           false            |
|     sendInfoMail      |          boolean           |   Hayır    |            |               Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir               |           false            |
|        _limit         |           number           |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |             50             |
|         _skip         |           number           |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |             20             |
|        _sortBy        |           string           |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |         "username"         |
|      _sortValue       |           number           |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |             -1             |
|       _project        |           string           |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |  "name,startDate,endDate"  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|         Parametre          |            Tip             |                                 Açıklama                                 |           Örnek            |
| :------------------------: | :------------------------: | :----------------------------------------------------------------------: | :------------------------: |
|            data            |           array            |                              Kullanıcılar.                               |        [{...},...]         |
|          data._id          |           string           |                                   Id.                                    | "639e415e5880681729f0ac10" |
|       data.username        |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|         data.email         |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|         data.roles         |      array\<string\>       |                           Sahip olduğu roller.                           |       ["superUser"]        |
|      data.department       |           string           |                            Departman bilgisi.                            |   "Chemical Engineering"   |
|        data.office         |           string           |                              Ofis bilgisi.                               |  "Lorem Ipsum Hall, 512"   |
|       data.officeDay       | number\<-1,0,1,2,3,4,5,6\> |                       Ofis günü.(hafanın günleri)                        |             3              |
|   data.officeStartHours    |   string\<time\|ss:dd\>    |                           Ofis başlama saati.                            |          "14:00"           |
|    data.officeEndHours     |   string\<time\|ss:dd\>    |                            Ofis bitiş saati.                             |          "15:00"           |
|       data.zoomLink        |       string\<url\>        |                               Zoom linki.                                |        zoom.com/123        |
|       data.assigned        |       string\<url\>        | **courseId** parametresi ile sorulduğunda o kursa atanma durumunu döner. |            true            |
| data.requirePasswordChange |          boolean           |    Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir    |           false            |
|     data.sendInfoMail      |          boolean           |  Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir   |           false            |
|         data.stamp         |           object           |                            Son işlem bilgisi.                            |           {...}            |
|    data.stamp.createAt     |       string\<ISO\>        |                            Son işlem bilgisi.                            | "2022-12-17T22:23:25.978Z" |
|    data.stamp.username     |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|      data.stamp.email      |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|   data.stamp.displayName   |           string           |                        Görünen adı, isim soyisim.                        |  "Üst Yetkili Kullanıcı"   |
|       data.stamp.ip        |           string           |                                Ip adresi.                                |        "127.0.0.1"         |

#### Örnek 1
##### Request
```json
{}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d41",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "superUser",
                "displayName": "Üst Yetkili Kullanıcı",
                "email": "superUser@paper-x.com",
                "roles": [
                    "superUser"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.759Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d42",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "teacher",
                "displayName": "Öğretmen Kullanıcı",
                "email": "teacher@paper-x.com",
                "roles": [
                    "teacher"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.761Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d43",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "forgot",
                "displayName": "Unutkan Öğrenci Kullanıcı",
                "email": "forgot@paper-x.com",
                "roles": [
                    "forgot"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d44",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "admin",
                "displayName": "Yetkili Kullanıcı",
                "email": "admin@paper-x.com",
                "roles": [
                    "admin"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d45",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "student",
                "displayName": "Öğrenci Kullanıcı",
                "email": "student@paper-x.com",
                "roles": [
                    "student"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "username": "admin"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d44",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "admin",
                "displayName": "Yetkili Kullanıcı",
                "email": "admin@paper-x.com",
                "roles": [
                    "admin"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "roles": [
        "admin",
        "student"
    ]
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d44",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "admin",
                "displayName": "Yetkili Kullanıcı",
                "email": "admin@paper-x.com",
                "roles": [
                    "admin"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d45",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "student",
                "displayName": "Öğrenci Kullanıcı",
                "email": "student@paper-x.com",
                "roles": [
                    "student"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            }
        ]
    }
}
```

#### Örnek 4
##### Request
```json
{
    "_id": [
        "63a3634d50f0fdade97e8d41",
        "63a3634d50f0fdade97e8d43",
        "63a3634d50f0fdade97e8d45"
    ]
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d41",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "superUser",
                "displayName": "Üst Yetkili Kullanıcı",
                "email": "superUser@paper-x.com",
                "roles": [
                    "superUser"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.759Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d43",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "forgot",
                "displayName": "Unutkan Öğrenci Kullanıcı",
                "email": "forgot@paper-x.com",
                "roles": [
                    "forgot"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
            {
                "_id": "63a3634d50f0fdade97e8d45",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "student",
                "displayName": "Öğrenci Kullanıcı",
                "email": "student@paper-x.com",
                "roles": [
                    "student"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            }
        ]
    }
}
```

## GET /user/:id

Id bilgisi ile belirtilen bir kullanıcının bilgilerini getiririr.
Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.
Parola değişiklik zorunluluğu olan kullanıcıların da kullanımına açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|       Parametre       |            Tip             |                               Açıklama                                |           Örnek            |
| :-------------------: | :------------------------: | :-------------------------------------------------------------------: | :------------------------: |
|          _id          |           string           |                                  Id.                                  | "639e415e5880681729f0ac2b" |
|       username        |           string           |                            Kullanıcı adı.                             |          "admin"           |
|         email         |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|         roles         |      array\<string\>       |                         Sahip olduğu roller.                          |         ["admin"]          |
|      department       |           string           |                          Departman bilgisi.                           |   "Chemical Engineering"   |
|        office         |           string           |                             Ofis bilgisi.                             |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |                      Ofis günü.(hafanın günleri)                      |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |                          Ofis başlama saati.                          |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |                           Ofis bitiş saati.                           |          "15:00"           |
|       zoomLink        |       string\<url\>        |                              Zoom linki.                              |        zoom.com/123        |
| requirePasswordChange |          boolean           |  Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir   |           false            |
|     sendInfoMail      |          boolean           | Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir |           false            |
|         stamp         |           object           |                          Son işlem bilgisi.                           |           {...}            |
|    stamp.createAt     |       string\<ISO\>        |                          Son işlem bilgisi.                           | "2022-12-17T22:23:25.978Z" |
|    stamp.username     |           string           |                            Kullanıcı adı.                             |          "admin"           |
|      stamp.email      |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|   stamp.displayName   |           string           |                      Görünen adı, isim soyisim.                       |    "Yetkili Kullanıcı"     |
|       stamp.ip        |           string           |                              Ip adresi.                               |        "127.0.0.1"         |

#### Örnek
##### Request (/user/63a3634d50f0fdade97e8d45)
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "_id": "63a3634d50f0fdade97e8d45",
        "passive": false,
        "department": "",
        "office": "",
        "officeDay": -1,
        "officeStartHours": "",
        "officeEndHours": "",
        "zoomLink": "",
        "username": "student",
        "displayName": "Öğrenci Kullanıcı",
        "email": "student@paper-x.com",
        "roles": [
            "student"
        ],
        "stamp": {
            "createAt": "2022-12-21T19:49:33.762Z",
            "username": "superUser",
            "email": "superUser@paper-x.com",
            "displayName": "Üst Yetkili Kullanıcı",
            "ip": "127.0.0.1"
        }
    }
}
```

## POST /user

Kullanıcı girişi/kaydı için kullanılır. Girilen değerlere göre yeni bir kullanıcı tanımlanır. Kullanıcı adı tekil alandır.
Var olan bir kullanıcı adı ile giriş yapıldığında hata verecektir. Sadece "admin" ve "superUser" rollerine açıktır.
"officeDay" alanındaki -1 yok anlamına gelmektedir. Diğer değerler pazar(0) gününden başlayarak cumartesi(6) gününe kadar sırasıyla giden değerlerdir.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                               Açıklama                                |             Örnek              |
| :-------------------: | :------------------------: | :--------: | :--------: | :-------------------------------------------------------------------: | :----------------------------: |
|       username        |           string           |    Evet    |            |                            Kullanıcı adı.                             |           "teacher2"           |
|      displayName      |           string           |    Evet    |            |                      Görünen adı, isim soyisim.                       | "Üretilmiş Öğrenmen Kullanıcı" |
|         email         |           string           |    Evet    |            |                            Eposta adresi.                             |     "teacher2@paper-x.com"     |
|         roles         |      array\<string\>       |    Evet    |            |                         Sahip olduğu roller.                          |          ["teacher"]           |
|      department       |           string           |   Hayır    |     ""     |                          Departman bilgisi.                           |     "Chemical Engineering"     |
|        office         |           string           |   Hayır    |     ""     |                             Ofis bilgisi.                             |    "Lorem Ipsum Hall, 512"     |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |   Hayır    |     -1     |                      Ofis günü.(hafanın günleri)                      |               3                |
|   officeStartHours    |   string\<time\|ss:dd\>    |   Hayır    |     ""     |                          Ofis başlama saati.                          |            "14:00"             |
|    officeEndHours     |   string\<time\|ss:dd\>    |   Hayır    |     ""     |                           Ofis bitiş saati.                           |            "15:00"             |
|       zoomLink        |       string\<url\>        |   Hayır    |     ""     |                              Zoom linki.                              |          zoom.com/123          |
| requirePasswordChange |          boolean           |   Hayır    |   false    |  Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir   |             false              |
|     sendInfoMail      |          boolean           |   Hayır    |   false    | Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir |             false              |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }}) Herhangi bir çıktı vermez.
Başarı durumunu **code** değerinden takip edebilirsiniz.

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

#### Örnek 1
##### Request
```json
{
    "username": "teacher2",
    "password": "1q2w3e4r5t6y7u",
    "email": "teacher2@paper-x.com",
    "displayName": "Üretilmiş Öğrenmen Kullanıcı",
    "roles": [
        "teacher"
    ]
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

#### Örnek 2
##### Request
```json
{
    "username": "teacher2",
    "password": "1q2w3e4r5t6y7u",
    "email": "teacher2@paper-x.com",
    "displayName": "Üretilmiş Öğrenmen Kullanıcı",
    "roles": [
        "teacher"
    ]
}
```

##### Response
```json
{
    "code": 1,
    "message": "Bu kullanıcı adı kullanılmaktadır.",
    "isShowMessage": true,
    "result": {}
}
```

## POST /user/:id

![alt](./materials/img/edit_tas.png)

Id bilgisi ile var olan bir kullanıcının bilgilerini güncellemek için kullanılır.
Kullanıcılar silinemez sadece pasife çekilebilir.
Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.
Parola değişiklik zorunluluğu olan kullanıcıların da kullanımına açıktır.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                               Açıklama                                |             Örnek              |                    Resim                    |
| :-------------------: | :------------------------: | :--------: | :--------: | :-------------------------------------------------------------------: | :----------------------------: | :-----------------------------------------: |
|       password        |           string           |   Hayır    |            |                          Kullanıcı parolası.                          |        "1q2w3e4r5t6y7u"        |                                             |
|      displayName      |           string           |   Hayır    |            |                      Görünen adı, isim soyisim.                       | "Üretilmiş Öğrenmen Kullanıcı" |                                             |
|         email         |           string           |   Hayır    |            |                            Eposta adresi.                             |         "bar@foo.baz"          |    ![alt](./materials/img/tas_email.png)    |
|         roles         |      array\<string\>       |   Hayır    |            |                         Sahip olduğu roller.                          |          ["teacher"]           |                                             |
|        passive        |          boolean           |   Hayır    |            |                           Pasiflik durumu.                            |              true              |                                             |
|      department       |           string           |   Hayır    |            |                          Departman bilgisi.                           |     "Chemical Engineering"     | ![alt](./materials/img/tas_department.png)  |
|        office         |           string           |   Hayır    |            |                             Ofis bilgisi.                             |    "Lorem Ipsum Hall, 512"     |   ![alt](./materials/img/tas_office.png)    |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |   Hayır    |            |                      Ofis günü.(hafanın günleri)                      |               3                | ![alt](./materials/img/tas_office_time.png) |
|   officeStartHours    |   string\<time\|ss:dd\>    |   Hayır    |            |                          Ofis başlama saati.                          |            "14:00"             | ![alt](./materials/img/tas_office_time.png) |
|    officeEndHours     |   string\<time\|ss:dd\>    |   Hayır    |            |                           Ofis bitiş saati.                           |            "15:00"             | ![alt](./materials/img/tas_office_time.png) |
|       zoomLink        |       string\<url\>        |   Hayır    |            |                              Zoom linki.                              |          zoom.com/123          |  ![alt](./materials/img/tas_zoomlink.png)   |
| requirePasswordChange |          boolean           |   Hayır    |            |  Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir   |             false              |                                             |
|     sendInfoMail      |          boolean           |   Hayır    |            | Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir |             false              |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

#### Örnek 1
##### Request (/user/639e415e5880681729f0ac2b)
```json
{
    "password": "1q2w3e4r5t6y7u"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

#### Örnek 2
##### Request (/user/639e415e5880681729f0ac2b)
```json
{
    "passive": true
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

## GET /students

![alt](./materials/img/tas.png)

Öğrenci listesini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                                             Açıklama                                              |           Örnek            |
| :-------------------: | :------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :------------------------: |
|          _id          |     string\<objectId\>     |   Hayır    |            |                                            Id bilgisi.                                            | "63a3634d50f0fdade97e8d41" |
|       username        |           string           |   Hayır    |            |                                          Kullanıcı adı.                                           |        "superUser"         |
|      displayName      |           string           |   Hayır    |            |                                Görünen adı, isim soyisim. (Regex).                                |  "Üst Yetkili Kullanıcı"   |
|         email         |           string           |   Hayır    |            |                                          Eposta adresi.                                           |  "superUser@paper-x.com"   |
|        passive        |          boolean           |   Hayır    |            |                                         Pasiflik durumu.                                          |           false            |
|      department       |           string           |   Hayır    |            |                                        Departman bilgisi.                                         |   "Chemical Engineering"   |
|        office         |           string           |   Hayır    |            |                                           Ofis bilgisi.                                           |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |   Hayır    |            |                                    Ofis günü.(hafanın günleri)                                    |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |   Hayır    |            |                                        Ofis başlama saati.                                        |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |   Hayır    |            |                                         Ofis bitiş saati.                                         |          "15:00"           |
|       zoomLink        |       string\<url\>        |   Hayır    |            |                                            Zoom linki.                                            |        zoom.com/123        |
|      courseIdNe       |           string           |   Hayır    |            |                            Kurs id'sine eşit olmayan. Kursa atanmamış.                            | "63a3634d50f0fdade97e8d41" |
|      courseIdEq       |           string           |   Hayır    |            |                              Kurs id'sine eşit olan. Kursa atanmış.                               | "63a3634d50f0fdade97e8d41" |
|       courseId        |           string           |   Hayır    |            |             Kurs id'sine eşit olanların assign değeri true, olmayanların false döner.             | "63a3634d50f0fdade97e8d41" |
| requirePasswordChange |          boolean           |   Hayır    |            |                Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir                 |           false            |
|     sendInfoMail      |          boolean           |   Hayır    |            |               Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir               |           false            |
|        _limit         |           number           |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |             50             |
|         _skip         |           number           |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |             20             |
|        _sortBy        |           string           |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |         "username"         |
|      _sortValue       |           number           |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |             -1             |
|       _project        |           string           |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |  "name,startDate,endDate"  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|         Parametre          |            Tip             |                                 Açıklama                                 |           Örnek            |
| :------------------------: | :------------------------: | :----------------------------------------------------------------------: | :------------------------: |
|            data            |           array            |                              Kullanıcılar.                               |        [{...},...]         |
|          data._id          |           string           |                                   Id.                                    | "639e415e5880681729f0ac10" |
|       data.username        |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|         data.email         |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|         data.roles         |      array\<string\>       |                           Sahip olduğu roller.                           |       ["superUser"]        |
|      data.department       |           string           |                            Departman bilgisi.                            |   "Chemical Engineering"   |
|        data.office         |           string           |                              Ofis bilgisi.                               |  "Lorem Ipsum Hall, 512"   |
|       data.officeDay       | number\<-1,0,1,2,3,4,5,6\> |                       Ofis günü.(hafanın günleri)                        |             3              |
|   data.officeStartHours    |   string\<time\|ss:dd\>    |                           Ofis başlama saati.                            |          "14:00"           |
|    data.officeEndHours     |   string\<time\|ss:dd\>    |                            Ofis bitiş saati.                             |          "15:00"           |
|       data.zoomLink        |       string\<url\>        |                               Zoom linki.                                |        zoom.com/123        |
|       data.assigned        |       string\<url\>        | **courseId** parametresi ile sorulduğunda o kursa atanma durumunu döner. |            true            |
| data.requirePasswordChange |          boolean           |    Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir    |           false            |
|     data.sendInfoMail      |          boolean           |  Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir   |           false            |
|         data.stamp         |           object           |                            Son işlem bilgisi.                            |           {...}            |
|    data.stamp.createAt     |       string\<ISO\>        |                            Son işlem bilgisi.                            | "2022-12-17T22:23:25.978Z" |
|    data.stamp.username     |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|      data.stamp.email      |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|   data.stamp.displayName   |           string           |                        Görünen adı, isim soyisim.                        |  "Üst Yetkili Kullanıcı"   |
|       data.stamp.ip        |           string           |                                Ip adresi.                                |        "127.0.0.1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d45",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "student",
                "displayName": "Öğrenci Kullanıcı",
                "email": "student@paper-x.com",
                "roles": [
                    "student"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.762Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "username": "admin"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": []
    }
}
```

## GET /student/:id

Id bilgisi ile belirtilen bir öğrenci bilgilerini getiririr. 
Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.
Parola değişiklik zorunluluğu olan kullanıcıların da kullanımına açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|       Parametre       |            Tip             |                               Açıklama                                |           Örnek            |
| :-------------------: | :------------------------: | :-------------------------------------------------------------------: | :------------------------: |
|          _id          |           string           |                                  Id.                                  | "639e415e5880681729f0ac2b" |
|       username        |           string           |                            Kullanıcı adı.                             |          "admin"           |
|         email         |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|         roles         |      array\<string\>       |                         Sahip olduğu roller.                          |         ["admin"]          |
|      department       |           string           |                          Departman bilgisi.                           |   "Chemical Engineering"   |
|        office         |           string           |                             Ofis bilgisi.                             |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |                      Ofis günü.(hafanın günleri)                      |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |                          Ofis başlama saati.                          |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |                           Ofis bitiş saati.                           |          "15:00"           |
|       zoomLink        |       string\<url\>        |                              Zoom linki.                              |        zoom.com/123        |
| requirePasswordChange |          boolean           |  Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir   |           false            |
|     sendInfoMail      |          boolean           | Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir |           false            |
|         stamp         |           object           |                          Son işlem bilgisi.                           |           {...}            |
|    stamp.createAt     |       string\<ISO\>        |                          Son işlem bilgisi.                           | "2022-12-17T22:23:25.978Z" |
|    stamp.username     |           string           |                            Kullanıcı adı.                             |          "admin"           |
|      stamp.email      |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|   stamp.displayName   |           string           |                      Görünen adı, isim soyisim.                       |    "Yetkili Kullanıcı"     |
|       stamp.ip        |           string           |                              Ip adresi.                               |        "127.0.0.1"         |

#### Örnek
##### Request (/user/63a3634d50f0fdade97e8d45)
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "_id": "63a3634d50f0fdade97e8d45",
        "passive": false,
        "department": "",
        "office": "",
        "officeDay": -1,
        "officeStartHours": "",
        "officeEndHours": "",
        "zoomLink": "",
        "username": "student",
        "displayName": "Öğrenci Kullanıcı",
        "email": "student@paper-x.com",
        "roles": [
            "student"
        ],
        "stamp": {
            "createAt": "2022-12-21T19:49:33.762Z",
            "username": "superUser",
            "email": "superUser@paper-x.com",
            "displayName": "Üst Yetkili Kullanıcı",
            "ip": "127.0.0.1"
        }
    }
}
```

## GET /teachers

Öğretmen listesini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                                             Açıklama                                              |           Örnek            |
| :-------------------: | :------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :------------------------: |
|          _id          |     string\<objectId\>     |   Hayır    |            |                                            Id bilgisi.                                            | "63a3634d50f0fdade97e8d41" |
|       username        |           string           |   Hayır    |            |                                          Kullanıcı adı.                                           |        "superUser"         |
|      displayName      |           string           |   Hayır    |            |                                Görünen adı, isim soyisim. (Regex).                                |  "Üst Yetkili Kullanıcı"   |
|         email         |           string           |   Hayır    |            |                                          Eposta adresi.                                           |  "superUser@paper-x.com"   |
|        passive        |          boolean           |   Hayır    |            |                                         Pasiflik durumu.                                          |           false            |
|      department       |           string           |   Hayır    |            |                                        Departman bilgisi.                                         |   "Chemical Engineering"   |
|        office         |           string           |   Hayır    |            |                                           Ofis bilgisi.                                           |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |   Hayır    |            |                                    Ofis günü.(hafanın günleri)                                    |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |   Hayır    |            |                                        Ofis başlama saati.                                        |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |   Hayır    |            |                                         Ofis bitiş saati.                                         |          "15:00"           |
|       zoomLink        |       string\<url\>        |   Hayır    |            |                                            Zoom linki.                                            |        zoom.com/123        |
|      courseIdNe       |           string           |   Hayır    |            |                            Kurs id'sine eşit olmayan. Kursa atanmamış.                            | "63a3634d50f0fdade97e8d41" |
|      courseIdEq       |           string           |   Hayır    |            |                              Kurs id'sine eşit olan. Kursa atanmış.                               | "63a3634d50f0fdade97e8d41" |
|       courseId        |           string           |   Hayır    |            |             Kurs id'sine eşit olanların assign değeri true, olmayanların false döner.             | "63a3634d50f0fdade97e8d41" |
| requirePasswordChange |          boolean           |   Hayır    |            |                Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir                 |           false            |
|     sendInfoMail      |          boolean           |   Hayır    |            |               Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir               |           false            |
|        _limit         |           number           |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |             50             |
|         _skip         |           number           |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |             20             |
|        _sortBy        |           string           |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |         "username"         |
|      _sortValue       |           number           |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |             -1             |
|       _project        |           string           |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |  "name,startDate,endDate"  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|         Parametre          |            Tip             |                                 Açıklama                                 |           Örnek            |
| :------------------------: | :------------------------: | :----------------------------------------------------------------------: | :------------------------: |
|            data            |           array            |                              Kullanıcılar.                               |        [{...},...]         |
|          data._id          |           string           |                                   Id.                                    | "639e415e5880681729f0ac10" |
|       data.username        |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|         data.email         |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|         data.roles         |      array\<string\>       |                           Sahip olduğu roller.                           |       ["superUser"]        |
|      data.department       |           string           |                            Departman bilgisi.                            |   "Chemical Engineering"   |
|        data.office         |           string           |                              Ofis bilgisi.                               |  "Lorem Ipsum Hall, 512"   |
|       data.officeDay       | number\<-1,0,1,2,3,4,5,6\> |                       Ofis günü.(hafanın günleri)                        |             3              |
|   data.officeStartHours    |   string\<time\|ss:dd\>    |                           Ofis başlama saati.                            |          "14:00"           |
|    data.officeEndHours     |   string\<time\|ss:dd\>    |                            Ofis bitiş saati.                             |          "15:00"           |
|       data.zoomLink        |       string\<url\>        |                               Zoom linki.                                |        zoom.com/123        |
|       data.assigned        |       string\<url\>        | **courseId** parametresi ile sorulduğunda o kursa atanma durumunu döner. |            true            |
| data.requirePasswordChange |          boolean           |    Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir    |           false            |
|     data.sendInfoMail      |          boolean           |  Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir   |           false            |
|         data.stamp         |           object           |                            Son işlem bilgisi.                            |           {...}            |
|    data.stamp.createAt     |       string\<ISO\>        |                            Son işlem bilgisi.                            | "2022-12-17T22:23:25.978Z" |
|    data.stamp.username     |           string           |                              Kullanıcı adı.                              |        "superUser"         |
|      data.stamp.email      |           string           |                              Eposta adresi.                              |  "superUser@paper-x.com"   |
|   data.stamp.displayName   |           string           |                        Görünen adı, isim soyisim.                        |  "Üst Yetkili Kullanıcı"   |
|       data.stamp.ip        |           string           |                                Ip adresi.                                |        "127.0.0.1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a3634d50f0fdade97e8d42",
                "passive": false,
                "department": "",
                "office": "",
                "officeDay": -1,
                "officeStartHours": "",
                "officeEndHours": "",
                "zoomLink": "",
                "username": "teacher",
                "displayName": "Öğretmen Kullanıcı",
                "email": "teacher@paper-x.com",
                "roles": [
                    "teacher"
                ],
                "stamp": {
                    "createAt": "2022-12-21T19:49:33.761Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                }
            },
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "username": "admin"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": []
    }
}
```

## GET /teacher/:id

Id bilgisi ile belirtilen bir öğretmen bilgilerini getiririr.
Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.
Parola değişiklik zorunluluğu olan kullanıcıların da kullanımına açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|       Parametre       |            Tip             |                               Açıklama                                |           Örnek            |
| :-------------------: | :------------------------: | :-------------------------------------------------------------------: | :------------------------: |
|          _id          |           string           |                                  Id.                                  | "639e415e5880681729f0ac2b" |
|       username        |           string           |                            Kullanıcı adı.                             |          "admin"           |
|         email         |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|         roles         |      array\<string\>       |                         Sahip olduğu roller.                          |         ["admin"]          |
|      department       |           string           |                          Departman bilgisi.                           |   "Chemical Engineering"   |
|        office         |           string           |                             Ofis bilgisi.                             |  "Lorem Ipsum Hall, 512"   |
|       officeDay       | number\<-1,0,1,2,3,4,5,6\> |                      Ofis günü.(hafanın günleri)                      |             3              |
|   officeStartHours    |   string\<time\|ss:dd\>    |                          Ofis başlama saati.                          |          "14:00"           |
|    officeEndHours     |   string\<time\|ss:dd\>    |                           Ofis bitiş saati.                           |          "15:00"           |
|       zoomLink        |       string\<url\>        |                              Zoom linki.                              |        zoom.com/123        |
| requirePasswordChange |          boolean           |  Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir   |           false            |
|     sendInfoMail      |          boolean           | Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir |           false            |
|         stamp         |           object           |                          Son işlem bilgisi.                           |           {...}            |
|    stamp.createAt     |       string\<ISO\>        |                          Son işlem bilgisi.                           | "2022-12-17T22:23:25.978Z" |
|    stamp.username     |           string           |                            Kullanıcı adı.                             |          "admin"           |
|      stamp.email      |           string           |                            Eposta adresi.                             |    "admin@paper-x.com"     |
|   stamp.displayName   |           string           |                      Görünen adı, isim soyisim.                       |    "Yetkili Kullanıcı"     |
|       stamp.ip        |           string           |                              Ip adresi.                               |        "127.0.0.1"         |

#### Örnek
##### Request (/user/63a3634d50f0fdade97e8d45)
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "_id": "63a3634d50f0fdade97e8d42",
        "passive": false,
        "department": "",
        "office": "",
        "officeDay": -1,
        "officeStartHours": "",
        "officeEndHours": "",
        "zoomLink": "",
        "username": "teacher",
        "displayName": "Öğretmen Kullanıcı",
        "email": "teacher@paper-x.com",
        "roles": [
            "teacher"
        ],
        "stamp": {
            "createAt": "2022-12-21T19:49:33.761Z",
            "username": "superUser",
            "email": "superUser@paper-x.com",
            "displayName": "Üst Yetkili Kullanıcı",
            "ip": "127.0.0.1"
        }
    }
}
```

## GET /courses

![alt](./materials/img/course_list.png)
![alt](./materials/img/course_materials.png)

Kurs bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları kursları görüntüleyebilir ve düzenleyebilir. Öğrenciler sadece kendilerine atanan kursları görüntüleyebilir.

#### Girdi

|       Parametre       |            Tip             | Zorunluluk | Varsayılan |                                             Açıklama                                              |          Örnek           |
| :-------------------: | :------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :----------------------: |
|      schoolName       |           string           |   Hayır    |            |                                           Okul bilgisi.                                           |        "School 1"        |
|    departmentName     |           string           |   Hayır    |            |                                          Bölüm bilgisi.                                           |      "Department 1"      |
|         name          |           string           |   Hayır    |            |                                           Kurs bilgisi.                                           |        "Course 1"        |
|       startDate       | string\<date\|yyyy-aa-gg\> |   Hayır    |            |                                       Kurs başlama tarihi.                                        |       "2022-12-18"       |
|        endDate        | string\<date\|yyyy-aa-gg\> |   Hayır    |            |                                        Kurs bitiş tarihi.                                         |       "2022-12-30"       |
|       startTime       |   string\<time\|ss:dd\>    |   Hayır    |            |                                        Kurs başlama saati.                                        |         "10:00"          |
|        endTime        |   string\<time\|ss:dd\>    |   Hayır    |            |                                         Kurs bitiş saati.                                         |         "16:00"          |
|      grades.type      |           string           |   Hayır    |            |                                        Grade tip bilgisi.                                         |        "Homework"        |
| assignedTAs.username  |           string           |   Hayır    |            |                                     TA kullanıcı adı bilgisi.                                     |          "TA 1"          |
|  videos.originalName  |           string           |   Hayır    |            |                                  Kurs video materyal dosya adı.                                   |        "Video 1"         |
| printeds.originalName |           string           |   Hayır    |            |                                  Kurs baskılı materyal dosya adı                                  |         "PDF 1"          |
|      exams.name       |           string           |   Hayır    |            |                                            Sınav  adı                                             |         "Exam 1"         |
| requirePasswordChange |          boolean           |   Hayır    |            |                Kullanıcının parola değiştirmesinin zorunlu olma durumunu belirtir                 |          false           |
|     sendInfoMail      |          boolean           |   Hayır    |            |               Kullanıcıya; kullanıcı adı ve parola bilgileri eposta olarak iletilir               |          false           |
|        _limit         |           number           |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |            50            |
|         _skip         |           number           |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |            20            |
|        _sortBy        |           string           |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |        "username"        |
|      _sortValue       |           number           |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |            -1            |
|       _project        |           string           |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. | "name,startDate,endDate" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|         Parametre          |            Tip             |               Açıklama               |                              Örnek                              |
| :------------------------: | :------------------------: | :----------------------------------: | :-------------------------------------------------------------: |
|            data            |           array            |               Kurslar.               |                           [{...},...]                           |
|          data._id          |           string           |                 Id.                  |                   "639e50c85880681729f8b23b"                    |
|      data.schoolName       |           string           |            Okul bilgisi.             |                           "School 1"                            |
|    data.departmentName     |           string           |            Bölüm bilgisi.            |                         "Department 1"                          |
|         data.name          |           string           |            Kurs bilgisi.             |                           "Course 1"                            |
|       data.startDate       | string\<date\|yyyy-aa-gg\> |         Kurs başlama tarihi.         |                          "2022-12-18"                           |
|        data.endDate        | string\<date\|yyyy-aa-gg\> |          Kurs bitiş tarihi.          |                          "2022-12-30"                           |
|       data.startTime       |   string\<time\|ss:dd\>    |         Kurs başlama saati.          |                             "10:00"                             |
|        data.endTime        |   string\<time\|ss:dd\>    |          Kurs bitiş saati.           |                             "16:00"                             |
|        data.grades         |      array\<object\>       |           Grade bilgileri.           |                           [{...},...]                           |
|      data.grades.type      |           string           |          Grade tip bilgisi.          |                           "Homework"                            |
|  data.grades.distribution  |           number           |        Grade dağılım bilgisi.        |                               40                                |
|      data.assignedTAs      |      array\<object\>       |         TA atama bilgileri.          |                           [{...},...]                           |
|    data.assignedTAs.id     |     string\<objectId\>     |            TA id bilgisi.            |                    63a37398b54d184ab996fabb                     |
| data.assignedTAs.username  |           string           |      TA kullanıcı adı bilgisi.       |                             "TA 1"                              |
|        data.videos         |      array\<object\>       |       Kurs material videolar.        |                           [{...},...]                           |
|       data.videos.id       |           string           |          Video id bilgisi.           |                       "925e52a0c8793cd01"                       |
|      data.videos.name      |           string           |           Video dosya adı.           |               "Courses-videos-925e52a0c8793cd01"                |
|  data.videos.originalName  |           string           |     Video yüklenen orijinal adı.     |                "file_example_MP4_480_1_5MG.mp4"                 |
|      data.videos.path      |           string           |          Video dosya yolu.           | "./projects/api/uploads/Courses/file_example_MP4_480_1_5MG.mp4" |
|    data.videos.encoding    |           string           |       Video encoding bilgisi.        |                             "7bit"                              |
|    data.videos.mimeType    |           string           |          Video dosya tipi.           |                           "video/mp4"                           |
|      data.videos.size      |           number           |         Video dosya boyutu.          |                             1570024                             |
|    data.videos.sizeType    |           string           |       Video dosya boyutu tipi.       |                             "bayt"                              |
|    data.videos.duration    |           number           |            Video süresi.             |                            30.033333                            |
|  data.videos.durationType  |           string           |          Video süresi tipi.          |                            "seconds"                            |
|       data.printeds        |      array\<object\>       |   Kurs material baskılı dosyalar.    |                           [{...},...]                           |
|      data.printeds.id      |           string           |      Baskılı dosya id bilgisi.       |                       "4d52d1153ab781320"                       |
|     data.printeds.name     |           string           |       Baskılı dosya dosya adı.       |              "Courses-printeds-4d52d1153ab781320"               |
| data.printeds.originalName |           string           | Baskılı dosya yüklenen orijinal adı. |                          "sample.pdf"                           |
|     data.printeds.path     |           string           |      Baskılı dosya dosya yolu.       |           "./projects/api/uploads/Courses/sample.pdf"           |
|   data.printeds.encoding   |           string           |   Baskılı dosya encoding bilgisi.    |                             "7bit"                              |
|   data.printeds.mimeType   |           string           |      Baskılı dosya dosya tipi.       |                        "application/pdf"                        |
|     data.printeds.size     |           number           |     Baskılı dosya dosya boyutu.      |                              3028                               |
|   data.printeds.sizeType   |           string           |   Baskılı dosya dosya boyutu tipi.   |                             "bayt"                              |
|   data.printeds.duration   |           number           |        Baskılı dosya süresi.         |                               -1                                |
| data.printeds.durationType |           string           |      Baskılı dosya süresi tipi.      |                            "seconds"                            |

|         exams.name         |           string           |              Sınav  adı              |                            "Exam 1"                             |
|         data.stamp         |           object           |          Son işlem bilgisi.          |                              {...}                              |
|    data.stamp.createAt     |       string\<ISO\>        |          Son işlem bilgisi.          |                   "2022-12-17T23:29:12.514Z"                    |
|    data.stamp.username     |           string           |            Kullanıcı adı.            |                          "system.user"                          |
|      data.stamp.email      |           string           |            Eposta adresi.            |                      "system@paper-x.com"                       |
|   data.stamp.displayName   |           string           |      Görünen adı, isim soyisim.      |                      "Sistem Kullanıcısı"                       |
|       data.stamp.ip        |           string           |              Ip adresi.              |                           "127.0.0.1"                           |

#### Örnek
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a37398b54d184ab996fabb",
                "schoolName": "School 1",
                "departmentName": "Department 1",
                "name": "Course 1",
                "startTime": "10:00",
                "endTime": "16:00",
                "grades": [
                    {
                        "type": "Midterm Exam",
                        "distribution": 30
                    },
                    {
                        "type": "Final Exam",
                        "distribution": 40
                    },
                    {
                        "type": "Homework",
                        "distribution": 15
                    },
                    {
                        "type": "Quizzes",
                        "distribution": 15
                    }
                ],
                "assignedTAs": [
                    {
                        "_id": "63a37398b54d184ab996fabb"
                    },
                    {
                        "_id": "63a37398b54d184ab996fabb"
                    }
                ],
                "stamp": {
                    "createAt": "2022-12-21T21:01:26.999Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                },
                "passive": false,
                "startDate": "2022-12-18",
                "endDate": "2022-12-30"
            },
            {
                "_id": "63a37398b54d184ab996fabc",
                "schoolName": "School 2",
                "departmentName": "Department 2",
                "name": "Course 2",
                "startTime": "13:00",
                "endTime": "15:00",
                "grades": [
                    {
                        "type": "Midterm Exam",
                        "distribution": 30
                    },
                    {
                        "type": "Final Exam",
                        "distribution": 40
                    },
                    {
                        "type": "Homework",
                        "distribution": 15
                    },
                    {
                        "type": "Quizzes",
                        "distribution": 15
                    }
                ],
                "assignedTAs": [],
                "stamp": {
                    "createAt": "2022-12-21T20:59:04.437Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                },
                "passive": false,
                "startDate": "2022-12-20",
                "endDate": "2022-12-24"
            },
            {
                "_id": "63a37398b54d184ab996fabd",
                "schoolName": "School 3",
                "departmentName": "Department 3",
                "name": "Course 3",
                "startTime": "08:00",
                "endTime": "12:00",
                "grades": [
                    {
                        "type": "Midterm Exam",
                        "distribution": 30
                    },
                    {
                        "type": "Final Exam",
                        "distribution": 40
                    },
                    {
                        "type": "Homework",
                        "distribution": 15
                    },
                    {
                        "type": "Quizzes",
                        "distribution": 15
                    }
                ],
                "assignedTAs": [],
                "stamp": {
                    "createAt": "2022-12-21T20:59:04.437Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                },
                "passive": false,
                "startDate": "2022-12-24",
                "endDate": "2022-12-26"
            },
            {
                "_id": "63a37398b54d184ab996fabe",
                "schoolName": "School 4",
                "departmentName": "Department 4",
                "name": "Course 4",
                "startTime": "13:00",
                "endTime": "16:00",
                "grades": [
                    {
                        "type": "Homework",
                        "distribution": 40
                    },
                    {
                        "type": "Quizzes",
                        "distribution": 20
                    }
                ],
                "assignedTAs": [],
                "stamp": {
                    "createAt": "2022-12-21T20:59:04.450Z",
                    "username": "superUser",
                    "email": "superUser@paper-x.com",
                    "displayName": "Üst Yetkili Kullanıcı",
                    "ip": "127.0.0.1"
                },
                "passive": false,
                "startDate": "2022-12-28",
                "endDate": "2022-12-31"
            }
        ]
    }
}
```

## GET /course/:id

Id ile belirtilen kurs bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları kursları görüntüleyebilir ve düzenleyebilir. Öğrenciler sadece kendilerine atanan kursları görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|       Parametre       |            Tip             |               Açıklama               |                              Örnek                              |
| :-------------------: | :------------------------: | :----------------------------------: | :-------------------------------------------------------------: |
|          _id          |           string           |                 Id.                  |                   "639e50c85880681729f8b23b"                    |
|      schoolName       |           string           |            Okul bilgisi.             |                           "School 1"                            |
|    departmentName     |           string           |            Bölüm bilgisi.            |                         "Department 1"                          |
|         name          |           string           |            Kurs bilgisi.             |                           "Course 1"                            |
|       startDate       | string\<date\|yyyy-aa-gg\> |         Kurs başlama tarihi.         |                          "2022-12-18"                           |
|        endDate        | string\<date\|yyyy-aa-gg\> |          Kurs bitiş tarihi.          |                          "2022-12-30"                           |
|       startTime       |   string\<time\|ss:dd\>    |         Kurs başlama saati.          |                             "10:00"                             |
|        endTime        |   string\<time\|ss:dd\>    |          Kurs bitiş saati.           |                             "16:00"                             |
|        grades         |      array\<object\>       |           Grade bilgileri.           |                           [{...},...]                           |
|      grades.type      |           string           |          Grade tip bilgisi.          |                           "Homework"                            |
|  grades.distribution  |           number           |        Grade dağılım bilgisi.        |                               40                                |
|      assignedTAs      |      array\<object\>       |         TA atama bilgileri.          |                           [{...},...]                           |
|    assignedTAs.id     |     string\<objectId\>     |            TA id bilgisi.            |                    63a37398b54d184ab996fabb                     |
| assignedTAs.username  |           string           |      TA kullanıcı adı bilgisi.       |                             "TA 1"                              |
|        videos         |      array\<object\>       |       Kurs material videolar.        |                           [{...},...]                           |
|       videos.id       |           string           |          Video id bilgisi.           |                       "925e52a0c8793cd01"                       |
|      videos.name      |           string           |           Video dosya adı.           |               "Courses-videos-925e52a0c8793cd01"                |
|  videos.originalName  |           string           |     Video yüklenen orijinal adı.     |                "file_example_MP4_480_1_5MG.mp4"                 |
|      videos.path      |           string           |          Video dosya yolu.           | "./projects/api/uploads/Courses/file_example_MP4_480_1_5MG.mp4" |
|    videos.encoding    |           string           |       Video encoding bilgisi.        |                             "7bit"                              |
|    videos.mimeType    |           string           |          Video dosya tipi.           |                           "video/mp4"                           |
|      videos.size      |           number           |         Video dosya boyutu.          |                             1570024                             |
|    videos.sizeType    |           string           |       Video dosya boyutu tipi.       |                             "bayt"                              |
|    videos.duration    |           number           |            Video süresi.             |                            30.033333                            |
|  videos.durationType  |           string           |          Video süresi tipi.          |                            "seconds"                            |
|       printeds        |      array\<object\>       |   Kurs material baskılı dosyalar.    |                           [{...},...]                           |
|      printeds.id      |           string           |      Baskılı dosya id bilgisi.       |                       "4d52d1153ab781320"                       |
|     printeds.name     |           string           |       Baskılı dosya dosya adı.       |              "Courses-printeds-4d52d1153ab781320"               |
| printeds.originalName |           string           | Baskılı dosya yüklenen orijinal adı. |                          "sample.pdf"                           |
|     printeds.path     |           string           |      Baskılı dosya dosya yolu.       |           "./projects/api/uploads/Courses/sample.pdf"           |
|   printeds.encoding   |           string           |   Baskılı dosya encoding bilgisi.    |                             "7bit"                              |
|   printeds.mimeType   |           string           |      Baskılı dosya dosya tipi.       |                        "application/pdf"                        |
|     printeds.size     |           number           |     Baskılı dosya dosya boyutu.      |                              3028                               |
|   printeds.sizeType   |           string           |   Baskılı dosya dosya boyutu tipi.   |                             "bayt"                              |
|   printeds.duration   |           number           |        Baskılı dosya süresi.         |                               -1                                |
| printeds.durationType |           string           |      Baskılı dosya süresi tipi.      |                            "seconds"                            |
|         stamp         |           object           |          Son işlem bilgisi.          |                               {}                                |
|    stamp.createAt     |       string\<ISO\>        |          Son işlem bilgisi.          |                   "2022-12-17T23:29:12.514Z"                    |
|    stamp.username     |           string           |            Kullanıcı adı.            |                          "system.user"                          |
|      stamp.email      |           string           |            Eposta adresi.            |                      "system@paper-x.com"                       |
|   stamp.displayName   |           string           |      Görünen adı, isim soyisim.      |                      "Sistem Kullanıcısı"                       |
|       stamp.ip        |           string           |              Ip adresi.              |                           "127.0.0.1"                           |

#### Örnek
##### Request (/course/639f1add84cf308199dc3736)
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "_id": "63a37398b54d184ab996fabb",
        "schoolName": "School 1",
        "departmentName": "Department 1",
        "name": "Course 1",
        "startTime": "10:00",
        "endTime": "16:00",
        "grades": [
            {
                "type": "Midterm Exam",
                "distribution": 30
            },
            {
                "type": "Final Exam",
                "distribution": 40
            },
            {
                "type": "Homework",
                "distribution": 15
            },
            {
                "type": "Quizzes",
                "distribution": 15
            }
        ],
        "assignedTAs": [
            {
                "_id": "63a37398b54d184ab996fabb"
            },
            {
                "_id": "63a37398b54d184ab996fabb"
            }
        ],
        "stamp": {
            "createAt": "2022-12-21T21:01:26.999Z",
            "username": "superUser",
            "email": "superUser@paper-x.com",
            "displayName": "Üst Yetkili Kullanıcı",
            "ip": "127.0.0.1"
        },
        "passive": false,
        "startDate": "2022-12-18",
        "endDate": "2022-12-30"
    }
}
```

## POST /course

![alt](./materials/img/course_post.png)
![alt](./materials/img/grades.png)

Kurs bilgisi girmek için kullanılır. Yeni bir kurs kaydedilir. "name" bilgisi benzersiz olmalıdır.
Eğer var olan bir name değerine ait giriş varsa hata döner. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|      Parametre       |            Tip             | Zorunluluk |                                                                           Varsayılan                                                                           |          Açıklama           |          Örnek           |                     Resim                     |
| :------------------: | :------------------------: | :--------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------: | :-------------------------: | :----------------------: | :-------------------------------------------: |
|      schoolName      |           string           |    Evet    |                                                                                                                                                                |        Okul bilgisi.        |        "School 1"        |   ![alt](./materials/img/course_school.png)   |
|    departmentName    |           string           |    Evet    |                                                                                                                                                                |       Bölüm bilgisi.        |      "Department 1"      | ![alt](./materials/img/course_department.png) |
|         name         |           string           |    Evet    |                                                                                                                                                                |        Kurs bilgisi.        |        "Course 1"        |    ![alt](./materials/img/course_code.png)    |
|      startDate       | string\<date\|yyyy-aa-gg\> |   Hayır    |                                                                                                                                                                |    Kurs başlama tarihi.     |       "2022-12-18"       |                                               |
|       endDate        | string\<date\|yyyy-aa-gg\> |   Hayır    |                                                                                                                                                                |     Kurs bitiş tarihi.      |       "2022-12-30"       |                                               |
|      startTime       |   string\<time\|ss:dd\>    |   Hayır    |                                                                                                                                                                |     Kurs başlama saati.     |         "10:00"          |                                               |
|       endTime        |   string\<time\|ss:dd\>    |   Hayır    |                                                                                                                                                                |      Kurs bitiş saati.      |         "16:00"          |                                               |
|        grades        |      array\<object\>       |   Hayır    | [{"type":"Midterm Exam","distribution":30},{"type":"Final Exam","distribution":40},{"type":"Homework","distribution":15},{"type":"Quizzes","distribution":15}] |      Grade bilgileri.       |       [{...},...]        |                                               |
|     grades.type      |           string           |   Hayır    |                                                                                                                                                                |     Grade tip bilgisi.      |        "Homework"        |    ![alt](./materials/img/grade_type.png)     |
| grades.distribution  |           number           |   Hayır    |                                                                                                                                                                |   Grade dağılım bilgisi.    |            40            |     ![alt](./materials/img/grade_val.png)     |
|     assignedTAs      |      array\<object\>       |   Hayır    |                                                                               []                                                                               |     TA atama bilgileri.     |       [{...},...]        |    ![alt](./materials/img/assign_tas.png)     |
|    assignedTAs.id    |     string\<objectId\>     |   Hayır    |                                                                                                                                                                |       TA id bilgisi.        | 63a37398b54d184ab996fabb |                                               |
| assignedTAs.username |           string           |   Hayır    |                                                                                                                                                                |  TA kullanıcı adı bilgisi.  |          "TA 1"          |                                               |
|        videos        |    array\<file(video)\>    |   Hayır    |                                                                                                                                                                |  Video materyal dosyaları.  |         \<FILE\>         |  ![alt](./materials/img/course_material.png)  |
|       printeds       |       array\<file\>        |   Hayır    |                                                                                                                                                                | Baskılı materyal dosyaları. |         \<FILE\>         |  ![alt](./materials/img/course_material.png)  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

#### Örnek 1
##### Request
```json
{
    "schoolName": "School 1",
    "departmentName": "Department 1",
    "name": "Course 1",
    "startDate": "2022-12-18",
    "endDate": "2022-12-30",
    "startTime": "10:00",
    "endTime": "16:00"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

#### Örnek 2
##### Request
```json
{
    "schoolName": "School 1",
    "departmentName": "Department 1",
    "name": "Course 1",
    "startDate": "2022-12-18",
    "endDate": "2022-12-30",
    "startTime": "10:00",
    "endTime": "16:00"
}
```

##### Response
```json
{
    "code": 1,
    "message": "Bu kurs kodu/adı kullanılmaktadır.",
    "isShowMessage": true,
    "result": {}
}
```

#### Örnek 3
##### Request
```json
{
    "schoolName": "School 4",
    "departmentName": "Department 4",
    "name": "Course 4",
    "startDate": "2022-12-28",
    "endDate": "2022-12-31",
    "startTime": "13:00",
    "endTime": "16:00",
    "grades": [
        {
            "type": "Homework",
            "distribution": 40
        },
        {
            "type": "Quizzes",
            "distribution": 20
        }
    ],
    {
    "assignedTAs": [
        {
            "_id": "63a37398b54d184ab996faba"
        },
        {
            "_id": "63a37398b54d184ab996fabd"
        }
    ]
}
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

## POST,PUT /course/:id

Id bilgisi ile belirtilen kurs bilgilerini günceller. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

Silme işlemi yoktur. Sadece pasife alınabilir.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|      Parametre       |            Tip             | Zorunluluk | Varsayılan |          Açıklama           |          Örnek           |
| :------------------: | :------------------------: | :--------: | :--------: | :-------------------------: | :----------------------: |
|      schoolName      |           string           |   Hayır    |            |        Okul bilgisi.        |        "School 1"        |
|    departmentName    |           string           |   Hayır    |            |       Bölüm bilgisi.        |      "Department 1"      |
|         name         |           string           |   Hayır    |            |        Kurs bilgisi.        |        "Course 1"        |
|       passive        |          boolean           |   Hayır    |            |      Pasiflik bilgisi.      |           true           |
|      startDate       | string\<date\|yyyy-aa-gg\> |   Hayır    |            |    Kurs başlama tarihi.     |       "2022-12-18"       |
|       endDate        | string\<date\|yyyy-aa-gg\> |   Hayır    |            |     Kurs bitiş tarihi.      |       "2022-12-30"       |
|      startTime       |   string\<time\|ss:dd\>    |   Hayır    |            |     Kurs başlama saati.     |         "10:00"          |
|       endTime        |   string\<time\|ss:dd\>    |   Hayır    |            |      Kurs bitiş saati.      |         "16:00"          |
|        grades        |      array\<object\>       |   Hayır    |            |      Grade bilgileri.       |       [{...},...]        |
|     grades.type      |           string           |   Hayır    |            |     Grade tip bilgisi.      |        "Homework"        |
| grades.distribution  |           number           |   Hayır    |            |   Grade dağılım bilgisi.    |            40            |
|     assignedTAs      |      array\<object\>       |   Hayır    |            |     TA atama bilgileri.     |       [{...},...]        |
|    assignedTAs.id    |     string\<objectId\>     |   Hayır    |            |       TA id bilgisi.        | 63a37398b54d184ab996fabb |
| assignedTAs.username |           string           |   Hayır    |            |  TA kullanıcı adı bilgisi.  |          "TA 1"          |
|        videos        |    array\<file(video)\>    |   Hayır    |            |  Video materyal dosyaları.  |         \<FILE\>         |
|       printeds       |       array\<file\>        |   Hayır    |            | Baskılı materyal dosyaları. |         \<FILE\>         |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

#### Örnek 1
##### Request (/course/639f1add84cf308199dc3736)
```json
{
    "schoolName": "School 2"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

#### Örnek 2
##### Request (/course/639f1add84cf308199dc3736)
```json
{
    "passive": true
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

#### Örnek 3
##### Request (/course/63a37398b54d184ab996fabb)
```json
{
    "assignedTAs": [
        {
            "_id": "63a37398b54d184ab996fabd"
        },
        {
            "_id": "63a37398b54d184ab996fabc"
        }
    ]
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {}
}
```

## POST,PUT /course-assign

![alt](./materials/img/course_assign.png)

Kursa atama işlemi yapar. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|      Parametre       |        Tip         | Zorunluluk | Varsayılan |         Açıklama          |           Örnek            |
| :------------------: | :----------------: | :--------: | :--------: | :-----------------------: | :------------------------: |
|        course        |       string       |    Evet    |            |     Kurs id bilgisi.      | "63a37398b54d184ab996fabb" |
|     assignedTAs      |  array\<object\>   |    Evet    |            |    TA atama bilgileri.    |        [{...},...]         |
|    assignedTAs.id    | string\<objectId\> |    Evet    |            |      TA id bilgisi.       | "63a37398b54d184ab996fabb" |
| assignedTAs.username |       string       |    Evet    |            | TA kullanıcı adı bilgisi. |           "TA 1"           |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## POST,PUT /course-uploads

![alt](./materials/img/course_material.png)

Kursa dosya yükleme işlemi yapar. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

| Parametre |         Tip          | Zorunluluk | Varsayılan |          Açıklama           |           Örnek            |
| :-------: | :------------------: | :--------: | :--------: | :-------------------------: | :------------------------: |
|  course   |        string        |    Evet    |            |      Kurs id bilgisi.       | "63a37398b54d184ab996fabb" |
|  videos   | array\<file(video)\> |    Evet    |            |  Video materyal dosyaları.  |          \<FILE\>          |
| printeds  |    array\<file\>     |    Evet    |            | Baskılı materyal dosyaları. |          \<FILE\>          |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## PUT /course-uploads/:id

![alt](./materials/img/course_video_duration.png)

Kursa videolarının izlenme süresini kaydeder. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|     Parametre      |  Tip   | Zorunluluk | Varsayılan |            Açıklama            |           Örnek            |
| :----------------: | :----: | :--------: | :--------: | :----------------------------: | :------------------------: |
|       course       | string |    Evet    |            |        Kurs id bilgisi.        | "63a37398b54d184ab996fabb" |
| videoWatchDuration | number |    Evet    |            | Video izlenme süresi. (saniye) |             15             |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## GET /exams

Sınav bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk | Varsayılan |                                             Açıklama                                              |                 Örnek                 |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :-----------------------------------: |
|          course          |                              string                               |   Hayır    |            |                                         Kurs id bilgisi.                                          |          "925e52a0c8793cd01"          |
|           name           |                              string                               |   Hayır    |            |                                          Sınav bilgisi.                                           |               "Exam 1"                |
|    files.originalName    |                              string                               |   Hayır    |            |                               Sınav yüklenen dosyanın orijinal adı.                               |   "file_example_MP4_480_1_5MG.mp4"    |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |            |                             Sınav gönderisi yükleyecek kişi bilgisi.                              |              "Students"               |
|   allowLateSubmissions   |                               array                               |   Hayır    |            |                         Sınav gönderisini geçiltirecek kişilerin bilgisi.                         | ["All Students", "Disabled Students"] |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                       Sınav başlama tarihi.                                       |              2023-01-08               |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                        Sınav bitiş tarihi.                                        |              2023-02-12               |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                       Sınav başlama saati.                                        |                 08:00                 |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                        Sınav bitiş saati.                                         |                 18:00                 |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                     Sınav geciktirme tarihi.                                      |              2023-02-25               |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                      Sınav geciktirme saati.                                      |                 17:00                 |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |            |                                       Sınav gönderim tipi.                                        |              "templated"              |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |            |                                     Sınav grup gönderim izni.                                     |                 false                 |
|   groupSubmissionLimit   |                              number                               |   Hayır    |            |                                    Sınav grup gönderi limiti.                                     |                   2                   |
|      fileVisibility      |                              boolean                              |   Hayır    |            |                           Sınav dosya görünürlüğü ve indirilebilirliği.                           |                 true                  |
|         passive          |                              boolean                              |   Hayır    |            |                                      Sınav pasiflik durumu.                                       |                 false                 |
|     shareInstructors     |                              boolean                              |   Hayır    |            |                            Sınavın eğitmen/öğretmen için paylaşılması.                            |                 true                  |
|         shareTAs         |                              boolean                              |   Hayır    |            |                            Sınavın öğrenciler(TA?) için paylaşılması.                             |                 true                  |
|      shareStudents       |                              boolean                              |   Hayır    |            |                          Sınavın öğrenciler(Student?) için paylaşılması.                          |                 false                 |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |            |                                       Sınav durum bilgisi.                                        |              "completed"              |
|       isPublished        |                              boolean                              |   Hayır    |            |                                      Sınav paylaşım durumu.                                       |                 true                  |
|        isRegrades        |                              boolean                              |   Hayır    |            |                                Sınav yeniden değerlendirmedurumu.                                 |                 false                 |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |            |                           Sınav varsayılan değerlendirme listesi türü.                            |              "positive"               |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    |            |                                 Sınav varsayılan puan tahvilleri.                                 |               ["floor"]               |
|         applyAll         |                              boolean                              |   Hayır    |            |                            Sınav ayarlarının tüm sorulara uygulanması.                            |                 true                  |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |            |                                   Sınav varsayılan seçim stili.                                   |                 "one"                 |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |            |                                    Sınav öğrenci görünürlüğü.                                     |        "showOnlyAppliedRublic"        |
|      outlines.title      |                              string                               |   Hayır    |            |                                         Sınav soru ismi.                                          |             "Question 1"              |
|      outlines.point      |                              number                               |   Hayır    |            |                                         Sınav soru puanı.                                         |                  10                   |
|           type           |                string\<enum\|exam,homework,quiz\>                 |   Hayır    |            |                                            Sınav tipi.                                            |                "exam"                 |
|     submissions.user     |                              string                               |   Hayır    |            |                          Sınav yüklenen cevap/göderim dosyasının sahibi.                          |              "superUser"              |
|          _limit          |                              number                               |   Hayır    |            | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |                  50                   |
|          _skip           |                              number                               |   Hayır    |            |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |                  20                   |
|         _sortBy          |                              string                               |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |              "username"               |
|        _sortValue        |                              number                               |   Hayır    |            |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |                  -1                   |
|         _project         |                              string                               |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |       "name,startDate,endDate"        |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|           Parametre           |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :---------------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|             data              |                               array                               |                     Sınavlar.                     |                   [{...},...]                    |
|           data._id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          data.course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        data.course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       data.course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           data.name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          data.files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         data.files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        data.files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    data.files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        data.files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      data.files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      data.files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        data.files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      data.files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      data.files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    data.files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    data.uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   data.allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        data.startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         data.endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        data.startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         data.endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         data.lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         data.lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      data.submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| data.isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   data.groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      data.fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         data.passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     data.shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         data.shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      data.shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          data.status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       data.isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        data.isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    data.defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    data.defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         data.applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      data.selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    data.studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         data.outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      data.outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      data.outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     data.outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  data.outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  data.outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           data.type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       data.submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      data.submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     data.submissions.user     |                              string                               |              Sınav gönderim sahini.               |                   "superUser"                    |
|          data.graded          |                              number                               |              Toplam başarı yüzdesi.               |                       100                        |
|          data.stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      data.stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      data.stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       data.stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    data.stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         data.stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## GET /exam/:id

Id ile belirtilen sınav bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|        Parametre         |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|           _id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     submissions.user     |                              string                               |              Sınav gönderim sahibi.               |                   "superUser"                    |
|          stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## POST /exam

![alt](./materials/img/exam_post.png)

Sınav bilgisi girmek için kullanılır. Yeni bir sınav kaydedilir. "name" bilgisi benzersiz olmalıdır.

Eğer var olan bir name değerine ait giriş varsa hata döner. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |                          Resim                          |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: | :-----------------------------------------------------: |
|          course          |                              string                               |    Evet    |                     |                 Kurs id bilgisi.                  |               "925e52a0c8793cd01"                |                                                         |
|           name           |                              string                               |    Evet    |                     |                  Sınav bilgisi.                   |                     "Exam 1"                     |          ![alt](./materials/img/exam_name.png)          |
|          files           |                           array\<file\>                           |    Evet    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |         ![alt](./materials/img/exam_files.png)          |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |    Evet    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |   ![alt](./materials/img/exam_upload_submission.png)    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |       ![alt](./materials/img/exam_allow_late.png)       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |       ![alt](./materials/img/exam_startdate.png)        |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |        ![alt](./materials/img/exam_enddate.png)         |
|        startTime         |                       string\<time\|ss:dd\>                       |    Evet    |                     |               Sınav başlama saati.                |                      08:00                       |       ![alt](./materials/img/exam_starttime.png)        |
|         endTime          |                       string\<time\|ss:dd\>                       |    Evet    |                     |                Sınav bitiş saati.                 |                      18:00                       |        ![alt](./materials/img/exam_endtime.png)         |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |        ![alt](./materials/img/exam_latedate.png)        |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |        ![alt](./materials/img/exam_latetime.png)        |
|      submissionType      |                string\<enum\|variable,templated\>                 |    Evet    |                     |               Sınav gönderim tipi.                |                   "templated"                    |    ![alt](./materials/img/exam_submission_type.png)     |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |    ![alt](./materials/img/exam_group_submission.png)    |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         | ![alt](./materials/img/exam_group_submission_limit.png) |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |    ![alt](./materials/img/exam_file_visibility.png)     |
|         passive          |                              boolean                              |   Hayır    |        false        |              Sınav pasiflik durumu.               |                      false                       |                                                         |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |       ![alt](./materials/img/exam_share_inst.png)       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |       ![alt](./materials/img/exam_share_tas.png)        |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |     ![alt](./materials/img/exam_share_students.png)     |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |         ![alt](./materials/img/exam_status.png)         |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |       ![alt](./materials/img/exam_published.png)        |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |        ![alt](./materials/img/exam_regrades.png)        |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |         ![alt](./materials/img/exam_rubic.png)          |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |         ![alt](./materials/img/exam_score.png)          |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |         ![alt](./materials/img/exam_apply.png)          |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |        ![alt](./materials/img/exam_selected.png)        |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |   ![alt](./materials/img/exam_student_visibility.png)   |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |        ![alt](./materials/img/exam_outlines.png)        |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |                                                         |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |                                                         |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |     ![alt](./materials/img/exam_outlines_child.png)     |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |                                                         |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |                                                         |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## POST,PUT /exam/:id

Id bilgisi ile belirtilen sınav bilgilerini günceller. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

Silme işlemi yoktur. Sadece pasife alınabilir.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: |
|          files           |                           array\<file\>                           |   Hayır    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |                     |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |                     |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |
|         passive          |                              boolean                              |   Hayır    |                     |              Sınav pasiflik durumu.               |                       true                       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## GET /homeworks

Ödev bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk | Varsayılan |                                             Açıklama                                              |                 Örnek                 |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :-----------------------------------: |
|          course          |                              string                               |   Hayır    |            |                                         Kurs id bilgisi.                                          |          "925e52a0c8793cd01"          |
|           name           |                              string                               |   Hayır    |            |                                          Sınav bilgisi.                                           |               "Exam 1"                |
|    files.originalName    |                              string                               |   Hayır    |            |                               Sınav yüklenen dosyanın orijinal adı.                               |   "file_example_MP4_480_1_5MG.mp4"    |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |            |                             Sınav gönderisi yükleyecek kişi bilgisi.                              |              "Students"               |
|   allowLateSubmissions   |                               array                               |   Hayır    |            |                         Sınav gönderisini geçiltirecek kişilerin bilgisi.                         | ["All Students", "Disabled Students"] |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                       Sınav başlama tarihi.                                       |              2023-01-08               |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                        Sınav bitiş tarihi.                                        |              2023-02-12               |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                       Sınav başlama saati.                                        |                 08:00                 |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                        Sınav bitiş saati.                                         |                 18:00                 |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                     Sınav geciktirme tarihi.                                      |              2023-02-25               |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                      Sınav geciktirme saati.                                      |                 17:00                 |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |            |                                       Sınav gönderim tipi.                                        |              "templated"              |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |            |                                     Sınav grup gönderim izni.                                     |                 false                 |
|   groupSubmissionLimit   |                              number                               |   Hayır    |            |                                    Sınav grup gönderi limiti.                                     |                   2                   |
|      fileVisibility      |                              boolean                              |   Hayır    |            |                           Sınav dosya görünürlüğü ve indirilebilirliği.                           |                 true                  |
|         passive          |                              boolean                              |   Hayır    |            |                                      Sınav pasiflik durumu.                                       |                 false                 |
|     shareInstructors     |                              boolean                              |   Hayır    |            |                            Sınavın eğitmen/öğretmen için paylaşılması.                            |                 true                  |
|         shareTAs         |                              boolean                              |   Hayır    |            |                            Sınavın öğrenciler(TA?) için paylaşılması.                             |                 true                  |
|      shareStudents       |                              boolean                              |   Hayır    |            |                          Sınavın öğrenciler(Student?) için paylaşılması.                          |                 false                 |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |            |                                       Sınav durum bilgisi.                                        |              "completed"              |
|       isPublished        |                              boolean                              |   Hayır    |            |                                      Sınav paylaşım durumu.                                       |                 true                  |
|        isRegrades        |                              boolean                              |   Hayır    |            |                                Sınav yeniden değerlendirmedurumu.                                 |                 false                 |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |            |                           Sınav varsayılan değerlendirme listesi türü.                            |              "positive"               |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    |            |                                 Sınav varsayılan puan tahvilleri.                                 |               ["floor"]               |
|         applyAll         |                              boolean                              |   Hayır    |            |                            Sınav ayarlarının tüm sorulara uygulanması.                            |                 true                  |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |            |                                   Sınav varsayılan seçim stili.                                   |                 "one"                 |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |            |                                    Sınav öğrenci görünürlüğü.                                     |        "showOnlyAppliedRublic"        |
|      outlines.title      |                              string                               |   Hayır    |            |                                         Sınav soru ismi.                                          |             "Question 1"              |
|      outlines.point      |                              number                               |   Hayır    |            |                                         Sınav soru puanı.                                         |                  10                   |
|           type           |                string\<enum\|exam,homework,quiz\>                 |   Hayır    |            |                                            Sınav tipi.                                            |                "exam"                 |
|     submissions.user     |                              string                               |   Hayır    |            |                          Sınav yüklenen cevap/göderim dosyasının sahibi.                          |              "superUser"              |
|          _limit          |                              number                               |   Hayır    |            | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |                  50                   |
|          _skip           |                              number                               |   Hayır    |            |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |                  20                   |
|         _sortBy          |                              string                               |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |              "username"               |
|        _sortValue        |                              number                               |   Hayır    |            |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |                  -1                   |
|         _project         |                              string                               |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |       "name,startDate,endDate"        |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|           Parametre           |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :---------------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|             data              |                               array                               |                     Sınavlar.                     |                   [{...},...]                    |
|           data._id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          data.course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        data.course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       data.course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           data.name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          data.files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         data.files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        data.files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    data.files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        data.files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      data.files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      data.files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        data.files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      data.files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      data.files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    data.files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    data.uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   data.allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        data.startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         data.endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        data.startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         data.endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         data.lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         data.lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      data.submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| data.isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   data.groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      data.fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         data.passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     data.shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         data.shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      data.shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          data.status          |                 string\<enum\|created,completed\>                 |               Sınav durum bilgisi.                |                   "completed"                    |
|       data.isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        data.isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    data.defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    data.defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         data.applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      data.selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    data.studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         data.outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      data.outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      data.outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     data.outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  data.outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  data.outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           data.type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       data.submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      data.submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     data.submissions.user     |                              string                               |              Sınav gönderim sahini.               |                   "superUser"                    |
|          data.graded          |                              number                               |              Toplam başarı yüzdesi.               |                       100                        |
|          data.stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      data.stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      data.stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       data.stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    data.stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         data.stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## GET /homework/:id

Id ile belirtilen sınav bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|        Parametre         |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|           _id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |                 string\<enum\|created,completed\>                 |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     submissions.user     |                              string                               |              Sınav gönderim sahibi.               |                   "superUser"                    |
|          stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## POST /homework

![alt](./materials/img/homework_post.png)

Sınav bilgisi girmek için kullanılır. Yeni bir sınav kaydedilir. "name" bilgisi benzersiz olmalıdır.

Eğer var olan bir name değerine ait giriş varsa hata döner. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |                          Resim                          |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: | :-----------------------------------------------------: |
|          course          |                              string                               |    Evet    |                     |                 Kurs id bilgisi.                  |               "925e52a0c8793cd01"                |                                                         |
|           name           |                              string                               |    Evet    |                     |                  Sınav bilgisi.                   |                     "Exam 1"                     |          ![alt](./materials/img/exam_name.png)          |
|          files           |                           array\<file\>                           |    Evet    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |         ![alt](./materials/img/exam_files.png)          |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |    Evet    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |   ![alt](./materials/img/exam_upload_submission.png)    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |       ![alt](./materials/img/exam_allow_late.png)       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |       ![alt](./materials/img/exam_startdate.png)        |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |        ![alt](./materials/img/exam_enddate.png)         |
|        startTime         |                       string\<time\|ss:dd\>                       |    Evet    |                     |               Sınav başlama saati.                |                      08:00                       |       ![alt](./materials/img/exam_starttime.png)        |
|         endTime          |                       string\<time\|ss:dd\>                       |    Evet    |                     |                Sınav bitiş saati.                 |                      18:00                       |        ![alt](./materials/img/exam_endtime.png)         |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |        ![alt](./materials/img/exam_latedate.png)        |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |        ![alt](./materials/img/exam_latetime.png)        |
|      submissionType      |                string\<enum\|variable,templated\>                 |    Evet    |                     |               Sınav gönderim tipi.                |                   "templated"                    |    ![alt](./materials/img/exam_submission_type.png)     |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |    ![alt](./materials/img/exam_group_submission.png)    |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         | ![alt](./materials/img/exam_group_submission_limit.png) |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |    ![alt](./materials/img/exam_file_visibility.png)     |
|         passive          |                              boolean                              |   Hayır    |        false        |              Sınav pasiflik durumu.               |                      false                       |                                                         |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |       ![alt](./materials/img/exam_share_inst.png)       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |       ![alt](./materials/img/exam_share_tas.png)        |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |     ![alt](./materials/img/exam_share_students.png)     |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |         ![alt](./materials/img/exam_status.png)         |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |       ![alt](./materials/img/exam_published.png)        |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |        ![alt](./materials/img/exam_regrades.png)        |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |         ![alt](./materials/img/exam_rubic.png)          |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |         ![alt](./materials/img/exam_score.png)          |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |         ![alt](./materials/img/exam_apply.png)          |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |        ![alt](./materials/img/exam_selected.png)        |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |   ![alt](./materials/img/exam_student_visibility.png)   |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |        ![alt](./materials/img/exam_outlines.png)        |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |                                                         |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |                                                         |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |     ![alt](./materials/img/exam_outlines_child.png)     |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |                                                         |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |                                                         |
|         subType          |                              string                               |    Evet    |                     |                  Sınav alt tipi.                  |                    "WebWork"                     |        ![alt](./materials/img/exam_subtype.png)         |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## POST,PUT /homework/:id

Id bilgisi ile belirtilen sınav bilgilerini günceller. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

Silme işlemi yoktur. Sadece pasife alınabilir.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: |
|          files           |                           array\<file\>                           |   Hayır    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |                     |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |                     |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |
|         passive          |                              boolean                              |   Hayır    |                     |              Sınav pasiflik durumu.               |                       true                       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## GET /quizzes

Quiz bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk | Varsayılan |                                             Açıklama                                              |                 Örnek                 |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :-----------------------------------: |
|          course          |                              string                               |   Hayır    |            |                                         Kurs id bilgisi.                                          |          "925e52a0c8793cd01"          |
|           name           |                              string                               |   Hayır    |            |                                          Sınav bilgisi.                                           |               "Exam 1"                |
|    files.originalName    |                              string                               |   Hayır    |            |                               Sınav yüklenen dosyanın orijinal adı.                               |   "file_example_MP4_480_1_5MG.mp4"    |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |            |                             Sınav gönderisi yükleyecek kişi bilgisi.                              |              "Students"               |
|   allowLateSubmissions   |                               array                               |   Hayır    |            |                         Sınav gönderisini geçiltirecek kişilerin bilgisi.                         | ["All Students", "Disabled Students"] |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                       Sınav başlama tarihi.                                       |              2023-01-08               |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                        Sınav bitiş tarihi.                                        |              2023-02-12               |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                       Sınav başlama saati.                                        |                 08:00                 |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                        Sınav bitiş saati.                                         |                 18:00                 |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                     Sınav geciktirme tarihi.                                      |              2023-02-25               |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                      Sınav geciktirme saati.                                      |                 17:00                 |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |            |                                       Sınav gönderim tipi.                                        |              "templated"              |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |            |                                     Sınav grup gönderim izni.                                     |                 false                 |
|   groupSubmissionLimit   |                              number                               |   Hayır    |            |                                    Sınav grup gönderi limiti.                                     |                   2                   |
|      fileVisibility      |                              boolean                              |   Hayır    |            |                           Sınav dosya görünürlüğü ve indirilebilirliği.                           |                 true                  |
|         passive          |                              boolean                              |   Hayır    |            |                                      Sınav pasiflik durumu.                                       |                 false                 |
|     shareInstructors     |                              boolean                              |   Hayır    |            |                            Sınavın eğitmen/öğretmen için paylaşılması.                            |                 true                  |
|         shareTAs         |                              boolean                              |   Hayır    |            |                            Sınavın öğrenciler(TA?) için paylaşılması.                             |                 true                  |
|      shareStudents       |                              boolean                              |   Hayır    |            |                          Sınavın öğrenciler(Student?) için paylaşılması.                          |                 false                 |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |            |                                       Sınav durum bilgisi.                                        |              "completed"              |
|       isPublished        |                              boolean                              |   Hayır    |            |                                      Sınav paylaşım durumu.                                       |                 true                  |
|        isRegrades        |                              boolean                              |   Hayır    |            |                                Sınav yeniden değerlendirmedurumu.                                 |                 false                 |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |            |                           Sınav varsayılan değerlendirme listesi türü.                            |              "positive"               |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    |            |                                 Sınav varsayılan puan tahvilleri.                                 |               ["floor"]               |
|         applyAll         |                              boolean                              |   Hayır    |            |                            Sınav ayarlarının tüm sorulara uygulanması.                            |                 true                  |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |            |                                   Sınav varsayılan seçim stili.                                   |                 "one"                 |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |            |                                    Sınav öğrenci görünürlüğü.                                     |        "showOnlyAppliedRublic"        |
|      outlines.title      |                              string                               |   Hayır    |            |                                         Sınav soru ismi.                                          |             "Question 1"              |
|      outlines.point      |                              number                               |   Hayır    |            |                                         Sınav soru puanı.                                         |                  10                   |
|           type           |                string\<enum\|exam,homework,quiz\>                 |   Hayır    |            |                                            Sınav tipi.                                            |                "exam"                 |
|     submissions.user     |                              string                               |   Hayır    |            |                          Sınav yüklenen cevap/göderim dosyasının sahibi.                          |              "superUser"              |
|          _limit          |                              number                               |   Hayır    |            | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |                  50                   |
|          _skip           |                              number                               |   Hayır    |            |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |                  20                   |
|         _sortBy          |                              string                               |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |              "username"               |
|        _sortValue        |                              number                               |   Hayır    |            |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |                  -1                   |
|         _project         |                              string                               |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |       "name,startDate,endDate"        |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|           Parametre           |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :---------------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|             data              |                               array                               |                     Sınavlar.                     |                   [{...},...]                    |
|           data._id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          data.course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        data.course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       data.course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           data.name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          data.files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         data.files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        data.files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    data.files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        data.files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      data.files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      data.files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        data.files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      data.files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      data.files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    data.files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    data.uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   data.allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        data.startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         data.endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        data.startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         data.endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         data.lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         data.lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      data.submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| data.isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   data.groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      data.fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         data.passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     data.shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         data.shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      data.shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          data.status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       data.isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        data.isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    data.defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    data.defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         data.applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      data.selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    data.studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         data.outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      data.outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      data.outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     data.outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  data.outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  data.outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           data.type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       data.submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      data.submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     data.submissions.user     |                              string                               |              Sınav gönderim sahini.               |                   "superUser"                    |
|          data.graded          |                              number                               |              Toplam başarı yüzdesi.               |                       100                        |
|          data.stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      data.stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      data.stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       data.stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    data.stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         data.stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## GET /quiz/:id

Id ile belirtilen sınav bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|        Parametre         |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|           _id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     submissions.user     |                              string                               |              Sınav gönderim sahibi.               |                   "superUser"                    |
|          stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## POST /quiz

Sınav bilgisi girmek için kullanılır. Yeni bir sınav kaydedilir. "name" bilgisi benzersiz olmalıdır.

Eğer var olan bir name değerine ait giriş varsa hata döner. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |                          Resim                          |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: | :-----------------------------------------------------: |
|          course          |                              string                               |    Evet    |                     |                 Kurs id bilgisi.                  |               "925e52a0c8793cd01"                |                                                         |
|           name           |                              string                               |    Evet    |                     |                  Sınav bilgisi.                   |                     "Exam 1"                     |          ![alt](./materials/img/exam_name.png)          |
|          files           |                           array\<file\>                           |    Evet    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |         ![alt](./materials/img/exam_files.png)          |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |    Evet    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |   ![alt](./materials/img/exam_upload_submission.png)    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |       ![alt](./materials/img/exam_allow_late.png)       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |       ![alt](./materials/img/exam_startdate.png)        |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |        ![alt](./materials/img/exam_enddate.png)         |
|        startTime         |                       string\<time\|ss:dd\>                       |    Evet    |                     |               Sınav başlama saati.                |                      08:00                       |       ![alt](./materials/img/exam_starttime.png)        |
|         endTime          |                       string\<time\|ss:dd\>                       |    Evet    |                     |                Sınav bitiş saati.                 |                      18:00                       |        ![alt](./materials/img/exam_endtime.png)         |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |        ![alt](./materials/img/exam_latedate.png)        |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |        ![alt](./materials/img/exam_latetime.png)        |
|      submissionType      |                string\<enum\|variable,templated\>                 |    Evet    |                     |               Sınav gönderim tipi.                |                   "templated"                    |    ![alt](./materials/img/exam_submission_type.png)     |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |    ![alt](./materials/img/exam_group_submission.png)    |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         | ![alt](./materials/img/exam_group_submission_limit.png) |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |    ![alt](./materials/img/exam_file_visibility.png)     |
|         passive          |                              boolean                              |   Hayır    |        false        |              Sınav pasiflik durumu.               |                      false                       |                                                         |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |       ![alt](./materials/img/exam_share_inst.png)       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |       ![alt](./materials/img/exam_share_tas.png)        |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |     ![alt](./materials/img/exam_share_students.png)     |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |         ![alt](./materials/img/exam_status.png)         |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |       ![alt](./materials/img/exam_published.png)        |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |        ![alt](./materials/img/exam_regrades.png)        |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |         ![alt](./materials/img/exam_rubic.png)          |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |         ![alt](./materials/img/exam_score.png)          |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |         ![alt](./materials/img/exam_apply.png)          |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |        ![alt](./materials/img/exam_selected.png)        |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |   ![alt](./materials/img/exam_student_visibility.png)   |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |        ![alt](./materials/img/exam_outlines.png)        |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |                                                         |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |                                                         |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |     ![alt](./materials/img/exam_outlines_child.png)     |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |                                                         |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |                                                         |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## POST,PUT /quiz/:id

Id bilgisi ile belirtilen sınav bilgilerini günceller. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

Silme işlemi yoktur. Sadece pasife alınabilir.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: |
|          files           |                           array\<file\>                           |   Hayır    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |                     |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |                     |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |
|         passive          |                              boolean                              |   Hayır    |                     |              Sınav pasiflik durumu.               |                       true                       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## GET /examines

Sınav (sınav, ödev, quiz vb.) bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk | Varsayılan |                                             Açıklama                                              |                 Örnek                 |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :-----------------------------------: |
|          course          |                              string                               |   Hayır    |            |                                         Kurs id bilgisi.                                          |          "925e52a0c8793cd01"          |
|           name           |                              string                               |   Hayır    |            |                                          Sınav bilgisi.                                           |               "Exam 1"                |
|    files.originalName    |                              string                               |   Hayır    |            |                               Sınav yüklenen dosyanın orijinal adı.                               |   "file_example_MP4_480_1_5MG.mp4"    |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |            |                             Sınav gönderisi yükleyecek kişi bilgisi.                              |              "Students"               |
|   allowLateSubmissions   |                               array                               |   Hayır    |            |                         Sınav gönderisini geçiltirecek kişilerin bilgisi.                         | ["All Students", "Disabled Students"] |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                       Sınav başlama tarihi.                                       |              2023-01-08               |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                        Sınav bitiş tarihi.                                        |              2023-02-12               |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                       Sınav başlama saati.                                        |                 08:00                 |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                        Sınav bitiş saati.                                         |                 18:00                 |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |            |                                     Sınav geciktirme tarihi.                                      |              2023-02-25               |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |            |                                      Sınav geciktirme saati.                                      |                 17:00                 |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |            |                                       Sınav gönderim tipi.                                        |              "templated"              |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |            |                                     Sınav grup gönderim izni.                                     |                 false                 |
|   groupSubmissionLimit   |                              number                               |   Hayır    |            |                                    Sınav grup gönderi limiti.                                     |                   2                   |
|      fileVisibility      |                              boolean                              |   Hayır    |            |                           Sınav dosya görünürlüğü ve indirilebilirliği.                           |                 true                  |
|         passive          |                              boolean                              |   Hayır    |            |                                      Sınav pasiflik durumu.                                       |                 false                 |
|     shareInstructors     |                              boolean                              |   Hayır    |            |                            Sınavın eğitmen/öğretmen için paylaşılması.                            |                 true                  |
|         shareTAs         |                              boolean                              |   Hayır    |            |                            Sınavın öğrenciler(TA?) için paylaşılması.                             |                 true                  |
|      shareStudents       |                              boolean                              |   Hayır    |            |                          Sınavın öğrenciler(Student?) için paylaşılması.                          |                 false                 |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |            |                                       Sınav durum bilgisi.                                        |              "completed"              |
|       isPublished        |                              boolean                              |   Hayır    |            |                                      Sınav paylaşım durumu.                                       |                 true                  |
|        isRegrades        |                              boolean                              |   Hayır    |            |                                Sınav yeniden değerlendirmedurumu.                                 |                 false                 |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |            |                           Sınav varsayılan değerlendirme listesi türü.                            |              "positive"               |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    |            |                                 Sınav varsayılan puan tahvilleri.                                 |               ["floor"]               |
|         applyAll         |                              boolean                              |   Hayır    |            |                            Sınav ayarlarının tüm sorulara uygulanması.                            |                 true                  |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |            |                                   Sınav varsayılan seçim stili.                                   |                 "one"                 |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |            |                                    Sınav öğrenci görünürlüğü.                                     |        "showOnlyAppliedRublic"        |
|      outlines.title      |                              string                               |   Hayır    |            |                                         Sınav soru ismi.                                          |             "Question 1"              |
|      outlines.point      |                              number                               |   Hayır    |            |                                         Sınav soru puanı.                                         |                  10                   |
|           type           |                string\<enum\|exam,homework,quiz\>                 |   Hayır    |            |                                            Sınav tipi.                                            |                "exam"                 |
|     submissions.user     |                              string                               |   Hayır    |            |                          Sınav yüklenen cevap/göderim dosyasının sahibi.                          |              "superUser"              |
|          _limit          |                              number                               |   Hayır    |            | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |                  50                   |
|          _skip           |                              number                               |   Hayır    |            |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |                  20                   |
|         _sortBy          |                              string                               |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |              "username"               |
|        _sortValue        |                              number                               |   Hayır    |            |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |                  -1                   |
|         _project         |                              string                               |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |       "name,startDate,endDate"        |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|           Parametre           |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :---------------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|             data              |                               array                               |                     Sınavlar.                     |                   [{...},...]                    |
|           data._id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          data.course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        data.course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       data.course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           data.name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          data.files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         data.files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        data.files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    data.files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        data.files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      data.files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      data.files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        data.files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      data.files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      data.files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    data.files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    data.uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   data.allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        data.startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         data.endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        data.startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         data.endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         data.lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         data.lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      data.submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| data.isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   data.groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      data.fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         data.passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     data.shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         data.shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      data.shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          data.status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       data.isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        data.isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    data.defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    data.defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         data.applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      data.selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    data.studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         data.outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      data.outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      data.outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     data.outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  data.outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  data.outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           data.type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       data.submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      data.submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     data.submissions.user     |                              string                               |              Sınav gönderim sahini.               |                   "superUser"                    |
|          data.graded          |                              number                               |              Toplam başarı yüzdesi.               |                       100                        |
|          data.stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      data.stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      data.stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       data.stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    data.stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         data.stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## GET /examine/:id

Id ile belirtilen sınav bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavları görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece kendilerine atanan kurslara ait sınavları paylaşıldığında görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|        Parametre         |                                Tip                                |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :-----------------------------------------------: | :----------------------------------------------: |
|           _id            |                              string                               |                        Id.                        |            "639e50c85880681729f8b23b"            |
|          course          |                          array\<object\>                          |                   Kurs bilgisi.                   |                   [{...},...]                    |
|        course.id         |                              string                               |                    Kurs id'si.                    |               "925e52a0c8793cd01"                |
|       course.name        |                              string                               |                    Kurs ismi.                     |                    "Course 1"                    |
|           name           |                              string                               |                  Sınav bilgisi.                   |                     "Exam 1"                     |
|          files           |                          array\<object\>                          |                 Sınav dosyaları.                  |                   [{...},...]                    |
|         files.id         |                              string                               |              Sınav dosya id bilgisi.              |               "925e52a0c8793cd01"                |
|        files.name        |                              string                               |                 Sınav dosya adı.                  |         "Exams-files-925e52a0c8793cd01"          |
|    files.originalName    |                              string                               |        Sınav yüklenen dosya orijinal adı.         |                "file_example.pdf"                |
|        files.path        |                              string                               |                 Sınav dosya yolu.                 |    "./projects/api/uploads/Exams/sample.pdf"     |
|      files.encoding      |                              string                               |           Sınav dosya encoding bilgisi.           |                      "7bit"                      |
|      files.mimeType      |                              string                               |                 Sınav dosya tipi.                 |                "application/pdf"                 |
|        files.size        |                              number                               |                Sınav dosya boyutu.                |                     1570024                      |
|      files.sizeType      |                              string                               |             Sınav dosya boyutu tipi.              |                      "bayt"                      |
|      files.duration      |                              number                               |                Sınav dosya süresi.                |                        -1                        |
|    files.durationType    |                              string                               |             Sınav dosya süresi tipi.              |                    "seconds"                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|         passive          |                              boolean                              |              Sınav pasiflik durumu.               |                      false                       |
|     shareInstructors     |                              boolean                              |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |       string\<enum\|created,completed,published,regrades\>        |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |               Sınav alt soru puanı.               |                        20                        |
|           type           |                string\<enum\|exam,homework,quiz\>                 |                    Sınav tipi.                    |                      "exam"                      |
|       submissions        |                          array\<object\>                          |                Sınav gönderimleri.                |                   [{...},...]                    |
|      submissions.id      |                              string                               |            Sınav gönderim id bilgisi.             |               "925e52a0c8793cd01"                |
|     submissions.user     |                              string                               |              Sınav gönderim sahibi.               |                   "superUser"                    |
|          stamp           |                              object                               |                Son işlem bilgisi.                 |                      {...}                       |
|      stamp.createAt      |                           string\<ISO\>                           |                Son işlem bilgisi.                 |            "2022-12-17T23:29:12.514Z"            |
|      stamp.username      |                              string                               |                  Kullanıcı adı.                   |                  "system.user"                   |
|       stamp.email        |                              string                               |                  Eposta adresi.                   |               "system@paper-x.com"               |
|    stamp.displayName     |                              string                               |            Görünen adı, isim soyisim.             |               "Sistem Kullanıcısı"               |
|         stamp.ip         |                              string                               |                    Ip adresi.                     |                   "127.0.0.1"                    |

## POST /examine

Sınav bilgisi girmek için kullanılır. Yeni bir sınav kaydedilir. "name" bilgisi benzersiz olmalıdır.

Eğer var olan bir name değerine ait giriş varsa hata döner. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |                          Resim                          |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: | :-----------------------------------------------------: |
|          course          |                              string                               |    Evet    |                     |                 Kurs id bilgisi.                  |               "925e52a0c8793cd01"                |                                                         |
|           name           |                              string                               |    Evet    |                     |                  Sınav bilgisi.                   |                     "Exam 1"                     |          ![alt](./materials/img/exam_name.png)          |
|          files           |                           array\<file\>                           |    Evet    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |         ![alt](./materials/img/exam_files.png)          |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |    Evet    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |   ![alt](./materials/img/exam_upload_submission.png)    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |       ![alt](./materials/img/exam_allow_late.png)       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |       ![alt](./materials/img/exam_startdate.png)        |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |    Evet    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |        ![alt](./materials/img/exam_enddate.png)         |
|        startTime         |                       string\<time\|ss:dd\>                       |    Evet    |                     |               Sınav başlama saati.                |                      08:00                       |       ![alt](./materials/img/exam_starttime.png)        |
|         endTime          |                       string\<time\|ss:dd\>                       |    Evet    |                     |                Sınav bitiş saati.                 |                      18:00                       |        ![alt](./materials/img/exam_endtime.png)         |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |        ![alt](./materials/img/exam_latedate.png)        |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |        ![alt](./materials/img/exam_latetime.png)        |
|      submissionType      |                string\<enum\|variable,templated\>                 |    Evet    |                     |               Sınav gönderim tipi.                |                   "templated"                    |    ![alt](./materials/img/exam_submission_type.png)     |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |    ![alt](./materials/img/exam_group_submission.png)    |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         | ![alt](./materials/img/exam_group_submission_limit.png) |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |    ![alt](./materials/img/exam_file_visibility.png)     |
|         passive          |                              boolean                              |   Hayır    |        false        |              Sınav pasiflik durumu.               |                      false                       |                                                         |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |       ![alt](./materials/img/exam_share_inst.png)       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |       ![alt](./materials/img/exam_share_tas.png)        |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |     ![alt](./materials/img/exam_share_students.png)     |
|          status          |       string\<enum\|created,completed,published,regrades\>        |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |         ![alt](./materials/img/exam_status.png)         |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |       ![alt](./materials/img/exam_published.png)        |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |        ![alt](./materials/img/exam_regrades.png)        |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |         ![alt](./materials/img/exam_rubic.png)          |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |         ![alt](./materials/img/exam_score.png)          |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |         ![alt](./materials/img/exam_apply.png)          |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |        ![alt](./materials/img/exam_selected.png)        |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |   ![alt](./materials/img/exam_student_visibility.png)   |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |        ![alt](./materials/img/exam_outlines.png)        |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |                                                         |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |                                                         |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |     ![alt](./materials/img/exam_outlines_child.png)     |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |                                                         |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |                                                         |
|           type           |                string\<enum\|exam,homework,quiz\>                 |    Evet    |                     |                    Sınav tipi.                    |                      "exam"                      |                                                         |
|         subType          |                              string                               |    Evet    |                     |                  Sınav alt tipi.                  |                    "WebWork"                     |        ![alt](./materials/img/exam_subtype.png)         |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## POST,PUT /examine/:id

Id bilgisi ile belirtilen sınav bilgilerini günceller. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

Silme işlemi yoktur. Sadece pasife alınabilir.

`POST` metodu kullanıldığında append(ardına ekleme) işlemi yapılır. `PUT` metodu kullanıldığında set(atama) işlemi yapılır. (array/liste türleri için)

#### Girdi

|        Parametre         |                                Tip                                | Zorunluluk |     Varsayılan      |                     Açıklama                      |                      Örnek                       |
| :----------------------: | :---------------------------------------------------------------: | :--------: | :-----------------: | :-----------------------------------------------: | :----------------------------------------------: |
|          files           |                           array\<file\>                           |   Hayır    |                     |                 Sınav dosyaları.                  |                     \<FILE\>                     |
|    uploadSubmissions     |                  string\<enum\|student,teacher\>                  |   Hayır    |                     |     Sınav gönderisi yükleyecek kişi bilgisi.      |                    "Students"                    |
|   allowLateSubmissions   |                               array                               |   Hayır    |         []          | Sınav gönderisini geçiltirecek kişilerin bilgisi. |      ["All Students", "Disabled Students"]       |
|        startDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |               Sınav başlama tarihi.               |                    2023-01-08                    |
|         endDate          |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |                Sınav bitiş tarihi.                |                    2023-02-12                    |
|        startTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |               Sınav başlama saati.                |                      08:00                       |
|         endTime          |                       string\<time\|ss:dd\>                       |   Hayır    |                     |                Sınav bitiş saati.                 |                      18:00                       |
|         lateDate         |                    string\<date\|yyyy-aa-gg\>                     |   Hayır    |                     |             Sınav geciktirme tarihi.              |                    2023-02-25                    |
|         lateTime         |                       string\<time\|ss:dd\>                       |   Hayır    |                     |              Sınav geciktirme saati.              |                      17:00                       |
|      submissionType      |                string\<enum\|variable,templated\>                 |   Hayır    |                     |               Sınav gönderim tipi.                |                   "templated"                    |
| isEnabledGroupSubmission |                              boolean                              |   Hayır    |        false        |             Sınav grup gönderim izni.             |                      false                       |
|   groupSubmissionLimit   |                              number                               |   Hayır    |                     |            Sınav grup gönderi limiti.             |                        2                         |
|      fileVisibility      |                              boolean                              |   Hayır    |        false        |   Sınav dosya görünürlüğü ve indirilebilirliği.   |                       true                       |
|     shareInstructors     |                              boolean                              |   Hayır    |        false        |    Sınavın eğitmen/öğretmen için paylaşılması.    |                       true                       |
|         shareTAs         |                              boolean                              |   Hayır    |        false        |    Sınavın öğrenciler(TA?) için paylaşılması.     |                       true                       |
|      shareStudents       |                              boolean                              |   Hayır    |        false        |  Sınavın öğrenciler(Student?) için paylaşılması.  |                      false                       |
|          status          |                 string\<enum\|created,completed\>                 |   Hayır    |       created       |               Sınav durum bilgisi.                |                   "completed"                    |
|       isPublished        |                              boolean                              |   Hayır    |        false        |              Sınav paylaşım durumu.               |                       true                       |
|        isRegrades        |                              boolean                              |   Hayır    |        false        |        Sınav yeniden değerlendirmedurumu.         |                      false                       |
|    defaultRubricType     |                 string\<enum\|negative,positive\>                 |   Hayır    |      negative       |   Sınav varsayılan değerlendirme listesi türü.    |                    "positive"                    |
|    defaultScoreBonds     |                   array\<enum\|ceiling,floor\>                    |   Hayır    | ["ceiling","floor"] |         Sınav varsayılan puan tahvilleri.         |                    ["floor"]                     |
|         applyAll         |                              boolean                              |   Hayır    |        false        |    Sınav ayarlarının tüm sorulara uygulanması.    |                       true                       |
|      selectionStyle      |                     string\<enum\|one,many\>                      |   Hayır    |        many         |           Sınav varsayılan seçim stili.           |                      "one"                       |
|    studentVisibility     | string\<enum\|showAllRublic,hideAllRublic,showOnlyAppliedRublic\> |   Hayır    |    showAllRublic    |            Sınav öğrenci görünürlüğü.             |             "showOnlyAppliedRublic"              |
|         outlines         |                               array                               |   Hayır    |         []          |          Sınav anahatları (puanlar vb.)           | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title      |                              string                               |   Hayır    |                     |                 Sınav soru ismi.                  |                   "Question 1"                   |
|      outlines.point      |                              number                               |   Hayır    |                     |                 Sınav soru puanı.                 |                        10                        |
|     outlines.childs      |                               array                               |   Hayır    |         []          |         Sınav alt anahatlar (puanlar vb.)         |        [{"title":"...","point":...},...]         |
|  outlines.childs.title   |                              string                               |   Hayır    |                     |               Sınav alt soru ismi.                |                  "Question 1.1"                  |
|  outlines.childs.point   |                              number                               |   Hayır    |                     |               Sınav alt soru puanı.               |                        20                        |
|         passive          |                              boolean                              |   Hayır    |                     |              Sınav pasiflik durumu.               |                       true                       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## GET /submissions

Sınav (sınav, ödev, quiz vb.) gönderim bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavların gönderimlerini görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece gönderimlerini görüntüleyebilir.

#### Girdi

|        Parametre         |                Tip                 | Zorunluluk | Varsayılan |                                             Açıklama                                              |           Örnek            |
| :----------------------: | :--------------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :------------------------: |
|        exam.name         |               string               |   Hayır    |            |                                          Sınav bilgisi.                                           |          "Exam 1"          |
| submissions.originalName |               string               |   Hayır    |            |                                  Gönderim dosyanın orijinal adı.                                  |     "file_example.jpg"     |
|      uploader.user       |               string               |   Hayır    |            |                                    Gönderim sahibi bilgileri.                                     |         "student1"         |
|    uploader.createAt     |            date\<ISO\>             |   Hayır    |            |                                   Gönderimin yüklendiği zaman.                                    | "2023-01-08T10:02:00.108Z" |
|      outlines.title      |               string               |   Hayır    |            |                                      Sınav sorularının adı.                                       |        "Question 1"        |
|      outlines.point      |               number               |   Hayır    |            |                                     Sınav sorularının puanı.                                      |             10             |
|         examType         | string\<enum\|exam,homework,quiz\> |   Hayır    |            |                                            Sınav tipi.                                            |             10             |
|         courseId         |               string               |   Hayır    |            |                                         Kurs id bilgisi.                                          |             10             |
|       assigned.id        |         string\<objectId\>         |   Hayır    |            |                                  Atanan kişi/öğrenci id bilgisi.                                  |  63a37398b54d184ab996fabb  |
|    assigned.username     |               string               |   Hayır    |            |                            Atanan kişi/öğrenci kullanıcı adı bilgisi.                             |           "TA 1"           |
|          _limit          |               number               |   Hayır    |            | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |             50             |
|          _skip           |               number               |   Hayır    |            |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |             20             |
|         _sortBy          |               string               |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |         "username"         |
|        _sortValue        |               number               |   Hayır    |            |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |             -1             |
|         _project         |               string               |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. |  "name,startDate,endDate"  |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|           Parametre            |        Tip         |                        Açıklama                        |                      Örnek                       |
| :----------------------------: | :----------------: | :----------------------------------------------------: | :----------------------------------------------: |
|              data              |       array        |                       Sınavlar.                        |                   [{...},...]                    |
|            data._id            |       string       |                          Id.                           |            "639e50c85880681729f8b23b"            |
|           data.exam            |       object       |                    Sınav bilgileri                     |            {"id":"...","name":"..."}             |
|          data.exam.id          |       string       |                   Sınav id bilgisi.                    |            "639e50c85880681729f8b23b"            |
|         data.exam.name         |       string       |                       Sınav adı.                       |                     "Exam 1"                     |
|         data.uploader          |       object       |               Gönderim sahibi bilgileri.               |                      {...}                       |
|     data.uploader.username     |       string       |           Gönderim sahibinin kullanıcı adı.            |                    "student1"                    |
|   data.uploader.displayName    |       string       |             Gönderim sahibinin adı soyadı.             |              "Öğrenci Kullanıcısı"               |
|      data.uploader.email       |       string       |           Gönderim sahibinin eposta adresi.            |              "student@paper-x.com"               |
|      data.uploader.roles       |       array        |              Gönderim sahibinin rolleri.               |                   ["student"]                    |
|        data.uploader.ip        |       string       |             Gönderim sahibinin ip adresi.              |                   "127.0.0.1"                    |
|     data.uploader.createAt     |       string       |               Gönderim işleminin zamanı.               |            "2023-01-08T10:02:00.108Z"            |
|         data.outlines          |       array        |             Sınav anahatları (puanlar vb.)             | [{"title":"...","point":...,"childs":[...]},...] |
|      data.outlines.title       |       string       |                    Sınav soru ismi.                    |                   "Question 1"                   |
|      data.outlines.point       |       number       |                   Sınav soru puanı.                    |                        10                        |
|      data.outlines.childs      |       array        |           Sınav alt anahatlar (puanlar vb.)            |        [{"title":"...","point":...},...]         |
|   data.outlines.childs.title   |       string       |                  Sınav alt soru ismi.                  |                  "Question 1.1"                  |
|   data.outlines.childs.point   |       number       |                 Sınav alt soru puanı.                  |                        20                        |
|        data.submissions        |  array\<object\>   |                    Sınav dosyaları.                    |                   [{...},...]                    |
|      data.submissions.id       |       string       |                Sınav dosya id bilgisi.                 |               "925e52a0c8793cd01"                |
|     data.submissions.name      |       string       |                    Sınav dosya adı.                    |         "Exams-files-925e52a0c8793cd01"          |
| data.submissions.originalName  |       string       |           Sınav yüklenen dosya orijinal adı.           |               "file_example.jpeg"                |
|     data.submissions.path      |       string       |                   Sınav dosya yolu.                    |    "./projects/api/uploads/Exams/sample.jpeg"    |
|   data.submissions.encoding    |       string       |             Sınav dosya encoding bilgisi.              |                      "7bit"                      |
|   data.submissions.mimeType    |       string       |                   Sınav dosya tipi.                    |                   "image/jpeg"                   |
|     data.submissions.size      |       number       |                  Sınav dosya boyutu.                   |                     1570024                      |
|   data.submissions.sizeType    |       string       |                Sınav dosya boyutu tipi.                |                      "bayt"                      |
|   data.submissions.duration    |       number       |                  Sınav dosya süresi.                   |                        -1                        |
| data.submissions.durationType  |       string       |                Sınav dosya süresi tipi.                |                    "seconds"                     |
| data.submissions.outlineTitles |       string       |          Sınav sorusunun/başlığının bilgisi.           |               ["Soru 1/Soru 1.1"]                |
|    data.submissions.passive    |      boolean       |             Gönderinin pasiflik durumudur.             |                      false                       |
|         data.answerer          |       object       |              Cevaplayan sahibi bilgileri.              |                      {...}                       |
|     data.answerer.username     |       string       |          Cevaplayan sahibinin kullanıcı adı.           |                    "teacher1"                    |
|   data.answerer.displayName    |       string       |            Cevaplayan sahibinin adı soyadı.            |              "Öğretmen Kullanıcısı"              |
|      data.answerer.email       |       string       |          Cevaplayan sahibinin eposta adresi.           |              "teacher@paper-x.com"               |
|      data.answerer.roles       |       array        |             Cevaplayan sahibinin rolleri.              |                   ["teacher"]                    |
|        data.answerer.ip        |       string       |            Cevaplayan sahibinin ip adresi.             |                   "127.0.0.1"                    |
|     data.answerer.createAt     |       string       |              Cevaplayan işleminin zamanı.              |            "2023-01-08T10:02:00.108Z"            |
|          data.answers          |  array\<object\>   |          Sınava verilen cevaba ait dosyaları.          |                   [{...},...]                    |
|        data.answers.id         |       string       |      Sınava verilen cevaba ait dosya id bilgisi.       |               "925e52a0c8793cd01"                |
|       data.answers.name        |       string       |          Sınava verilen cevaba ait dosya adı.          |         "Exams-files-925e52a0c8793cd01"          |
|   data.answers.originalName    |       string       | Sınava verilen cevaba ait yüklenen dosya orijinal adı. |               "file_example.jpeg"                |
|       data.answers.path        |       string       |         Sınava verilen cevaba ait dosya yolu.          |    "./projects/api/uploads/Exams/sample.jpeg"    |
|     data.answers.encoding      |       string       |   Sınava verilen cevaba ait dosya encoding bilgisi.    |                      "7bit"                      |
|     data.answers.mimeType      |       string       |         Sınava verilen cevaba ait dosya tipi.          |                   "image/jpeg"                   |
|       data.answers.size        |       number       |        Sınava verilen cevaba ait dosya boyutu.         |                     1570024                      |
|     data.answers.sizeType      |       string       |      Sınava verilen cevaba ait dosya boyutu tipi.      |                      "bayt"                      |
|     data.answers.duration      |       number       |        Sınava verilen cevaba ait dosya süresi.         |                        -1                        |
|   data.answers.durationType    |       string       |      Sınava verilen cevaba ait dosya süresi tipi.      |                    "seconds"                     |
|         data.assigned          |       object       |          Atanan kişi/öğrenci atama bilgileri.          |                      {...}                       |
|        data.assigned.id        | string\<objectId\> |            Atanan kişi/öğrenci id bilgisi.             |             63a37398b54d184ab996fabb             |
|     data.assigned.username     |       string       |       Atanan kişi/öğrenci kullanıcı adı bilgisi.       |                      "TA 1"                      |
|           data.stamp           |       object       |                   Son işlem bilgisi.                   |                      {...}                       |
|      data.stamp.createAt       |   string\<ISO\>    |                   Son işlem bilgisi.                   |            "2022-12-17T23:29:12.514Z"            |
|      data.stamp.username       |       string       |                     Kullanıcı adı.                     |                  "system.user"                   |
|        data.stamp.email        |       string       |                     Eposta adresi.                     |               "system@paper-x.com"               |
|     data.stamp.displayName     |       string       |               Görünen adı, isim soyisim.               |               "Sistem Kullanıcısı"               |
|         data.stamp.ip          |       string       |                       Ip adresi.                       |                   "127.0.0.1"                    |

## GET /submission/:id

Id ile sınav (sınav, ödev, quiz vb.) gönderim bilgisini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Öğretmenler kendi oluşturdukları sınavların gönderimlerini görüntüleyebilir ve düzenleyebilir.

Öğrenciler sadece gönderimlerini görüntüleyebilir.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|         Parametre         |        Tip         |                        Açıklama                        |                      Örnek                       |
| :-----------------------: | :----------------: | :----------------------------------------------------: | :----------------------------------------------: |
|            _id            |       string       |                          Id.                           |            "639e50c85880681729f8b23b"            |
|           exam            |       object       |                    Sınav bilgileri                     |            {"id":"...","name":"..."}             |
|          exam.id          |       string       |                   Sınav id bilgisi.                    |            "639e50c85880681729f8b23b"            |
|         exam.name         |       string       |                       Sınav adı.                       |                     "Exam 1"                     |
|         uploader          |       object       |               Gönderim sahibi bilgileri.               |                      {...}                       |
|     uploader.username     |       string       |           Gönderim sahibinin kullanıcı adı.            |                    "student1"                    |
|   uploader.displayName    |       string       |             Gönderim sahibinin adı soyadı.             |              "Öğrenci Kullanıcısı"               |
|      uploader.email       |       string       |           Gönderim sahibinin eposta adresi.            |              "student@paper-x.com"               |
|      uploader.roles       |       array        |              Gönderim sahibinin rolleri.               |                   ["student"]                    |
|        uploader.ip        |       string       |             Gönderim sahibinin ip adresi.              |                   "127.0.0.1"                    |
|     uploader.createAt     |       string       |               Gönderim işleminin zamanı.               |            "2023-01-08T10:02:00.108Z"            |
|         outlines          |       array        |             Sınav anahatları (puanlar vb.)             | [{"title":"...","point":...,"childs":[...]},...] |
|      outlines.title       |       string       |                    Sınav soru ismi.                    |                   "Question 1"                   |
|      outlines.point       |       number       |                   Sınav soru puanı.                    |                        10                        |
|      outlines.childs      |       array        |           Sınav alt anahatlar (puanlar vb.)            |        [{"title":"...","point":...},...]         |
|   outlines.childs.title   |       string       |                  Sınav alt soru ismi.                  |                  "Question 1.1"                  |
|   outlines.childs.point   |       number       |                 Sınav alt soru puanı.                  |                        20                        |
|        submissions        |  array\<object\>   |                    Sınav dosyaları.                    |                   [{...},...]                    |
|      submissions.id       |       string       |                Sınav dosya id bilgisi.                 |               "925e52a0c8793cd01"                |
|     submissions.name      |       string       |                    Sınav dosya adı.                    |         "Exams-files-925e52a0c8793cd01"          |
| submissions.originalName  |       string       |           Sınav yüklenen dosya orijinal adı.           |               "file_example.jpeg"                |
|     submissions.path      |       string       |                   Sınav dosya yolu.                    |    "./projects/api/uploads/Exams/sample.jpeg"    |
|   submissions.encoding    |       string       |             Sınav dosya encoding bilgisi.              |                      "7bit"                      |
|   submissions.mimeType    |       string       |                   Sınav dosya tipi.                    |                   "image/jpeg"                   |
|     submissions.size      |       number       |                  Sınav dosya boyutu.                   |                     1570024                      |
|   submissions.sizeType    |       string       |                Sınav dosya boyutu tipi.                |                      "bayt"                      |
|   submissions.duration    |       number       |                  Sınav dosya süresi.                   |                        -1                        |
| submissions.durationType  |       string       |                Sınav dosya süresi tipi.                |                    "seconds"                     |
| submissions.outlineTitles |       string       |          Sınav sorusunun/başlığının bilgisi.           |               ["Soru 1/Soru 1.1"]                |
|    submissions.passive    |      boolean       |             Gönderinin pasiflik durumudur.             |                      false                       |
|         answerer          |       object       |              Cevaplayan sahibi bilgileri.              |                      {...}                       |
|     answerer.username     |       string       |          Cevaplayan sahibinin kullanıcı adı.           |                    "teacher1"                    |
|   answerer.displayName    |       string       |            Cevaplayan sahibinin adı soyadı.            |              "Öğretmen Kullanıcısı"              |
|      answerer.email       |       string       |          Cevaplayan sahibinin eposta adresi.           |              "teacher@paper-x.com"               |
|      answerer.roles       |       array        |             Cevaplayan sahibinin rolleri.              |                   ["teacher"]                    |
|        answerer.ip        |       string       |            Cevaplayan sahibinin ip adresi.             |                   "127.0.0.1"                    |
|     answerer.createAt     |       string       |              Cevaplayan işleminin zamanı.              |            "2023-01-08T10:02:00.108Z"            |
|          answers          |  array\<object\>   |          Sınava verilen cevaba ait dosyaları.          |                   [{...},...]                    |
|        answers.id         |       string       |      Sınava verilen cevaba ait dosya id bilgisi.       |               "925e52a0c8793cd01"                |
|       answers.name        |       string       |          Sınava verilen cevaba ait dosya adı.          |         "Exams-files-925e52a0c8793cd01"          |
|   answers.originalName    |       string       | Sınava verilen cevaba ait yüklenen dosya orijinal adı. |               "file_example.jpeg"                |
|       answers.path        |       string       |         Sınava verilen cevaba ait dosya yolu.          |    "./projects/api/uploads/Exams/sample.jpeg"    |
|     answers.encoding      |       string       |   Sınava verilen cevaba ait dosya encoding bilgisi.    |                      "7bit"                      |
|     answers.mimeType      |       string       |         Sınava verilen cevaba ait dosya tipi.          |                   "image/jpeg"                   |
|       answers.size        |       number       |        Sınava verilen cevaba ait dosya boyutu.         |                     1570024                      |
|     answers.sizeType      |       string       |      Sınava verilen cevaba ait dosya boyutu tipi.      |                      "bayt"                      |
|     answers.duration      |       number       |        Sınava verilen cevaba ait dosya süresi.         |                        -1                        |
|   answers.durationType    |       string       |      Sınava verilen cevaba ait dosya süresi tipi.      |                    "seconds"                     |
|         assigned          |       object       |          Atanan kişi/öğrenci atama bilgileri.          |                      {...}                       |
|        assigned.id        | string\<objectId\> |            Atanan kişi/öğrenci id bilgisi.             |             63a37398b54d184ab996fabb             |
|     assigned.username     |       string       |       Atanan kişi/öğrenci kullanıcı adı bilgisi.       |                      "TA 1"                      |
|           stamp           |       object       |                   Son işlem bilgisi.                   |                      {...}                       |
|      stamp.createAt       |   string\<ISO\>    |                   Son işlem bilgisi.                   |            "2022-12-17T23:29:12.514Z"            |
|      stamp.username       |       string       |                     Kullanıcı adı.                     |                  "system.user"                   |
|        stamp.email        |       string       |                     Eposta adresi.                     |               "system@paper-x.com"               |
|     stamp.displayName     |       string       |               Görünen adı, isim soyisim.               |               "Sistem Kullanıcısı"               |
|         stamp.ip          |       string       |                       Ip adresi.                       |                   "127.0.0.1"                    |

## POST /submission

Sınav gönderimlerini yüklemek için kullanılır. Yeni bir gönderim kaydedilir. Aynı sınava yükleme yapıldığında üstüne yazar.

Sadece "admin", "student" ve "superUser" rollerine açıktır.

Alt başlığı olan sorularda "/" işareti ayraç olarak kullanılır. Örneğin "Soru 1" başlığına(title) ait alt başlıklardan(childs) "Soru 1.1" için bir gönderim yapılacaksa "Soru 1/Soru 1.1" şeklinde gönderilmelidir.
Alt başlığı olmayan sorularda doğrudan başlık değeri kullanılabilir. Örneğin "Soru 2"nin(title) alt başlığı(childs) olmadığında "Soru 2" şeklinde gönderilir.

Gönderiler silinemez sadece pasif edilebilir. Bunun için "passive" parametresi kullanılabilir.

#### Girdi

|   Parametre   |      Tip      | Zorunluluk | Varsayılan |                                            Açıklama                                            |           Örnek           |
| :-----------: | :-----------: | :--------: | :--------: | :--------------------------------------------------------------------------------------------: | :-----------------------: |
|     exam      |    string     |  !passive  |            | Sınav id bilgisi.passive parametresi yoksa zorunludur. passive parametresi varken kullanılmaz. |    "925e52a0c8793cd01"    |
|  submissions  | array\<file\> |    Evet    |            |                                Sınav cevap/gönderim dosyaları.                                 |         \<FILE\>          |
| outlineTitles |    string     |    Evet    |            |                                 Sınav cevap/gönderim başlığı.                                  | [Question 1/Question 1.1] |
|    passive    |    boolean    |   Hayır    |   false    |                             Gönderinin pasiflik durumunu ayarlar.                              |           true            |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## PUT /submission/:id

Id bilgisi ile belirtilen gönderim bilgilerini günceller, puanlamak. Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|       Parametre       |   Tip   |     Zorunluluk     | Varsayılan |             Açıklama              |                      Örnek                       |
| :-------------------: | :-----: | :----------------: | :--------: | :-------------------------------: | :----------------------------------------------: |
|       outlines        |  array  |        Evet        |     []     |  Sınav anahatları (puanlar vb.)   | [{"title":"...","point":...,"childs":[...]},...] |
|    outlines.title     | string  |        Evet        |            |         Sınav soru ismi.          |                   "Question 1"                   |
|    outlines.point     | number  |        Evet        |            |         Sınav soru puanı.         |                        10                        |
|    outlines.childs    |  array  |       Hayır        |     []     | Sınav alt anahatlar (puanlar vb.) |        [{"title":"...","point":...},...]         |
| outlines.childs.title | string  | Evet(childs varsa) |            |       Sınav alt soru ismi.        |                  "Question 1.1"                  |
| outlines.childs.point | number  | Evet(childs varsa) |            |       Sınav alt soru puanı.       |                        20                        |
|        passive        | boolean |       Hayır        |            |     Gönderim pasiflik durumu.     |                       true                       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## POST /submission-answer/:id

Id bilgisi ile belirtilen gönderim bilgilerinin cevaplanmış dosyasını günceller, gönderir. Yüklendikçe üstüne yazar.

Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|  Parametre   |      Tip      | Zorunluluk |                  Açıklama                   |        Örnek        |
| :----------: | :-----------: | :--------: | :-----------------------------------------: | :-----------------: |
| submissionId |    string     |    Evet    | Gönderim elemanının id bilgisi. (_id değil) | "c998d2c28a5046d80" |
|   answers    | array\<file\> |    Evet    |       Sınav cevap/gönderim dosyaları.       |      \<FILE\>       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

## POST /submission-evaluate

Sınavlara ait (quiz, homework, exam gibi) not girişlerini yapmak için kullanılır. Herhangi bir gönderim/dosya olmaksızın sadece not/outline girişinin yapılmasını sağlar. Not girişi yapılan sınav için daha önce giriş yapılmışsa üstüne yazar.

Sadece "admin", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

|       Parametre       |        Tip         |     Zorunluluk     | Varsayılan |                  Açıklama                  |                      Örnek                       |
| :-------------------: | :----------------: | :----------------: | :--------: | :----------------------------------------: | :----------------------------------------------: |
|         exam          |       string       |        Evet        |            |             Sınav id bilgisi.              |               "925e52a0c8793cd01"                |
|       outlines        |       array        |        Evet        |     []     |       Sınav anahatları (puanlar vb.)       | [{"title":"...","point":...,"childs":[...]},...] |
|    outlines.title     |       string       |        Evet        |            |              Sınav soru ismi.              |                   "Question 1"                   |
|    outlines.point     |       number       |        Evet        |            |             Sınav soru puanı.              |                        10                        |
|    outlines.childs    |       array        |       Hayır        |     []     |     Sınav alt anahatlar (puanlar vb.)      |        [{"title":"...","point":...},...]         |
| outlines.childs.title |       string       | Evet(childs varsa) |            |            Sınav alt soru ismi.            |                  "Question 1.1"                  |
| outlines.childs.point |       number       | Evet(childs varsa) |            |           Sınav alt soru puanı.            |                        20                        |
|        passive        |      boolean       |       Hayır        |            |         Gönderim pasiflik durumu.          |                       true                       |
|       assigned        |       object       |        Evet        |            |       Atanan kişi/öğrenci bilgileri.       |                      {...}                       |
|      assigned.id      | string\<objectId\> |        Evet        |            |      Atanan kişi/öğrenci id bilgisi.       |             63a37398b54d184ab996fabb             |
|   assigned.username   |       string       |        Evet        |            | Atanan kişi/öğrenci kullanıcı adı bilgisi. |                      "TA 1"                      |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |        Tip         |        Açıklama        |           Örnek            |
| :-------: | :----------------: | :--------------------: | :------------------------: |
|    id     | string\<objectId\> | Veritabanı id bilgisi. | "63d6d10418fe7f514d197b6f" |

## GET /schedules

![alt](./materials/img/schedule.png)

Zamanlanmış bilgileri (kurs, sınav vb.) döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

"startDate" ve "endDate" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

"startTime" ve "endTime" birlikte kullanıldığında aralık sorgulanır. Tek başlarına kullanıldıklarında eşitlik sorgulanır.

Öğretmenler kendi oluşturdukları veriler (kurs, sınav, homework vb.) için planları görüntüleyebilir.

Öğrenciler sadece kendilerine atanan planları görüntüleyebilir.

#### Girdi

| Parametre  |            Tip             | Zorunluluk | Varsayılan |                                             Açıklama                                              |          Örnek           |
| :--------: | :------------------------: | :--------: | :--------: | :-----------------------------------------------------------------------------------------------: | :----------------------: |
|    type    |           string           |   Hayır    |            |                                           Tip bilgisi.                                            |         "course"         |
|    name    |           string           |   Hayır    |            |                                           Plan bilgisi.                                           |        "Course 1"        |
| startDate  | string\<date\|yyyy-aa-gg\> |   Hayır    |            |                                       Plan başlama tarihi.                                        |       "2022-12-18"       |
|  endDate   | string\<date\|yyyy-aa-gg\> |   Hayır    |            |                                        Plan bitiş tarihi.                                         |       "2022-12-30"       |
| startTime  |   string\<time\|ss:dd\>    |   Hayır    |            |                                        Plan başlama saati.                                        |         "10:00"          |
|  endTime   |   string\<time\|ss:dd\>    |   Hayır    |            |                                         Plan bitiş saati.                                         |         "16:00"          |
|   _limit   |           number           |   Hayır    |    1000    | Tek seferde çekilecek veri sayısıdır. -1 girilirse tüm veriler çekilir. (en fazla 1.000.000.000)  |            50            |
|   _skip    |           number           |   Hayır    |     0      |                        Baştan itibaren atlanacak veri sayısını ifade eder.                        |            20            |
|  _sortBy   |           string           |   Hayır    |            |                              Sıralama için kullanılacak alan adıdır.                              |        "username"        |
| _sortValue |           number           |   Hayır    |     1      |      Küçükten büyüğe (1 değeri) mi büyükten küçüğe (-1 değeri) mi sıralanacağını ifade eder.      |            -1            |
|  _project  |           string           |   Hayır    |            | Getirilecek alanları ifade eder. Virgüllerle ayrılmış şekilde birden fazla alan ifade edilebilir. | "name,startDate,endDate" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|   Parametre    |            Tip             |       Açıklama       |           Örnek            |
| :------------: | :------------------------: | :------------------: | :------------------------: |
|      data      |           array            |       Planlar.       |        [{...},...]         |
|    data._id    |           string           |         Id.          | "639e50c85880681729f8b23b" |
|   data.type    |           string           |     Tip bilgisi.     |          "course"          |
|   data.name    |           string           |    Plan bilgisi.     |         "Course 1"         |
| data.startDate | string\<date\|yyyy-aa-gg\> | Plan başlama tarihi. |        "2022-12-18"        |
|  data.endDate  | string\<date\|yyyy-aa-gg\> |  Plan bitiş tarihi.  |        "2022-12-30"        |
| data.startTime |   string\<time\|ss:dd\>    | Plan başlama saati.  |          "10:00"           |
|  data.endTime  |   string\<time\|ss:dd\>    |  Plan bitiş saati.   |          "16:00"           |

#### Örnek
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "63a60a6af2debf14704e5862",
                "name": "Course 1",
                "startTime": "10:00",
                "endTime": "16:00",
                "startDate": "2022-12-18",
                "endDate": "2022-12-30",
                "type": "course"
            },
            {
                "_id": "63a60a6af2debf14704e5863",
                "name": "Course 2",
                "startTime": "13:00",
                "endTime": "15:00",
                "startDate": "2022-12-20",
                "endDate": "2022-12-24",
                "type": "course"
            },
            {
                "_id": "63a60a6af2debf14704e5864",
                "name": "Course 3",
                "startTime": "08:00",
                "endTime": "12:00",
                "startDate": "2022-12-24",
                "endDate": "2022-12-26",
                "type": "course"
            },
            {
                "_id": "63a60a6af2debf14704e5865",
                "name": "Course 4",
                "startTime": "13:00",
                "endTime": "16:00",
                "startDate": "2022-12-28",
                "endDate": "2022-12-31",
                "type": "course"
            },
            {
                "_id": "63a70eef79f3f0f7ee4f9112",
                "name": "Course 6",
                "startTime": "10:00",
                "endTime": "16:00",
                "startDate": "2022-12-18",
                "endDate": "2022-12-30",
                "type": "course"
            },
            {
                "_id": "63a71aae79f3f0f7ee4f9113",
                "name": "Sample Course",
                "startDate": "",
                "endDate": "",
                "type": "course"
            }
        ]
    }
}
```

## GET /grades

![alt](./materials/img/grading.png)

Not, değerlendirme bilgileri tip bazlı döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |            Tip             | Zorunluluk | Varsayılan |       Açıklama       |    Örnek     |
| :-------: | :------------------------: | :--------: | :--------: | :------------------: | :----------: |
| exam.name |           string           |   Hayır    |            |     Tip bilgisi.     |   "course"   |
|  exam.id  |           string           |   Hayır    |            |    Plan bilgisi.     |  "Course 1"  |
| courseId  | string\<date\|yyyy-aa-gg\> |   Hayır    |            | Plan başlama tarihi. | "2022-12-18" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|      Parametre      |  Tip   |                Açıklama                 |           Örnek            |
| :-----------------: | :----: | :-------------------------------------: | :------------------------: |
|        data         | array  |                Planlar.                 |        [{...},...]         |
|      data._id       | string |                   Id.                   | "639e50c85880681729f8b23b" |
|  data.submissions   | number |             Gönderim adeti.             |             2              |
|      data.exam      | object |            Sınav bilgileri.             |           {...}            |
|   data.exam.name    | string |               Sınav adı.                |          "Exam 1"          |
| data.exam.startTime | string |          Sınav başlama saati.           |          "08:00"           |
|  data.exam.endTime  | string |           Sınav bitiş saati.            |          "16:00"           |
|   data.exam.type    | string | Sınav tipi.\<enum\|exam,homework,quiz\> |           "exam"           |
| data.exam.startDate | string |          Sınav başlama tarihi.          |        "2023-01-15"        |
|  data.exam.endDate  | string |           Sınav bitiş tarihi.           |        "2023-02-15"        |
|     data.graded     | number |           Başarı yüzdesi. (%)           |             50             |

## GET /grade-submissions/:id

![alt](./materials/img/grade_submissions.png)

Not, değerlendirme bilgileri soru bazlı döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Not: "Graded By" bölümü anlaşılmadığı için web servisinde bulunmamaktadır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

| Parametre  |  Tip   |               Açıklama                |    Örnek     |
| :--------: | :----: | :-----------------------------------: | :----------: |
|    data    | array  |               Planlar.                | [{...},...]  |
| data.title | string |             Soru başlığı.             | "Question 1" |
| data.point | number |              Soru puanı.              |      10      |
|  data.sum  | number | Soruya cevap verenlerin toplam puanı. |      15      |
| data.total | number |   Toplam soruyu cevaplayan sayısı.    |      2       |
| data.grade | number |       Soru başarı yüzdesi. (%)        |      50      |

## GET /manage-submissions/:id

![alt](./materials/img/grade_manage.png)
![alt](./materials/img/grade_review-2.png)

Not, değerlendirme bilgileri kişi bazlı döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

Not: "Graded", "Viewed" ve "Blackboard" alanları anlaşılmadığı için web servisinde bulunmamaktadır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})
Sürelerde **-1** ifadesi olmadığı anlamına gelir.

|    Parametre     |       Tip       |              Açıklama              |         Örnek         |
| :--------------: | :-------------: | :--------------------------------: | :-------------------: |
|       data       |      array      |              Planlar.              |      [{...},...]      |
|  data.username   |     string      |           Kullanıcı ad.            |      "student1"       |
| data.displayName |     string      |            Görünen ad.             |   "Öğrenci Kişisi"    |
|    data.email    |     string      |           Eposta adresi.           | "student@paper-x.com" |
|    data.roles    | array<\string\> |         Kullanıcı rolleri.         |      ["student"]      |
|     data.ip      |     string      | Gönderim yaptığı andaki ip adresi. |      "127.0.0.1"      |
|  data.createAt   |     string      |          Gönderim zamanı.          | "2023-01-23 13:02:10" |
|   data.graded    |     number      |        Başarı yüzdesi. (%)         |          100          |

## GET /grade-review/:id

![alt](./materials/img/grade_review.png)

Not, değerlendirme bilgileri tip bazlı istatistiksel döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |       Tip       |         Açıklama          |  Örnek  |
| :-------: | :-------------: | :-----------------------: | :-----: |
|    min    |     number      |      En düşük puan.       |    5    |
|  median   |     number      | Medyan noktasındaki puan. |   7.5   |
|    max    |     number      |      En yüksek puan.      |   10    |
|   mean    |     number      |      Ortalama puan.       |   7.5   |
|  stdDev   |     number      |   Standart sapma puanı.   |   2.5   |
|   total   |     number      |  Toplam gönderim sayısı.  |    2    |
|  scores   | array\<number\> |    Puanların listesi.     | [5, 10] |

## GET /grades-established/:courseId

![alt](./materials/img/grade_estimate.png)

Not, değerlendirme bilgileri tip bazlı bar grafik gösterimine uygun döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|             Parametre              |  Tip   |                                            Açıklama                                            |                       Örnek                       |
| :--------------------------------: | :----: | :--------------------------------------------------------------------------------------------: | :-----------------------------------------------: |
|    \<enum\|exam,homework,quiz\>    | object | Sınav tip bilgisidir. Dinamik olarak dolar. Eğer ilgili tipte sonuç yoksa çıktıda gösterilmez. | {"exam": {...}, "homework": {...}, "quiz": {...}} |
| \<enum\|exam,homework,quiz\>.grade | number |                                    Sonuç başarı ortalaması.                                    |                        7.5                        |

## GET /grades-stats/:courseId

![alt](./materials/img/grade_stats.png)

Not, değerlendirme bilgileri tip bazlı döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

|                   Parametre                   |  Tip   |                                            Açıklama                                            |                       Örnek                       |
| :-------------------------------------------: | :----: | :--------------------------------------------------------------------------------------------: | :-----------------------------------------------: |
|                      me                       | object |                            Login olan kişinin kendi başarı durumu.                             |                       {...}                       |
|        me.\<enum\|exam,homework,quiz\>        | object | Sınav tip bilgisidir. Dinamik olarak dolar. Eğer ilgili tipte sonuç yoksa çıktıda gösterilmez. | {"exam": {...}, "homework": {...}, "quiz": {...}} |
|   me.\<enum\|exam,homework,quiz\>.estimated   | number |                                    Sonuç başarı ortalaması.                                    |                        7.5                        |
|      course.\<enum\|exam,homework,quiz\>      | object |                                     Kursun başarı durumu.                                      |                       {...}                       |
|      course.\<enum\|exam,homework,quiz\>      | object | Sınav tip bilgisidir. Dinamik olarak dolar. Eğer ilgili tipte sonuç yoksa çıktıda gösterilmez. | {"exam": {...}, "homework": {...}, "quiz": {...}} |
| course.\<enum\|exam,homework,quiz\>.estimated | number |                                    Sonuç başarı ortalaması.                                    |                        7.5                        |
|   course.\<enum\|exam,homework,quiz\>.grade   | number |                                   Sonuç başarı yüzdesi. (&)                                    |                        50                         |

# Helper Methodları

Input elemanları için kullanılabilir yardımcı web servisleridir. Kaçtane olduğuna bakmaksınız en fazla 25 adet veri döner. 25'ten fazla verisi olan bir servis olur ise filtreleyerek kullanılmalıdır.

## GET /helper/schools

![alt](./materials/img/course_school.png)

Seçim kümesinde kullanılabilir şekilde okul bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |     Açıklama      | Örnek  |
| :-------: | :----: | :--------: | :--------: | :---------------: | :----: |
|   name    | string |   Hayır    |            | Okul adı. (Regex) | "Scho" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Okullar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |         "School 1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "School 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "School 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "School 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "School 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "School 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Scho"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "School 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "School 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "School 3"
            }
        ]
    }
}
```

## GET /helper/departments

![alt](./materials/img/course_department.png)

Seçim kümesinde kullanılabilir şekilde bölüm bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |      Açıklama      | Örnek  |
| :-------: | :----: | :--------: | :--------: | :----------------: | :----: |
|   name    | string |   Hayır    |            | Bölüm adı. (Regex) | "Depa" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Bölümler.   |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |       "Department 1"       |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Department 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Department 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Department 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Department 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Department 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Depa"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Department 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Department 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Department 3"
            }
        ]
    }
}
```

## GET /helper/courses

![alt](./materials/img/course_code.png)

Seçim kümesinde kullanılabilir şekilde kurs bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |     Açıklama      | Örnek  |
| :-------: | :----: | :--------: | :--------: | :---------------: | :----: |
|   name    | string |   Hayır    |            | Kurs adı. (Regex) | "Cour" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Kurslar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |         "Course 1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Course 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Course 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Course 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Course 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Course 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Cour"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Course 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Course 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Course 3"
            }
        ]
    }
}
```

## GET /helper/students

Seçim kümesinde kullanılabilir şekilde öğrenci bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |       Açıklama       | Örnek |
| :-------: | :----: | :--------: | :--------: | :------------------: | :---: |
|   name    | string |   Hayır    |            | Öğrenci adı. (Regex) | "Stu" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Kurslar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |        "Student 1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Student 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Student 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Student 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Student 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Student 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Stu"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Student 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Student 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Student 3"
            }
        ]
    }
}
```

## GET /helper/teachers

Seçim kümesinde kullanılabilir şekilde öğretmen bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |       Açıklama        | Örnek  |
| :-------: | :----: | :--------: | :--------: | :-------------------: | :----: |
|   name    | string |   Hayır    |            | Öğretmen adı. (Regex) | "Teac" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Kurslar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |        "Teacher 1"         |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Teacher 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Teacher 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Teacher 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Teacher 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Teacher 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Teac"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Teacher 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Teacher 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Teacher 3"
            }
        ]
    }
}
```

## GET /helper/grades

![alt](./materials/img/grade_type.png) 

Seçim kümesinde kullanılabilir şekilde grade bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |      Açıklama      | Örnek |
| :-------: | :----: | :--------: | :--------: | :----------------: | :---: |
|   name    | string |   Hayır    |            | Grade adı. (Regex) | "Gra" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Kurslar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |         "Grade 1"          |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Grade 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Grade 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Grade 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Grade 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Grade 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Gra"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Grade 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Grade 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Grade 3"
            }
        ]
    }
}
```

## GET /helper/homeworks

![alt](./materials/img/exam_subtype.png) 

Seçim kümesinde kullanılabilir şekilde homework bilgilerini döner. Sadece "admin", "student", "teacher" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip   | Zorunluluk | Varsayılan |       Açıklama        | Örnek |
| :-------: | :----: | :--------: | :--------: | :-------------------: | :---: |
|   name    | string |   Hayır    |            | Homework adı. (Regex) | "Hom" |

#### Çıktı

Response objesindeki **result** objesinin altındaki alanlardır. ({result: { ... }})

| Parametre |  Tip   |   Açıklama    |           Örnek            |
| :-------: | :----: | :-----------: | :------------------------: |
|   data    | array  |   Kurslar.    |        [{...},...]         |
| data._id  | string |      Id.      | "639e5e445880681729fc2b98" |
| data.name | string | İsim bilgisi. |        "Homework 1"        |

#### Örnek 1
##### Request
```json
{

}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Homework 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Homework 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Homework 3"
            }
        ]
    }
}
```

#### Örnek 2
##### Request
```json
{
    "name": "Homework 1"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Homework 1"
            }
        ]
    }
}
```

#### Örnek 3
##### Request
```json
{
    "name": "Hom"
}
```

##### Response
```json
{
    "code": 0,
    "message": "İşlem başarılı.",
    "isShowMessage": false,
    "result": {
        "data": [
            {
                "_id": "639e5e445880681729fc2b98",
                "name": "Homework 1"
            },
            {
                "_id": "639e5e445880681729fc2b9e",
                "name": "Homework 2"
            },
            {
                "_id": "639e5e445880681729fc2ba0",
                "name": "Homework 3"
            }
        ]
    }
}
```

# Dosya Methodları

## GET /file/:filename

Uygulamada kayıtlı olan dosyaları görüntülemek veya indirmek için kullanılır.
Sadece dosya sahiplerine, "admin" ve "superUser" rollerine açıktır.

#### Girdi

| Parametre |  Tip  | Zorunluluk | Varsayılan | Açıklama | Örnek |
| :-------: | :---: | :--------: | :--------: | :------: | :---: |
|           |       |            |            |          |       |

#### Çıktı

Dosya çıktısıdır. Tarayıcının görüntüleyebileceği bir formatsa görüntülenir.
Eğer tarayıcının görüntüleyebileceği bir format değilse indirilir.

| Parametre |  Tip  | Açıklama | Örnek |
| :-------: | :---: | :------: | :---: |
|           |       |          |       |

#### Örnek
##### Request (/file/Courses-videos-9bc24e510dd5a6250)
##### Response (FILE)
